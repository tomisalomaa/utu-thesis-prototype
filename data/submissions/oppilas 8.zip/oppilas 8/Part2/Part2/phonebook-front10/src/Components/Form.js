import React from 'react'

const Form = ({object}) => {
return (
  <form onSubmit={object.addPerson}>
    <div>
      Name: <input value={object.state.newName} onChange={object.handleNewPerson}/>
    </div>
    <div>
      Number: <input value={object.state.newNumber} onChange={object.handleNewNumber}/>
    </div>
    <div>
      <button type="submit">Add</button>
    </div>
  </form>
)
}
export default Form
