import React from 'react'

const Show = ({name, number, removePerson}) => {
return (
  <p>{name}: {number} <button onClick={removePerson}>Remove</button></p>

)
}
export default Show
