import React from 'react';

const Record = ({name }) => {
return (
  <p>{name}</p>
)
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { id: 1,
          name: 'Arto Hellas'
        }
      ],
      newName: ''
    }
  }

  addPerson = (event) => {
    event.preventDefault()
    const personObject = {
      id: this.state.persons.length + 1,
      name: this.state.newName
    }

    const persons = this.state.persons.concat(personObject)

    this.setState({
    persons: persons,
    newName: ''
    })

  }
  handleNewPerson = (event) => {
    this.setState({ newName: event.target.value })
  }

  render() {
    return (
      <div>
        <h2>Phone book</h2>
        <form onSubmit={this.addPerson}>
          <div>
            Name: <input value={this.state.newName} onChange={this.handleNewPerson}/>
          </div>
          <div>
            <button type="submit">Add</button>
          </div>
        </form>
        <h2>Numbers</h2>
        {this.state.persons.map(person => <Record key={person.id} name={person.name} />)}
      </div>
    )
  }
}

export default App
