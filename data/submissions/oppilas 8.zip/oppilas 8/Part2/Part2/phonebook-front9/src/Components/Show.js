import React from 'react'

const Show = ({name, number}) => {
return (
    <p>{name}: {number}</p>
)
}
export default Show
