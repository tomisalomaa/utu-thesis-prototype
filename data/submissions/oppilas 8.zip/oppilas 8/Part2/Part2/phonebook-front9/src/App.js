import React from 'react'
import phonebookService from './services/phonebook'
import Show from './Components/Show'
import Form from './Components/Form'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: '',
    }
  }
  componentDidMount() {
    phonebookService
      .getAll('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }

  addPerson = (event) => {
    event.preventDefault()
    if (this.state.persons.find(person => person.name === this.state.newName)){
      alert("Duplicate - Record not created")
    }
    else{
      const personObject = {
        name: this.state.newName,
        number: this.state.newNumber
      }

      phonebookService
        .create(personObject)
        .then(response => {
          this.setState({
            persons: this.state.persons.concat(response.data),
            newName: '',
            newNumber: ''
          })
        })
    }

  }

  handleNewPerson = (event) => {
    this.setState({ newName: event.target.value })
  }
  
  handleNewNumber = (event) => {
    this.setState({ newNumber: event.target.value })
  }
  render() {
    return (
      <div>
        <h2>Phone book</h2>
        <Form object={this} />
        <h2>Numbers</h2>
        {this.state.persons.map(person => <Show key={person.id} name={person.name} number={person.number} />)}
      </div>
    )
  }
}

export default App
