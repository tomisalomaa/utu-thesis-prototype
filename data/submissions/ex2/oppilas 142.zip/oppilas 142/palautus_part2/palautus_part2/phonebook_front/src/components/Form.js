const Form = (props) => {
  console.log(props)
  const { addName, newName, handleNameChange, newNumber, handleNumberChange } = props
  return (
    <form onSubmit={addName}>
      nimi: <input
        value={newName}
        onChange={handleNameChange} />

      <div>
        <div>
          numero: <input
            value={newNumber}
            onChange={handleNumberChange} />
        </div>
        <button type="submit">lisää</button>
      </div>
    </form>
  )
}

export default Form