import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

/* const persons = [
  { 
    name: 'Arto Hellas',
    number: '040 969696'
 }
] */

ReactDOM.render(
    <App/>,
  document.getElementById('root')
);
