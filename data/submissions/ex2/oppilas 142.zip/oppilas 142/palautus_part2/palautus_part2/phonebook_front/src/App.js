import React from 'react';
import Person from './components/Person.js'
import Form from './components/Form.js'
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
    console.log('constructor')
  }

  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3002/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  addName = (event) => {
    const isPresent = this.state.persons.find((p) => p.name === this.state.newName);
    if (!isPresent) {
      event.preventDefault()
      const personObject = {
        name: this.state.newName,
        number: this.state.newNumber,
        id: this.state.persons.length + 1
      }

      axios
        .post('http://localhost:3002/persons', personObject)
        .then(response => {
          this.setState({
            persons: this.state.persons.concat(response.data),
            newName: '',
            newNumber: ''
          })
        })
    } else {
      alert("This name has already been submitted");
    }

  }

  handleNameChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })

  }

  handleNumberChange = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value })
  }

  deletePerson = (id) => {
    return () => {
      console.log(`Delete ${id}?`)
      const guy = this.state.persons.find(n => n.id === id)
      const url = `http://localhost:3002/persons/${id}`

      axios
        .delete(url)
        .then(response => {
          window.confirm(`Delete ${guy.name}?`);
          this.setState({
            persons: this.state.persons.filter(note => note.id !== id)
          })
        })
    }
  }


  render() {
    console.log('render')
    return (
      <div>
        <h2>Puhelinluettelo</h2>

        <div>
          <Form addName={this.addName} newName={this.state.newName} handleNameChange={this.handleNameChange} newNumber={this.state.newNumber} handleNumberChange={this.handleNumberChange} />
        </div>

        <h2>Numerot</h2>
        <div>
          {this.state.persons.map(person => <Person key={person.id} person={person} number={person.number} deletePerson={this.deletePerson(person.id)} />)}
        </div>
        <div>
          debug: {this.state.newName} {this.state.newNumber}
        </div>
      </div>
    )
  }
}

export default App