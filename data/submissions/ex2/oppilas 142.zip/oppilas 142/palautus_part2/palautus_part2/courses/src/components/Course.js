import React from 'react'

const Header = (props) => {
  return (
    <div>
      <h1>{props.name}</h1>
    </div>
  )
}

const Part = (props) => {
  return (
    <div>{props.name} {props.exercises}</div>
  )
}

const Contents = ({ part }) => {
  return (
    <div>
      <Part name={part.name} exercises={part.exercises} />
    </div>
  )
}

const Total = (props) => {
  return (
    <div>
      <p>Total {props.parts.map(ex => ex.exercises).reduce((a, b) => a + b, 0)} excercises</p>
    </div>
  );
}
const Course = (props) => {
  return (
    <div>
      <Header name={props.course.name} />
      {props.course.parts.map(part => <Contents key={part.id} part={part} />)}
      <Total parts={props.course.parts} />
    </div>
  )
}

export default Course