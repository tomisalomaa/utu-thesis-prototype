const Course = (props) => {
  var kurssienMaara = props.course.parts.reduce(function(summa, order){
    return summa + order.exercises
  }, 0)
    return(
    <div>
      <h1>{props.course.name}</h1>
      {props.course.parts.map(part => <p key={part.id}>{part.name} {part.exercises}</p>)}
      Total: {kurssienMaara} 
    </div>
  )
}
export default Course