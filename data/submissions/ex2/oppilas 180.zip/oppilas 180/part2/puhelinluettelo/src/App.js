import React from 'react';
import axios from 'axios'
import addName from './components/Note';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }
  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  addName = (event) => {
    event.preventDefault()
    const nameObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }
    
    var persons = this.state.persons
    var x = true;
  
  
    for (const person in persons) {
      console.log(persons[person])
      if (persons[person].name === nameObject.name) {
        alert();
        x = false;
        break;
        
      } 
    }
    if(x) {
      var persons = this.state.persons.concat(nameObject)
    }
    this.setState({
      persons: persons,
      newName: '',
      newNumber: ''
    })
    axios.post('http://localhost:3001/persons', nameObject)
    .then(response => {
      console.log(response)
    })
  }


  handleNameChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
    }
  handleNumberChange = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value })
    }


  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.addName}>
          <div>
            nimi: <input
                    value={this.state.newName}
                    onChange={this.handleNameChange}
                  />
          </div>
          <div>
            numero: <input
                    value={this.state.newNumber}
                    onChange={this.handleNumberChange}
                  />
          </div>
          
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <div>
          debug: {this.state.newName}
        </div>
        <h2>Numerot</h2>
        {this.state.persons.map(person => <div key={Math.random().toString(36).substr(2, 9)}>{person.name}: {person.number}</div>)}
      </div>
      
    )
  }
}

export default App