import React from 'react'

const Course = ({ course }) => {
    const parts = () => course.parts.map(x => <p key={x.id}>{x.name} {x.exercises}</p>)
    var b = 0;
    course.parts.map(x => {b+=x.exercises})
    return (
      <>
      <h1>{course.name}</h1>
      {parts()}
      {"Total:"} {b}
      </>
    )
  }



export default Course
