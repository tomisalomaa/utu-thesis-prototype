const Course = ({course}) => {
    return (
      <div>
        <Header text={course.name}/>
        <Contents parts={course.parts}/>
      </div>
    )
  }
  
  const Header = ({text}) => {
    return (
      <h1>{text}</h1>
    )
  }
  
  const Contents = ({parts}) => {
    const partRows = () =>
    parts.map(part => <Part key={part.id} name={part.name} exercises={part.exercises}/>);
    
    return (
      <div>
        {partRows()}
        <Total parts={parts}/>
      </div>
    )
  }
  
  const Part = ({name, exercises}) => {
    return (
      <p>{name} {exercises}</p>
    )
  }
  
  const Total = ({parts}) => {
    const sum = parts.reduce((prev, current) => prev + current.exercises, 0);
    return (
      <p>Total: {sum}</p>
    )
  }

  export default Course;