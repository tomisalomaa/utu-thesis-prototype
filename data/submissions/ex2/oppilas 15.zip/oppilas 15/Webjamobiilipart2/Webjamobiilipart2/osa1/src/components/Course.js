import React from 'react'

const Course = (props) => {

    const Header = (props) => {
      return (
        <div>
          <h1> {props.name} </h1>
        </div>
      )
    }
    const Contents = (props) => {
      return (
        <div>
          {props.parts.map(part => <Part key={part.id} name={part.name} exercises={part.exercises}/>)}
        </div>
      )
    }
  
    const Part = (props) => {
      return (
        <div>
          <p> {props.name} {props.exercises} </p>
        </div>
      )
    }
  
    const Total = (props) => {
      // props.course.parts[0].exercises + props.course.parts[1].exercises + props.course.parts[2].exercises
      const total = props.parts.reduce((total, currentValue) => total = total + currentValue.exercises,0); 
      return(
        <div>
          <p> Total: {total} </p>
        </div>
      )
    }
  
    
    return (
      <div>
        <Header name ={props.course.name}/>
        <Contents parts = {props.course.parts}/>
        <Total parts = {props.course.parts}/>
      </div>
    )
  }

  export default Course