import React from 'react';
import axios from 'axios'

const Entry = (props) => {
  return (
    <div>
      <p> {props.name} {props.number} <button onClick={props.funktio} id={props.id} name={props.name}> poista </button> </p>
    </div>
  )
}

const Form = (props) => {
  return(
    <form onSubmit={props.onsubmit}>
          <div>
            nimi: <input 
            value={props.value1}
            onChange={props.onChange1}/>
          </div>
          <div>
            numero: <input 
            value={props.value2}
            onChange={props.onChange2}/>
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }


  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }


  handlaaMuutos = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value})
  }

  handlaaMuutos2 = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value})
  }


  lisääYhteystieto = (event) => {
    event.preventDefault()
    const personAsia = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    if (this.state.persons.some(person => person.name === personAsia.name)){
      alert("Nimi oli jo listalla")
    }
    else {
      axios.post('http://localhost:3001/persons', personAsia)
      .then(response => {
        console.log(response)
        this.setState({
          persons: this.state.persons.concat(response.data),
          newName: '',
          newNumber: ''
        })
      })
    }
  }


  poistaYhteystieto = (event) => {
    if(window.confirm(`Poistetaanko ${event.currentTarget.name}`)){
      axios
      .delete(`http://localhost:3001/persons/${event.currentTarget.id}`)
      // kutsutaan jotta yhteystiedot päivittyy
      this.componentDidMount()
      console.log("poistettu")
    }
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form 
        onsubmit={this.lisääYhteystieto}
        value1={this.state.newName}
        onChange1={this.handlaaMuutos}
        value2={this.state.newNumber}
        onChange2={this.handlaaMuutos2}
        />
        <h2>Numerot</h2>
        {this.state.persons.map(person => <Entry key={person.id} id={person.id} name={person.name} number={person.number} funktio={this.poistaYhteystieto}/>)}
      </div>
    )
  }
}

export default App
