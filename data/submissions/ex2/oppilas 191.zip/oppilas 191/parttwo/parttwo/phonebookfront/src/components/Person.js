import React from 'react'

const Person = ({person, deletePerson}) => {
  return (
    <p className='numbers'>{person.name} {person.number} 
    <button onClick={deletePerson}>poista</button>
    </p>
  )
}

export default Person