import React from 'react';
import Person from './components/Person'
import Form from './components/Form'
import personService from './services/persons'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: '',
    }
    console.log('constructor')
  }

  componentDidMount() {
    personService
      .getAll()
      .then(response => {
        this.setState({ persons: response })
      })
  }

  addPerson = (event) => {
    event.preventDefault()
    const names = this.state.persons.map(person => person.name)
    if (names.includes(this.state.newName) === false) {
      const personObject = {
        name: this.state.newName,
        number: this.state.newNumber,
      }

      personService
      .create(personObject)
      .then(newPerson => {
        this.setState({
          persons: this.state.persons.concat(newPerson),
          newName: '',
          newNumber: ''
        })
      }) 
      this.render()

    } else {
      alert('Henkilö on jo lisätty')
      this.setState({
        newName: '',
        newNumber: ''
      })
    }
  }

  deletePerson = (id) => {
    return () => {
      const confirmed = window.confirm('Haluatko poistaa henkilön luettelosta?')
      if (confirmed) {
        personService
        .update(id)
        .then(response => {
          this.setState({persons: response})
        })
      }
    }
  }

  handleNameChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value })
  }


  render() {
    console.log('render')
    return (
      <div>
        <h1>Puhelinluettelo</h1>
        <Form name={this.state.newName} 
        number={this.state.newNumber}
        namechange={this.handleNameChange}
        numberchange={this.handleNumberChange}
        handle={this.addPerson} />
        <h2>Numerot</h2>
        {this.state.persons.map(person => 
        <Person key={person.id} 
        person={person} 
        deletePerson={this.deletePerson(person.id)} />)}
      </div>
    )
  }
}

export default App

