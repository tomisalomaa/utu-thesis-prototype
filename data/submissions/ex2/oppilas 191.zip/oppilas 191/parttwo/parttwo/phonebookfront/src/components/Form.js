import React from 'react'

const Form = ({name, number, namechange, numberchange, handle}) => {
    return (
        <form onSubmit={handle}>
          <div className='teksti'>
            Nimi: <input value={name} onChange={namechange} />
          </div>
          <div className='teksti'>
            Numero: <input value={number} onChange={numberchange} />
          </div>
          <div>
            <button type="submit">tallenna</button>
          </div>
        </form>
    )
}

export default Form
