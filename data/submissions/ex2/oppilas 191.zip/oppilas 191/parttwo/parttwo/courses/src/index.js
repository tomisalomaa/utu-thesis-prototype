import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

const parts = [
  {
    name: 'Basics of React',
    exercises: 15,
    id: 1
  },
  {
    name: 'Using props',
    exercises: 10,
    id: 2
  },
  {
    name: 'Component states',
    exercises: 24,
    id: 3
  }
]


ReactDOM.render(
  <App parts={parts}/>,
  document.getElementById('root')
)