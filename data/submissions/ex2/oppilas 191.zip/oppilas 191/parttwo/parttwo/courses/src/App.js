import React from 'react'
import Course from './components/Course'

const App = ({ parts }) => {
    return (
        <div>
            <h1>Superadvanced web and mobile programming</h1>
            <ul>
                {parts.map(part => <Course key={part.id} part={part} />)}
                <li>Total: {parts.reduce((total, current) => total = total + current.exercises,0)}</li>
            </ul>
        </div>
    )
}

export default App
