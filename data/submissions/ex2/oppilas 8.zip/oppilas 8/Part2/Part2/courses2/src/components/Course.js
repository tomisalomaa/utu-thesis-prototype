
import React from 'react'
import Header from './Header'
import Contents from './Contents'
import Total from './Total'

const Course = ({ course }) => {
return (
  <div>
  <Header name = {course.name} />
  <Contents parts = {course.parts} />
  <Total parts = {course.parts} />
  </div>

)
}

export default Course
