import React from 'react';

const Record = ({name, number}) => {
return (
  <p>{name}: {number}</p>
)
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { id: 1,
          name: 'Arto Hellas',
          number: '0-40 123456'
        }
      ],
      newName: '',
      newNumber: '',
    }
  }

  addPerson = (event) => {
    event.preventDefault()
    if (this.state.persons.find(person => person.name === this.state.newName)){
      alert("Duplicate - Record not created")
    }
    else{
      const personObject = {
        id: this.state.persons.length + 1,
        name: this.state.newName,
        number: this.state.newNumber
      }

      const persons = this.state.persons.concat(personObject)


      this.setState({
      persons: persons,
      newName: '',
      newNumber: ''
      })
    }
  }
  handleNewPerson = (event) => {
    this.setState({ newName: event.target.value })
  }
  handleNewNumber = (event) => {
    this.setState({ newNumber: event.target.value })
  }
  render() {
    return (
      <div>
        <h2>Phone book</h2>
        <form onSubmit={this.addPerson}>
          <div>
            Name: <input value={this.state.newName} onChange={this.handleNewPerson}/>
          </div>
          <div>
            Number: <input value={this.state.newNumber} onChange={this.handleNewNumber}/>
          </div>
          <div>
            <button type="submit">Add</button>
          </div>
        </form>
        <h2>Numbers</h2>
        {this.state.persons.map(person => <Record key={person.id} name={person.name} number={person.number} />)}
      </div>
    )
  }
}

export default App
