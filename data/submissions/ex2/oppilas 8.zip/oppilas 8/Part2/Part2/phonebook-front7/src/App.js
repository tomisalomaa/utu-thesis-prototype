import React from 'react'
import Show from './Components/Show'
import Form from './Components/Form'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { id: 1,
          name: 'Arto Hellas',
          number: '0-40 123456'
        }
      ],
      newName: '',
      newNumber: '',
    }
  }

  addPerson = (event) => {
    event.preventDefault()
    if (this.state.persons.find(person => person.name === this.state.newName)){
      alert("Duplicate - Record not created")
    }
    else{
      const personObject = {
        id: this.state.persons.length + 1,
        name: this.state.newName,
        number: this.state.newNumber
      }

      const persons = this.state.persons.concat(personObject)


      this.setState({
      persons: persons,
      newName: '',
      newNumber: ''
      })
    }
  }
  handleNewPerson = (event) => {
    this.setState({ newName: event.target.value })
  }
  handleNewNumber = (event) => {
    this.setState({ newNumber: event.target.value })
  }
  render() {
    return (
      <div>
        <h2>Phone book</h2>
        <Form object={this} />
        <h2>Numbers</h2>
        {this.state.persons.map(person => <Show key={person.id} name={person.name} number={person.number} />)}
      </div>
    )
  }
}

export default App
