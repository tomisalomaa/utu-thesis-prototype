import React from 'react'
import axios from 'axios'

const Form = ({handler, name, nameHandler, number, numHandler}) => {
	return (
		<div>
			<form onSubmit={handler}>

 	     <div>
      	nimi: <input value={name} onChange={nameHandler} />
       </div>

			 <div>
				numero: <input value={number} onChange={numHandler} />
			 </div>

       <div>
       	<button type="submit">lisää</button>
       </div>

      </form>

		</div>
	)
}

const Contacts = ({contacts, handler}) => {
	return (
		<div>
		<table>
		<tbody>
			{ contacts.map(
				(e) => 
					<tr key={e.id}>
						<td>{e.name}</td>
						<td>{e.number}</td>
						<td><button id={e.id} onClick={handler}>poista</button></td> 
					</tr>	
				) 
			}
		</tbody>
		</table>
		</div>
	)
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      contacts: [
        // { name: 'Arto Hellas', number: '040-123456' }
      ],
      newName: '',
			newNumber: ''
    }
  }

	addPerson = (event) => {
		event.preventDefault()
		console.log('nappia painetu')
		// console.log(event.target)
		const arr = this.state.contacts.map((e) => e.name)
		const res = arr.includes(this.state.newName)
		// console.log(res)
		if(res === false && this.state.newNumber !== '' && this.state.newName !== '') {
			const obj = { 
				name: this.state.newName, 
				number: this.state.newNumber,
				id: this.state.contacts[arr.length - 1].id + 1 
			}
			// console.log(obj)
			const temp = this.state.contacts.concat(obj)
			// console.log(temp)
			this.setState({contacts: temp})

			axios.post('http://localhost:3001/persons', obj)
				.then(response => {console.log(response)})
		}
		else {
			console.log('virhe')	
		}
		this.setState({newName: ''})
		this.setState({newNumber: ''})
	}

	handleChangeName = (event) => {
		this.setState({ newName: event.target.value})
	}
	
	handleChangeNum = (event) => {
		this.setState({ newNumber: event.target.value})
	}

	deleteContact = (e) => {
		console.log('poista: ' + e.target.id)
		axios.delete('http://localhost:3001/persons/' + e.target.id)
		
		setTimeout(() => { 
			axios
				.get('http://localhost:3001/persons')
				.then(response => this.setState({contacts: response.data})) },
			500
		)
	}

	componentDidMount() {
		console.log('did mount')
		axios
			.get('http://localhost:3001/persons')
			.then(response => this.setState({contacts: response.data}))
	}

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
				<Form handler={this.addPerson} 
					name={this.state.newName} nameHandler={this.handleChangeName} 
					number={this.state.newNumber} numHandler={this.handleChangeNum} />
        <h2>Numerot</h2>
				<Contacts contacts={this.state.contacts} handler={this.deleteContact}/>
			</div>
    )
  }
}

export default App
