import React from 'react'

const Header = (props) =>{
  return (
    <div>
      <h1> {props.name} </h1>
    </div>
  )
}

const Part = (props) =>{
  return (
    <div>
      <p> {props.part} {props.exercise}</p>
    </div>
  )
}

const Contents = (props) => {
  // const t = props.parts.map((e) =>  <Part part={e.name} exercise={e.exercises}/> )
  return (
    <div>
      {props.parts.map((e) => <Part part={e.name} exercise={e.exercises}/> )}
    </div>
  )
}

const Total = (props) =>{
  const total = props.parts.reduce((acc, curr) => acc + curr.exercises, 0)
  return (
    <div>
      <p>Total {total} exercises</p>
    </div>
  )
}

const Course = (props) => {
  return (
    <div>
      <Header name={props.course.name} />
      <Contents parts={props.course.parts} />
      <Total parts={props.course.parts} />
    </div>
  )
}

export default Course
