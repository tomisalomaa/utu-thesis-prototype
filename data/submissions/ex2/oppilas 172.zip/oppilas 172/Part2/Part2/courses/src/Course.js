import React from 'react'

const Course = (props) => {
    const {course} = props;
    const courses = () => course.parts.map(course => <p key={course.id}>{course.name} {course.exercises}</p>)
    const total = () => course.parts.reduce((total,currentItem) =>  total = total + currentItem.exercises , 0 )
    
    return (
      <div>
        <header>
          <h1>{course.name}</h1>
        </header>
        <contents>
          {courses()}
          <p>Total: {total()}</p>
        </contents>
      </div>
    )
  }
  
  export default Course