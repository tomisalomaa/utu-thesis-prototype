import React from 'react';
import axios from 'axios';
const Lomake = (props) => {
    return(
      <div>
        <form onSubmit={props.handleEvent}>
            <table>
              <tbody>
                <tr>
                  <th>Nimi:</th>
                  <th>
                    <input 
                      value={props.nimi}
                      onChange={props.nimenMuutos}
                    />
                  </th>
                </tr>
                <tr>
                  <th>Numero:</th>
                  <th>
                    <input
                      value={props.numero}
                      onChange={props.numeronMuutos}
                    />
                  </th>
                </tr>
              </tbody>
            </table>
            <div>
              <button type="submit">Lisää</button>
            </div>
          </form>
      </div>
    )
}
const Numerot = (props) => {
    const persons = props.numerot

    return(
      <div>
        <h2>Numerot</h2>
        <table>
          <thead>
            <tr>
              <th>Nimi</th>
              <th>Numero</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {persons.map(person => <tr key={person.name}>
            <th>{person.name}</th>
            <th>{person.number}</th>
            <th>
              <button id={person.name} onClick={props.handleClick}>
                    Poista
              </button>
            </th>
            </tr>)}
          </tbody>
        </table>
      </div>
    )
  }
class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({persons: response.data})
      })
  }
addPersons = (event) => {
    event.preventDefault()

    const person = {
      name: this.state.newName, 
      number: this.state.newNumber}

    if (person.name === '' || person.number === ''){
      alert("Täytä molemmat kentät.")
    }else {
      if (this.state.persons.map(p => p.name).includes(person.name)) {
        alert(person.name + " on jo listassa.")
      } else {
        axios
          .post('http://localhost:3001/persons', person)
          .then(response => {
            this.setState({
              persons: this.state.persons.concat(response.data),
              newName: '',
              newNumber: ''})
          })
      }
    }
  }

  deletePeople = (event) => {
    event.preventDefault()
    const kohde = event.target.id
    console.log(kohde)
    const person = this.state.persons.filter(p => p.name === kohde)

    if (window.confirm(`Poistetaanko ${kohde} puhelinluettelosta?`)) {
      console.log(person[0].id)
      axios
        .delete(`http://localhost:3001/persons/${person[0].id}`)
        .then(response => {
          console.log("poistettu")
          this.setState({
            persons: this.state.persons.filter(p => p.name !== kohde)
          })
        })
    } else {
      console.log("Ketään ei poistettu")
    }
  }
handlingNameInput = (event) => {
    this.setState({newName: event.target.value})
  }

  handlingNumInput = (event) => {
    this.setState({newNumber: event.target.value})
  }
render() {
    return (
      <div>
        <h1>Puhelinluettelo</h1>
        <Lomake handleEvent={this.addPersons}
          nimi={this.state.newName} nimenMuutos={this.handlingNameInput}
          numero={this.state.newNumber} numeronMuutos={this.handlingNumInput}
        />
        <Numerot numerot={this.state.persons} handleClick={this.deletePeople}/>
      </div>
    )
  }
}

export default App