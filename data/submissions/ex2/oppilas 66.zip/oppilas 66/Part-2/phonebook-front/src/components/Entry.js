import React from 'react';

const Entry = ({ person, deleteNumber }) => {
    return (
        <tr>
            <td>{person.name}</td>
            <td>{person.number}</td>
            <td><button onClick={deleteNumber(person)}>poista</button></td> 
        </tr>
    );
}

export default Entry;
