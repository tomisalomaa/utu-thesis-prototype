import React from 'react';
import Entry from './Entry';

const Numbers = ({ persons, deleteNumber }) => {
    return (
        <div>
            <h2>Numerot</h2>
            <table>
                <tbody>
                {persons.map(person => {
                    return (
                        <Entry 
                            key={`${person.id}_${person.name}_${person.number}`}
                            person={person} 
                            deleteNumber={deleteNumber} />
                    );
                })}
                </tbody>
            </table>
        </div>
    )
};

export default Numbers;
