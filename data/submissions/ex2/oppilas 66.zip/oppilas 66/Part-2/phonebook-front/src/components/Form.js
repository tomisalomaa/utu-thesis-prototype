import React from 'react';

const Form = ({ addNumber, newName, newNumber, handleNameChange, handleNumberChange }) => {
    return (
        <div>
            <h2>Puhelinluettelo</h2>
            <form onSubmit={addNumber}>
                <div>nimi: <input value={newName} onChange={handleNameChange}/></div>
                <div>numero: <input value={newNumber} onChange={handleNumberChange}/></div>
                <button type='submit'>lisää</button>
            </form>
        </div>
    )
}

export default Form;
