import React from 'react';
import ReactDOM from 'react-dom';
import Course from './Course';

const App = () => {
    const data = {
        course: 'Superadvanced web and mobile programming',
        parts: [
            {
                name: 'Basics of React',
                exercises: 8
            },
            {
                name: "Using props",
                exercises: 10
            },
            {
                name: "Component states",
                exercises: 12
            }
        ]
    }

    return (
        <Course data={data}/>
	);
};

ReactDOM.render(<App />, document.getElementById('root'));
