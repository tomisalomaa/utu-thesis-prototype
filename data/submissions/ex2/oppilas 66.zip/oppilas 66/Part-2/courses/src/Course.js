import React from 'react';

const Part = props => {
    return (
        <p>{props.name} {props.exercises}</p>
    )
}

const Header = props => {
    return(
        <div>
            <h1>{props.course}</h1>
        </div>
    )
};

const Contents = props => {
    return (
        <div>
            {props.parts.map((part, index) => {
                return <Part key={index} name={part.name} exercises={part.exercises}/>
            })}
        </div>
    )
};

const Total = props => {
    return (
        <div>
            <p>Total: {props.parts.reduce((accum, part) => accum + part.exercises, 0)}</p>
        </div>
    )
};

const Course = props => {
    return (
        <div>
            <Header course={props.data.course}/>
            <Contents parts={props.data.parts}/>
            <Total parts={props.data.parts}/>
        </div>
    )
};

export default Course;