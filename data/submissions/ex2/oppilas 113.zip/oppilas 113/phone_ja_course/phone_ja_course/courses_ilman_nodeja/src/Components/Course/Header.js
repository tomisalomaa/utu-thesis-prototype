import React from 'react'

const Header = ({header}) => {
  return (
    <h1>{header}</h1>
  )
}

export default Header