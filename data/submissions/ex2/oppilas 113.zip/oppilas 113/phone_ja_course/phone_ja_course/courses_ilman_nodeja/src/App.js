import React from "react"
import Course from "./Components/Course/Course"

const App = ({course}) => {
   
    return (
      <div>
        <Course course={course} />
      </div>
    )
  }
  export default App