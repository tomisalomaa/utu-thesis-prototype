import React from 'react'
const Part = ({parts}) => {
    return (
        <>
        {parts.map(p => <li key={p.id}>{p.name} {p.exercises}</li>)}
        </>
    )
}
const Contents = ({parts}) => {

    let summa = parts.map(p => p.exercises).reduce((sum, exe) => sum + exe,0)
    
  return (
    <>
    <Part parts={parts}/>
    <p>Total: {summa}</p>
    </>
  )
}

export default Contents