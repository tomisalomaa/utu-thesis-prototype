import React from 'react'
import Header from './Header'
import Contents from './Contents/Contents'

const Course = ({course}) => {
  return (
    <>
    <Header header={course.name}/>
    <Contents parts={course.parts}/>
    
    </>
  )
}

export default Course