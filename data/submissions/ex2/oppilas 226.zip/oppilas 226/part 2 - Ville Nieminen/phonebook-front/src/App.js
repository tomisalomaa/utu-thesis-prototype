import React from 'react'
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: '',
    }
  }

  addPerson = (event) => {
    event.preventDefault()
    if (this.state.persons.map((person) => person.name).includes(this.state.newName)) {
      alert("Cannot add multiple of the same name.")
      return
    }
    const newPerson = {
      name: this.state.newName,
      number: this.state.newNumber,
      id: this.state.persons[this.state.persons.length - 1].id + 1
    }
    this.setState({
      persons: this.state.persons.concat(newPerson),
      newName: '',
      newNumber: '',
    })
    axios.post('http://localhost:3001/persons', newPerson).then(response => console.log(response))
  }

  changeNewName = (event) => {
    this.setState({
      newName: event.currentTarget.value
    })
  }

  changeNewNumber = (event) => {
    this.setState({
      newNumber: event.currentTarget.value
    })
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  deleteCallback = (person) => {
    return () => {
      if (window.confirm("poistetaanko " + person.name)) {
        axios.delete('http://localhost:3001/persons/' + person.id).then(response => console.log(response))
        this.setState({persons: this.state.persons.filter(item => item.id !== person.id)})
      }
    }
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form
          submitCallback={this.addPerson}
          nameCallback={this.changeNewName}
          numberCallback={this.changeNewNumber}
          newName={this.state.newName}
          newNumber={this.state.newNumber}
        />
        <h2>Numerot</h2>
        <ContactTable persons={this.state.persons} deleteCallback={this.deleteCallback}/>
      </div>
    )
  }
}

const Form = (props) => {
  return (
    <form onSubmit={props.submitCallback}>
      <div>
        nimi: <input value={props.newName} onChange={props.nameCallback} />
      </div>
      <div>
        numero: <input value={props.newNumber} onChange={props.numberCallback} />
      </div>
      <div>
        <button type="submit">lisää</button>
      </div>
    </form>
  )
}

const ContactTable = ({ persons, deleteCallback }) => {
  return (
    <table>
      <tbody>
        {persons.map((person) => <ContactRow key={person.name} person={person} deleteCallback={deleteCallback} />)}
      </tbody>
    </table>
  )
}

const ContactRow = ({ person, deleteCallback }) => {
  return (
  <tr>
    <td>{person.name}</td>
    <td>{person.number}</td>
    <td><button onClick={deleteCallback(person)}>poista</button></td>
  </tr>
  )
}

export default App
