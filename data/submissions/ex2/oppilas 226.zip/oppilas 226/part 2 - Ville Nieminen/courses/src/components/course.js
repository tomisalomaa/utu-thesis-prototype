import React from 'react'

const Course = ({ headerText, parts }) => {

  const Header = ({ text }) => {
    return <h1>{text}</h1>
  }

  const Contents = ({ parts }) => {
    return parts.map(part => <Part key={part.id} part={part} />);
  }

  const Part = ({ part }) => {
    return <p>{part.name} {part.exercise}</p>
  }

  const Total = ({ parts }) => {
    return (
      <div>
        <p>Total {parts.map(part => part.exercise).reduce((previous, current) => previous + current)} exercises</p>
      </div>
    )
  }

  return (
    <div>
      <Header text={headerText} />
      <Contents parts={parts} />
      <Total parts={parts} />
    </div>
  )
}

export default Course