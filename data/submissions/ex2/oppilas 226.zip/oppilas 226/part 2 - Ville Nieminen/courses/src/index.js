import React from 'react'
import ReactDOM from 'react-dom'
import Course from './components/course'

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = 'Basics of React'
  const exercises1 = 8
  const part2 = 'Using props'
  const exercises2 = 10
  const part3 = 'Component states'
  const exercises3 = 12

  const parts = [
    {
      id: 1,
      name: part1,
      exercise: exercises1
    },
    {
      id: 2,
      name: part2,
      exercise: exercises2
    },
    {
      id: 3,
      name: part3,
      exercise: exercises3
    }
  ]

  return (
    <div>
      <Course headerText={course} parts={parts}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
