import React from 'react'

const Course = ({course}) => {
    const name = course.name
    const parts = course.parts
    return (
      <div>
        <Header name={name} />
        <Contents parts={parts} />
        <Total parts={parts} />
      </div>
    )
  }
  
  const Header = ({name}) => {
    return (
      <h1>{name}</h1>
    )
  }
  
  const Contents = ({parts}) => {
    return (
      <div>
        {parts.map(part => <Part key={part.id} part={part} />)}
      </div>
    )
  }
  
  const Part = ({part}) => {
    return (
      <p>{part.name} {part.exercises}</p>
    )
  }
  
  const Total = ({parts}) => {
    return (
      <p>Total: {parts.reduce((a,b) => a += b.exercises, 0)}</p>
    )
  }

  export default Course