import React from 'react'
import Entry from './Entry'

const Directory = ({persons, deleteEntry}) => {
    return (
      <table>
        <thead>
        </thead>
        <tbody>
          {persons.map(person =>
            <Entry key={person.name}
            person={person}
            deleteEntry={deleteEntry}/>)}
        </tbody>
      </table>
    )
  }

  export default Directory