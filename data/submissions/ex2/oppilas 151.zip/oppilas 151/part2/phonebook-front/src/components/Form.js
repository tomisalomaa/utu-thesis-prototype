import React from 'react'

const Form = ({state, addName, handleNameChange, handleNumChange}) => {
    return (
      <form onSubmit={addName}>
        <div>
          nimi: <input value={state.newName} onChange={handleNameChange} />
        </div>
        <div>
          numero: <input value={state.newNum} onChange={handleNumChange}/>
        </div>
        <div>
          <button type="submit">lisää</button>
        </div>
      </form>
    )
  }

  export default Form