import React from 'react'

const Entry = ({person, deleteEntry}) => {
    return (
      <tr>
        <td>{person.name}</td>
        <td>{person.number}</td>
        <td><button onClick={deleteEntry(person.name, person.id)}>poista</button></td>
      </tr>
    )
  }

  export default Entry