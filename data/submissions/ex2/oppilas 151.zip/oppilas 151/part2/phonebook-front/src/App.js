import React from 'react'
import Form from './components/Form'
import Directory from './components/Directory'
import axios from 'axios'


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNum: ''
    }
  }

  addName = (event) => {
    event.preventDefault()
    if (this.state.persons.some(person => person.name === this.state.newName)) {
      alert('Nimi on jo lisätty!')
    } else {
      const person = {
        name: this.state.newName,
        number: this.state.newNum,
        id: this.state.persons.length + 1
      }
    
      axios
        .post('http://localhost:3001/persons', person)
        .then(response => {
          this.setState({
            persons: this.state.persons.concat(response.data),
            newName: '',
            newNum: ''
          })
        })
    }
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumChange = (event) => {
    this.setState({ newNum: event.target.value })
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }

  deleteEntry = (name, id) => {
    return () => {
      if(window.confirm(`Poistetaanko ${name}?`)) {
        axios
        .delete(`http://localhost:3001/persons/${id}`)
        .then(() => {
          const persons = this.state.persons.filter(person => person.id !== id)
          this.setState({ persons })
        })
      }
      
    }
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form 
          state={this.state}
          addName={this.addName}
          handleNameChange={this.handleNameChange}
          handleNumChange={this.handleNumChange}
        />
        <h2>Numerot</h2>
        <Directory persons={this.state.persons} deleteEntry={this.deleteEntry} />
      </div>
    )
  }
}

export default App
