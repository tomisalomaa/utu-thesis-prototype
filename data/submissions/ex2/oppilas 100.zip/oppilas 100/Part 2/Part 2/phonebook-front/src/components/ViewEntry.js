import React from "react"


const ViewEntry = ({persons, handleDelete}) => {
    return (
      <div>
         {persons.name} &nbsp;&nbsp; {persons.number} &nbsp;&nbsp; 
        <button onClick={handleDelete} type="delete">poista</button>
      </div>
    )
  }

export default ViewEntry

