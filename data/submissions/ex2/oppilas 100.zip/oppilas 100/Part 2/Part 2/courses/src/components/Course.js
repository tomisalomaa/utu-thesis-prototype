import React from 'react'

const Course = ({course}) => {
  return(
    <div>
      <Header header={course.name}/>
      <div>
      <Contents contents ={course.parts}/>
      <div>
      <Total total = {course.parts}/>
      </div>
      </div>
    </div>
  )
}

const Header = ( {header}) => {
  return (
    <div>
      <h1> {header} </h1>
    </div>
  )
}
const Contents = ({contents}) => {
  return (
    <div> 
      {contents.map(part => <Part key={part.id} obj={part} />)}
    </div>
  )
}

const Part = (props) => {
    return (
      <div>
        <p> {props.obj.name} {props.obj.exercises} </p>
      </div>
    )
  }

const Total = ({total}) => {
  return(
    'Total: ' + total.reduce((total, currentValue) => 
    total = total + currentValue.exercises,0)
)
}

export default Course