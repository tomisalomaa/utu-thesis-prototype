import React from 'react'

const Directory = ({ persons, props }) => {
	return (
		<table>
			<tbody>
         		{persons.map(({name, number, id}) => {
    				return <tr key={name}><td >{name}</td>
						<td >{number}</td>
						<td>  
                    	<button onClick = {(event) => props.handleRemovePerson(id, name, event)}>Poista</button>  
                  		</td>  
					</tr>
				})}			
			</tbody>
		</table>
	)
}

export default Directory