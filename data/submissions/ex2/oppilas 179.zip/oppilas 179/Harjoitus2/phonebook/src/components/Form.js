import React from 'react'

const Form = ({ props, person} ) => {	
	return (
		<form onSubmit={props.addName}>
          <div>
            nimi: <input name='nimi' value = {person.newName}
			onChange={props.handleChangeName}/>
          </div>
		  <div>
   			numero: <input name='numero' value = {person.newNumber}
			onChange={props.handleChangeNumber}/>
  		  </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
	)
}	

export default Form