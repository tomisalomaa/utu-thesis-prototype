import React from 'react';


const Course = ({ course }) => {
	
	const total = course.parts.reduce((total, currentValue) => total = total+currentValue.exercises, 0);
	
	return (
		<div>
			<h1>{course.name}</h1>
			<div>
				{course.parts.map(part=>
				<p key={part.id}>
				{part.name} {' '}
				{part.exercises}
				</p>)
				}
			</div>
			<p>Total: {total}</p>
		</div>
	)
}

export default Course