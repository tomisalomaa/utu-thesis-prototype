import React from 'react';
import axios from 'axios';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({persons: response.data})
  })
  }

  addContact = (event) => {
    event.preventDefault()

    if(!this.checkIfPresent()){
      const personObject = {name: this.state.newName, number: this.state.newNumber}
      
      axios
        .post('http://localhost:3001/persons', personObject)
        .then(response => {
          this.setState({
            persons: this.state.persons.concat(response.data),
            newName: '',
            newNumber: ''
          })
        })
    }
    else{
      alert("The name is on the list already")
      this.setState({
        newName: '',
        newNumber: ''
      })
    }
  }

  deleteContact = (props) => {
    const id = props.currentTarget.id
    const person = props.currentTarget.value

    if (window.confirm(`Are you sure you want to delete ${person}?`)){
      axios
        .delete(`http://localhost:3001/persons/${id}`)
        .then(() =>
          this.setState({persons: this.state.persons.filter(p => p.name !== person)}))
    }
  }

  handleAddName = (event) => {
      this.setState({ newName: event.target.value })
  }

  handleAddNumber = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  checkIfPresent = () => {
    const namesList = this.state.persons.map(person => person.name)
    const nameToSearch = this.state.newName
    return(namesList.includes(nameToSearch))
  }


  render() {
    return (
      <div>
        <h2>Phone Book</h2>
        <SearchForm
          addContact={this.addContact}
          name={this.state.newName}
          handleName={this.handleAddName}
          number={this.state.newNumber}
          handleNumber={this.handleAddNumber}/>

        <NameTable
          list={this.state.persons}
          deleteContact={this.deleteContact} />

      </div>
    )
  }
}

const SearchForm = (props) => {
  return(
    <div>
      <form onSubmit={props.addContact}>
        <table>
          <tbody>
            <tr>
              <td>Name:</td>
              <td><input value={props.name} onChange={props.handleName} /></td>
            </tr>
            <tr>
              <td>Number:</td>
              <td><input value={props.number} onChange={props.handleNumber}/></td>
            </tr>
          </tbody>
        </table>
        <div>
          <button type="submit">add</button>
        </div>
      </form>
    </div>
    
  )
}

const NameTable = (props) => {
  return(
    <div>
      <h2>Numbers</h2>
      <table>
        <tbody>
          {props.list.map(person =>
            <tr key={person.name}>
              <td>{person.name}</td>
              <td>{person.number}</td>
              <td>
                <button onClick={props.deleteContact} id={person.id} value={person.name}>
                  delete</button>
              </td>
            </tr>
            )}
        </tbody>
      </table>
    </div>
  )
}


export default App