import React from 'react'

const Header = (t) => {
    return (<h1>{t.title}</h1>)
}

const Contents = (p) => {
    const l = []
    for (let i = 0; i < p.parts.length; i++) {
	l.push(<p key={i}> {p.parts[i].name} {p.parts[i].exercises}</p>);
    }
    return l
}

const Total = (p) => {
    var i = 0
    for (const v of p.parts) {
	i += v.exercises
    }
    return (<p>Total: {i}</p>)
}

const Course = (c) => {
    return (
	<div>
	    <Header title={c.course.name} />
	    <Contents parts={c.course.parts} />
	    <Total parts={c.course.parts} />
	</div>
    )
}

export default Course
