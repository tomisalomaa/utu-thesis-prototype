import axios from 'axios'
import React from 'react';

const URL = 'http://localhost:3001'

const Inp = () => {
    return (
	<div>
	    <div>
		nimi: <input id="name"/>
	    </div>
	    <div>
		numero: <input id="num"/>
	    </div>
	    <div>
		<button type="submit">lisää</button>
	    </div>
	</div>
    )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: ''
    }
  }

  componentDidMount() {
    axios
      .get(URL + '/persons')
      .then(response => {
        this.setState({
	    persons: response.data
	})
      })
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={(e) => {
	    e.preventDefault()
	    var na = e.target.querySelector('#name').value

	    if (na == "" || na == null) {
		return
	    }

	    for (let i = 0; i < this.state.persons.length; i++) {
		if (na == this.state.persons[i].name) {
		    alert("no")
		    return
		}
	    }

	    const contactObj = {
		name: na,
		number: e.target.querySelector('#num').value,
		id: this.state.persons.slice(-1)[0].id + 1
	    }

	  axios
	    .post(URL + '/persons', contactObj)
	    .then(response => {
	      this.setState({
		persons: this.state.persons.concat(response.data)
	      })
	    })
	}}>
	    <Inp/>
        </form>
        <h2>Numerot</h2>
	<table>
	    <tbody>
		{
		    this.state.persons.map((item) => (
			<tr key={item.id}>
			    <td>{item.name}</td>
			    <td>{item.number}</td>
			    <td>
				<button onClick={(e) => {
				    axios
					.delete(URL + '/persons/' + item.id)
					.then(response => {
					    if (response.status == 200) {
						this.setState({
						    persons: this.state.persons.filter(
							function (val, index, arr) {
							    return val.id != item.id
							}
						    )
						})
					    }
					})
				}}>
				    poista
				</button>
			    </td>
			</tr>
		    ))
		}
	    </tbody>
	</table>
      </div>
    )
  }
}

export default App
