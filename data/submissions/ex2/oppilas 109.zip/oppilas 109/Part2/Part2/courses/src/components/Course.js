import React from 'react'

const Course = ({course}) => {
    return(
      <div>
        <Header course={course}/>
        <Contents course={course}/>
      </div>
    )
  }
  
  const Header = ({course}) => {
    return(
      <div>
        <h1>Course name: {course.name}</h1>
      </div>
    )
  }
  
  const Contents = ({course}) => {
    
    let total = 0
    course.parts.map(part=> total += part.exercises)
    
    return(
      <div>
          {course.parts.map(part =><Part key={part.id} part={part}/>)}
          <Total total={total}/>
      </div>
    )
  }
  
  const Part = ({part}) => {
    return(
      <p>
          {part.name} {part.exercises}
      </p>
    )
  }
  
  const Total = (props) => {
    return(
      <p>
        Total: {props.total}
      </p>
    )
  }

  export default Course