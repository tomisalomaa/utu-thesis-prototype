import React from 'react'
import Person from './Person'

const Persons = (props) => {
  return (
     <ul>    
     {props.persons.map((item) => <Person key={item.id} data={item} deletePerson={props.deletePerson}/>)}
     </ul>
  )
}

export default Persons