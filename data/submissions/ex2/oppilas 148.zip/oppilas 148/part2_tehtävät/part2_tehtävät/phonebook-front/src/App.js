import React from 'react'
import axios from 'axios'

import Persons from './components/Persons.js'
import Form from './components/Form.js'


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        {
          name: '',
          number: ''
        }
      ],
      newName: '',
	  newNumber: ''
    }
  }
 
  componentDidMount() {
    axios.get('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }
 
  addPerson = (event) => {
	event.preventDefault()

	const newObject = {
	  name: this.state.newName,
	  number: this.state.newNumber
	}
	
	if (this.state.persons.some(person => person.name === newObject.name)) {
		alert(`${newObject.name} - Not added. Person is already on the list`);
	} else {
		
		axios.post('http://localhost:3001/persons', newObject)
			.then(response => {
			  this.setState({
				persons: this.state.persons.concat(response.data),
				newName: '',
				newNumber: ''
			  })
			})
	  }
	}
	
  handleNameChange = (event) => {
	this.setState({newName: event.target.value})
  }
  
  handleNumberChange = (event) => {
	this.setState({newNumber: event.target.value})
  }
  
  deletePerson = (id) => {  
	  return () => {
		axios.delete(`http://localhost:3001/persons/${id}`)
		  .then(response => {
			const persons = this.state.persons.filter(n => n.id !== id)
			this.setState({
			  persons: persons
			})
		  })
		  .catch(error => {
			alert(`Yhteystieto on jo poistettu palvelimelta`)
		  })
	  }
	}

  render() {
    return (	  
	  <div>
	  <h2>Puhelinluettelo</h2>
		<div>
			{<Form addPerson={this.addPerson} valueName={this.state.newName} handleNameChange={this.handleNameChange} valueNumber={this.state.newNumber} handleNumberChange={this.handleNumberChange} />}
	    </div>
        
		<h2>Numerot</h2>
        <Persons persons={this.state.persons} deletePerson={this.deletePerson} />
			
      </div>
	)
  }
}

export default App