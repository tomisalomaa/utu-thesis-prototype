import React from 'react'

const Person = (props) => {
  return (
    <li>{(props.data.number)} {props.data.name} <button onClick={props.deletePerson(props.data.id)}>Poista</button></li>
  )
}

export default Person