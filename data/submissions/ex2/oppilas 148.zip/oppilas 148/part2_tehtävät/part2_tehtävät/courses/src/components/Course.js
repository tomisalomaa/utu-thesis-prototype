import React from 'react'

const Header = (props) => {
	return (
	  <div>
		<h1>{props.course.name}</h1>
	  </div>
	)
}

const Contents = (props) => {
	return (
	  <ul>
		{props.parts.map(item => <Entry key={item.id} name={item.name} exercise={item.exercises}/>)}
	  </ul>
	)
}

const Entry = (props) => {
	return (
	  <div>
		<li>{props.name} {props.exercise}</li>
	  </div>
	)
}

const Total = (props) => {
  const total = props.parts.reduce(
    (prevValue, currentValue) => prevValue + currentValue.exercises,
    0
  )
	return (
	  <div>
		<p>Total: {total}</p>
	  </div>
	)
}

const Course = (props) => {
  return(
  <div>
    <Header course={props.course} />
    <Contents parts={props.course.parts} />
    <Total parts={props.course.parts} />
  </div>
)
}

export default Course
