import React from 'react';
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { name: 'Arto Hellas', number:'040-123456'}
      ],
      newName: '',
      newNumber: ''
      
    }
  }

  poista = async (id,name) => {
    const baseUrl = 'http://localhost:3001/persons'
    axios
      .get(`${baseUrl}/${id}`)
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ response })
      })
    if(window.confirm("Poistetaanko " + name))
    {
      axios.delete(`${baseUrl}/${id}`)
      window.location.reload();
    }
  }


  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  addName = (event) => {
    event.preventDefault()

    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }
  
    if(this.state.persons.find(n => n.name === this.state.newName)) {
      alert("Nimi on jo syötetty :(")
    }
    else {
      axios
      .post('http://localhost:3001/persons', personObject)
      .then(response => {
        this.setState({
          persons: this.state.persons.concat(response.data),
          newName: '',
          newNumber: ''
        })
      })
    }
  }
  
 
  handleNameChange = (event) => {
    this.setState({
      newName: event.target.value
    })
  }

  handleNumberChange = (event) => {
    this.setState({
      newNumber: event.target.value
    })
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.addName}>
          <div>
            nimi: <input 
            value={this.state.newName}
            onChange={this.handleNameChange}
            />
          </div>
          <div>
            numero: <input 
            value={this.state.newNumber}
            onChange={this.handleNumberChange}/>
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
        <div>
          {this.state.persons.map((n, i) => <p key={i}>{n.name} {n.number}<button id={n.id} name={n.name}onClick={() => this.poista(n.id,n.name)} >poista</button> </p>)}
        </div>
        <div>
          
        </div>
      </div>
    )
  }
}
export default App