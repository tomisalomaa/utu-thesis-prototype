import React from 'react'

const Course = ({course}) => {
  const rivit = () => course.parts.map((course, i) => <p key={i}>{course.name} {course.exercises}</p>)
  let sum = 0;
  for (let i = 0; i < course.parts.length; i++) {
      sum += course.parts[i].exercises;
  }

  return (
    <div>
      <h1>{course.name}</h1>
      <div>
        {rivit()}
        Total: {sum}
      </div>
    </div>

  )
}

export default Course
