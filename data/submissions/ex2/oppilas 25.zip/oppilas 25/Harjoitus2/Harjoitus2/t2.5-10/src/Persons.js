import React from 'react';
const Persons =(props)=>{
    const{person}= props
    return (
      person.map((e)=>
        
        <p>{e.name}</p>
      )
        
      
    )
  }

export default Persons