import React from 'react'

const PersonForm = (addPerson) => {
    return (
        <form onSubmit={addPerson}>
            <div>
                nimi: <input
                    value={addPerson.newName}
                    
                /><br />
                numero: <input
                    value={addPerson.newNumber}
                    
                />
            </div>
            <div>
                <button type="submit">lisää</button>
            </div>
        </form>
    )
}

export default PersonForm