import React from 'react'

class Input extends React.Component{
  render(){
    if(this.props.item.type==="text"){
      return(
        <div>
          {this.props.item.name}: <input  value={this.props.item.value}
          onChange={this.props.item.change}/>
        </div>
        )
    } else if(this.props.item.type==="submit") {
      return(
      <div>
        <button type="submit">{this.props.item.name}</button>
      </div>
    )
    }

  }
}
export default Input
