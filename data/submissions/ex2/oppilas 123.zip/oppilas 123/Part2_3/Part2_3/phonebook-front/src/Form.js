import React from 'react';
import InputField from './InputGroup'
class Form extends React.Component{
  render(){
    return(<form onSubmit={this.props.conf.submit}>
      <InputField inputs={this.props.conf.inputs}/>
    </form>)
  }
}
export default Form
