import React from 'react';
import List from './List'
import Form from './Form'
import axios from 'axios'
class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newPhone: ''
    }
    this.handleNameChange=this.handleNameChange.bind(this)
    this.handlePhoneChange=this.handlePhoneChange.bind(this)
    this.handleSubmit=this.handleSubmit.bind(this)
    this.deleteContact=this.deleteContact.bind(this)
  }
  handleNameChange(e){
    this.setState({newName:e.target.value})
  }
  handlePhoneChange(e){
    this.setState({newPhone:e.target.value})
  }
  deleteContact(id,name){
    return ()=>{
      if (window.confirm(`Poistetaanko ${name}`)) {

        axios.delete(`http://localhost:3001/persons/${id}`)
        .then(response=>{
          this.setState({persons:this.state.persons.filter(item=>item.id!==id)})
        })
      }
    }
  }
  handleSubmit(e){
    e.preventDefault()
    let names =this.state.persons.map(item=>item.name)
    if(names.indexOf(this.state.newName)>-1 || !this.state.newName||!this.state.newPhone){
      alert("Tyhjiä kenttiä tai nimi on jo listalla")
    }
    else{
      let newPerson={name:this.state.newName, number:this.state.newPhone, id:this.state.persons.length+1}
      axios.post(" http://localhost:3001/persons", newPerson)
      .then(response=>{
        this.setState({persons:[...this.state.persons, response.data],newName:'',newPhone:''})
      })
    }

  }
  componentDidMount(){
    axios.get(" http://localhost:3001/persons").then(result=>this.setState({persons:result.data}))
  }
  render() {
    let conf={
      submit: this.handleSubmit,
      inputs: [
        {
          name:"nimi",
          value:this.state.newName,
          change:this.handleNameChange,
          type:'text'
        },
        {
          name:"puhelin",
          value:this.state.newPhone,
          change:this.handlePhoneChange,
          type:'text'
        },
        {
          name:"lisää",
          type:"submit"
        }
      ]
    }
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form conf={conf}/>
        <h2>Numerot</h2>
        <List persons={this.state.persons} removeItem={this.deleteContact}/>
      </div>
    )
  }
}

export default App
