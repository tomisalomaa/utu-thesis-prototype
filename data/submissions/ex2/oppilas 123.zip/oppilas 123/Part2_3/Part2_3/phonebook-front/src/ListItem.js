import React from 'react'

class ListItem extends React.Component{
  render(){
    return(<p key={this.props.item.id}>{this.props.item.name} {this.props.item.number} <button onClick={this.props.removeItem}>poista</button></p>)
  }
}
export default ListItem
