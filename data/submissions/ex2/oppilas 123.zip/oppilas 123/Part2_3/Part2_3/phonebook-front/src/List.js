import React from 'react';
import ListItem from './ListItem'
class List extends React.Component {
  render(){
    let el= this.props.persons.map((item,index)=>{
      return (<ListItem key={item.id} item={item} removeItem={this.props.removeItem(item.id,item.name)}/>)
    })
    return el
  }
}
export default List
