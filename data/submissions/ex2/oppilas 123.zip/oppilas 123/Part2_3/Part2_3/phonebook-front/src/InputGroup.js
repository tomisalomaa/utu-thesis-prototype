import React from 'react'
import TextInput from './Input'
class InputGroup extends React.Component{
  render(){
    let inputList=this.props.inputs.map(item=>{
      return(<TextInput key={item.name} item={item}/>)
    })
    return inputList
  }
}
export default InputGroup
