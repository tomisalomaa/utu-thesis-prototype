import React, { Component } from "react";

class Course extends Component {

  constructor() {
    super();
    this.state = {
      name: "React",
    };
  }

  render() {

    const { parts } = this.props;
    const numRows = parts.length

    for (const element of parts) {
      console.log(element);
    }

    const pr = parts.map(part => `Courses id is: ${part.id}.`)

    return (
      <div>
      {pr}
      </div>
    );

  }

}

export default Course
