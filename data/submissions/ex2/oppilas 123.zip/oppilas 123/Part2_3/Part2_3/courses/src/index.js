import React, { Component } from "react";
import { render } from "react-dom";
import Header from '/Users/loviisamaenpaa/Desktop/WebAndMobileProgramming/courses/src/Header.js';
import Contents from '/Users/loviisamaenpaa/Desktop/WebAndMobileProgramming/courses/src/Contents.js';
import Total from '/Users/loviisamaenpaa/Desktop/WebAndMobileProgramming/courses/src/Total.js';
import Course from '/Users/loviisamaenpaa/Desktop/WebAndMobileProgramming/courses/src/Course.js';

class App extends Component {

  constructor() {
    super();
    this.state = {
      headers: [
        {
          otsikko: 'Superadvanced web and mobile programming'
        }
      ],
      parts: [
        {
          excercises: 8,
          name: "Basics of React",
          id: 1
        },
        {
          excercises: 10,
          name: "Using props",
          id: 2
        },
        {
          excercises: 12,
          name: "Component states",
          id: 3
        }
      ]
    };
  }

  render() {
    return (
      <div>
        <Course
          parts={this.state.parts}
        />
        <Header
          headers={this.state.headers}
        />
        <Contents
          parts={this.state.parts}
        />
        <Total
          parts={this.state.parts}
        />
      </div>
    );
  }
}

render(<App />, document.getElementById("root"));
