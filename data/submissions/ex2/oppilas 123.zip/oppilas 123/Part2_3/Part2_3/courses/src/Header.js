import React, { Component } from "react";

class Header extends Component {

  constructor() {
    super();
    this.state = {
      name: "React",
    };
  }

  render() {

    const { headers } = this.props;

    return (
      <div>
        {
          headers.map((item) => {
            return (
              <div><h1>{item.otsikko}</h1></div>
            )
          })


        }
      </div>
    );
  }
}

export default Header
