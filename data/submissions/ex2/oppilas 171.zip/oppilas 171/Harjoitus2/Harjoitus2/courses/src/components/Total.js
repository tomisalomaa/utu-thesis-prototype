import React from "react"

const Total = ({course}) => {
    const parts = course.parts
    let sum = 0
    for (let part of parts){
      sum = sum + part.exercises
    }
    return (
      <div>
        <p>Total {sum} exercises</p>
      </div>
    )
  }

  export default Total