import React from "react"

const Part = ({part, maara}) => {
    return (
      <p>{part} {maara}</p>
    )
  }

const Header = ({course}) => {
    return (
      <div>
        <h1>{course.name}</h1>
      </div>
    )
  }

  const Contents = ({course}) => {
    return (
      <div>
        {course.parts.map(part => <Part key={part.id} part={part.name} maara={part.exercises} />)}
      </div>
    )
  }

const Course = ({course}) => {
    return (
      <div>
        <Header course={course}/>
        <Contents course={course} />
      </div> 
    )
  }

  export default Course