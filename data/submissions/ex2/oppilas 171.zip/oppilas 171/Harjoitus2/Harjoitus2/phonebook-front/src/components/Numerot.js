import React from "react"
import Person from "./Person"

const Numerot = ({state}) => {
    return (
        <div>
            <h2>Numerot</h2>
            {state.persons.map(person => <Person key={person.name} person={person}/>)}
        </div>
    )
}

export default Numerot