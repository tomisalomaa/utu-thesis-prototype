import React from "react"

const Form = (props) => {
    return (
        <div>
            <form onSubmit={props.addPerson}>
                <div>
                    nimi: <input 
                    value={props.state.newName}
                    onChange={props.handlePerson}/>
                </div>
                <div>
                    numero: <input 
                    value={props.state.newNumber}
                    onChange={props.handleNumber}/>
                </div>
                <div>
                    <button type="submit">lisää</button>
                </div>
            </form>
        </div>
    )
}

export default Form