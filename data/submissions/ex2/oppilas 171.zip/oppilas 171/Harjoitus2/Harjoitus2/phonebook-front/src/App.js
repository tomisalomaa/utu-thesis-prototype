import React from 'react';
import Form from "./components/Form"
import Numerot from "./components/Numerot"
import axios from "axios"

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  addPerson = (event) => {
    event.preventDefault()
    const names = this.state.persons.map(person => person.name)
    if (!names.includes(this.state.newName)){
        this.state.persons.includes(this.state.newName)
        const personObject = {
            name: this.state.newName,
            number: this.state.newNumber
        }

        axios
          .post("http://localhost:3001/persons", personObject)
          .then(response => {
            this.setState({
              persons: this.state.persons.concat(response.data),
              newName: "",
              newNumber: ""
            })
          })
    }
  }

  handleNewPerson = (event) => {
      this.setState({newName: event.target.value})
  }

  handleNewNumber = (event) => {
      this.setState({newNumber: event.target.value})
  }

  componentDidMount(){
    axios
      .get("http://localhost:3001/persons")
      .then(response => {
        this.setState({persons: response.data})
      })
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form state={this.state} addPerson={this.addPerson} handlePerson={this.handleNewPerson} handleNumber={this.handleNewNumber} />
        <Numerot state={this.state} />
      </div>
    )
  }
}

export default App