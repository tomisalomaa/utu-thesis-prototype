import React from 'react'

const Course = (props) => {
  return (
    <div>
      <Header otsikko={props.notes.name} />
      <Contents rivit={props.notes.parts} />

    </div>
  )
}

const Header = (props) => {
  return (
    <div>
      <h1> {props.otsikko} </h1>
    </div>
  )
}

const Contents = (props) => {
  return (
    <div>
      <Part rivi={props.rivit[0]} />
      <Part rivi={props.rivit[1]} />
      <Part rivi={props.rivit[2]} />
      <Total rivi1={props.rivit[0]} rivi2={props.rivit[1]} rivi3={props.rivit[2]} />
    </div>
  )
}

const Part = (props) => {
  return (
    <div>
      <p>{props.rivi.name} {props.rivi.exercises}</p>
    </div>
  )
}

const Total = (props) => {
  var summa = props.rivi1.exercises+props.rivi2.exercises+props.rivi3.exercises
  return (
    <p> Total {summa}</p>
  )
}

export default Course