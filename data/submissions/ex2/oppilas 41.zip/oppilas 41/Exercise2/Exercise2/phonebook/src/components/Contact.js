import React from 'react'

const Contact = ({contact}) => {
    return (
        <p>
            {contact}
        </p>
    )
}
export default Contact
