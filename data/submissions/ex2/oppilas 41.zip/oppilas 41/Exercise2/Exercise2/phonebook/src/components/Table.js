import React from 'react'
import Contact from './Contact'

const Table = (props) => {
    return (
        <table>
          <caption><h2>Contacts</h2></caption>
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Number</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                {props.tiedot.map(contact =>
                  <Contact key={contact.name} contact={contact.name} />)}
                 
              </td>
              <td>
                {props.tiedot.map(contact =>
                  <Contact key={contact.name} contact={contact.number} />)} 
              </td>
            </tr>
          </tbody>
        </table>
    )
}
export default Table