import React from 'react';
import Table from './components/Table'
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
    console.log('constructor')
  }

  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  addContact = (event) => {
    event.preventDefault()
    const noteObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }
    // Tarkistetaan onko nimi jo annettu:
    var valueArr = this.state.persons.map(function (item){ return item.name })
    if (valueArr.includes(noteObject.name) === true) {
      // Jos nimi on duplicate:
      alert('Duplicate!');
      this.setState({
        newName: '',
        newNumber: ''
      })
    }
    else {
      // Jos nimi ei ole duplicate:
      axios
        .post('http://localhost:3001/persons', noteObject)
        .then(response => {
          this.setState({
            persons: this.state.persons.concat(response.data),
            newName: '',
            newNumber: '',
          })
        })
      }
  }

  handleContactChangeName = (event) => {
    console.log('handleName:', event.target.value)
    this.setState({ newName: event.target.value })
  }

  handleContactChangeNumber = (event) => {
    console.log('handeNumber:', event.target.value)
    this.setState({ newNumber: event.target.value })
  }


  render() {
    console.log('render')
    return (
      <div>
        <h1>Puhelinluettelo</h1>
        <form onSubmit={this.addContact}>
          <div>
            nimi:
            <input
              value={this.state.newName}
              onChange={this.handleContactChangeName} />
          </div>
          <div>
            puhelinnumero:
            <input
              value={this.state.newNumber}
              onChange={this.handleContactChangeNumber} />
          </div>
          <div>
            <button type="submit">tallenna</button>
          </div> 
        </form>
        <Table tiedot={this.state.persons} />
      </div>
    )
  }
}
export default App