import React from 'react';
import ReactDOM from 'react-dom';
import course from './components/Course'

const Part = (props) => {
  return (
    <div>
      {props.parts[props.index].name} {props.parts[props.index].exercises}
    </div>
  )
}

const Header = (props) => {
  return(
    <div>
      <h1>{props.course}</h1>
    </div>
  )
}

const Total = (props) => {
  return(
  <div>
    total: {props.parts[0].exercises + props.parts[1].exercises + props.parts[2].exercises}
  </div>
  )
}

const App = (props) => {
  const { course } = props;
  
  return (
    <div>
      <h1>{course.name}</h1>
      <ul>
        {course.parts.map(part_name => <li>{part_name.name}: {part_name.exercises}</li>)}
        <li><Total parts={course.parts}/></li>
      </ul>
    </div>
  )
}

ReactDOM.render(
  <App course={course} />,
  document.getElementById('root')
)
