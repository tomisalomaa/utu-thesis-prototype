import React from "react";

const Person = ({ person,deleteFunction }) => (
    <tr>
        <td>{person.name}</td>
        <td>{person.number}</td>
        <td><button className="deleteButton" onClick={(event) => deleteFunction(event,person)}></button></td>
    </tr>
)

const Persons = ({ persons,deleteFunction }) => (
    <table id="persons-list">
        <tbody>
            {persons.map(person => <Person key={person.name} person={person} deleteFunction={deleteFunction}/>)}
        </tbody>
    </table>
)

export default Persons