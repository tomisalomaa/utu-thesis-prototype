import React from "react"

const Input = ({ input }) => (
    <div>
        {input.name}: <input id={input.name+"-input"} value={input.value} onChange={input.onChange} />
    </div>
)

const Form = ({ onSubmit, inputs }) => (
    <form className="form" onSubmit={onSubmit}>
        {inputs.map(input => <Input key={input.name} input={input} />)}
        <div>
            <button id="add-button" type="submit">lisää</button>
        </div>
    </form>
)

export default Form