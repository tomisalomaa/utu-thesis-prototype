import React from 'react';
import axios from 'axios'
import Persons from './components/Persons';
import Form from './components/Form';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  // get persons array from json server
  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  addPerson = (event) => {
    event.preventDefault()

    // check if empty or duplicate
    let cannotAdd = false;
    if (this.state.newName === '' || this.state.newNumber === '') {
      cannotAdd = true;
    }
    this.state.persons.forEach((item) => {
      if (item.name === this.state.newName) {
        alert(item.name + " on jo lisätty")
        cannotAdd = true
      }
    })
    if (cannotAdd) return;

    // add new person
    const newPerson = {
      name: this.state.newName,
      number: this.state.newNumber,
      id: Math.max(...this.state.persons.map(person => person.id)) + 1
    }
    axios.post('http://localhost:3001/persons', newPerson)
    .then(response => {
      this.setState({ persons: this.state.persons.concat(
        newPerson),
        newName: '',
        newNumber: ''
      })
    })

    document.getElementById("nimi-input").focus()
  }

  deletePerson = ( event,person ) => {
    event.preventDefault()

    if (!window.confirm(`Poistetaanko ${person.name}?`)) return
    const url = `http://localhost:3001/persons/${person.id}`
    
    axios
      .delete(url)
      .then(response =>
        this.setState({
          persons: this.state.persons.filter((item) =>
            item !== person
          )
        })
      )
  }

  render() {
    const inputs = [
      {
        name: "nimi",
        value: this.state.newName,
        onChange: this.handleNameChange
      },
      {
        name: "numero",
        value: this.state.newNumber,
        onChange: this.handleNumberChange
      }
    ]
    return (
      <div>
        <div id="above-content"></div>
        <div id="content">
          <h2>Puhelinluettelo</h2>
          <Form onSubmit={this.addPerson} inputs={inputs}/>
          <h3>Numerot</h3>
          <Persons deleteFunction={this.deletePerson} persons={this.state.persons}/>
        </div>
      </div>
    )
  }
}

export default App
