import React from "react"

const Header = ({ course }) => (
    <div>
        <h1>{course}</h1>
    </div>
)

const Part = ({ part }) => (
    <div className="part">
        <p>{part.name} {part.exercises}</p>
    </div>
)

const Contents = (props) => (
    <div>
        <Part part={props.parts[0]}/>
        <Part part={props.parts[1]}/>
        <Part part={props.parts[2]}/>
    </div>
)

const Total = ({ parts }) => (
    <div>
        <p>Total: {parts[0].exercises +
                  parts[1].exercises +
                  parts[2].exercises}</p>
    </div>
)

const Course = ({ course }) => (
    <div id="content">
            <Header course={course.name} />
            <Contents parts={course.parts} />
            <Total parts={course.parts} />
    </div>
)

export default Course