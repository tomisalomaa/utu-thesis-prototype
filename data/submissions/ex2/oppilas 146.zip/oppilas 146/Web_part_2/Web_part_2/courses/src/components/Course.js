import React from 'react'

const Course = ({ course }) => {
    return (
      <div>
        <Header course = {course} />
        <Contents parts = {course.parts} />
        <Total parts = {course.parts} />
      </div>
    )
  }
  
  const Header = (props) => {
    return (
      <div>
        <h1>{props.course.name}</h1>
      </div>
    )
  }
  
  const Part = (props) => {
    return (
      <div>
        <p>{props.part.name} {props.part.exercises}</p>
      </div>
    )
  }
  
  const Contents = (props) => {
    const info = props.parts.map(x => <p key={x.id}>{x.name + " " + x.exercises}</p>)
    return (
      info
    )
  }
  
  const Total = (props) => {
    const exercises = props.parts.map(x => x.exercises)
    const initialValue = 0;
    const sum = exercises.reduce(
      (previousValue, currentValue) => previousValue + currentValue,
      initialValue
  );
    return (
      <div>
        <p>Total {sum} exercises</p>
      </div>
    )
  }

export default Course
