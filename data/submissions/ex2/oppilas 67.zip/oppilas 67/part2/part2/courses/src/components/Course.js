import React from "react"

const Header = ({ name }) => {
  return (
    <div>
      <h1>{name}</h1>
    </div>
  )
}

const Part = ({ part, exercises }) => {
  return (
    <div>
      <p>
        {part} {exercises}
      </p>
    </div>
  )
}

const Contents = ({ parts }) => {
  const rows = () =>
    parts.map((p) => <Part key={p.id} part={p.name} exercises={p.exercises} />)
  return <div>{rows()}</div>
}

const Total = ({ parts }) => {
  const getTotal = () => parts.reduce((sum, part) => sum + part.exercises, 0)

  return (
    <div>
      <p>Total: {getTotal()}</p>
    </div>
  )
}

const Course = ({ course }) => {
  return (
    <div>
      <Header name={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
  )
}

export default Course
