import React from "react"

const DeleteButton = ({ handleClick }) => {
  return <button onClick={handleClick}>Delete</button>
}

const Contact = ({ person, deleteContact }) => {
  return (
    <tr key={person.name}>
      <td>{person.name}</td>
      <td>{person.number}</td>
      <td>
        <DeleteButton handleClick={() => deleteContact(person.id)} />
      </td>
    </tr>
  )
}

const Contacts = ({ persons, deleteContact }) => {
  const rows = () =>
    persons.map((p) => (
      <Contact key={p.name} person={p} deleteContact={deleteContact} />
    ))

  return (
    <div>
      <h2>Numerot</h2>
      <table>
        <tbody>{rows()}</tbody>
      </table>
    </div>
  )
}

export default Contacts
