import React, { useState, useEffect } from "react"
import axios from "axios"
import Form from "./components/Form"
import Contacts from "./components/Contacts"

const App = () => {
  const [persons, setPersons] = useState([
    { name: "Arto Hellas", number: "0456789224" },
  ])
  const [newName, setNewName] = useState("")
  const [newNumber, setNewNumber] = useState("")

  useEffect(() => {
    axios.get("http://localhost:3001/persons").then((response) => {
      setPersons(response.data)
    })
  }, [])

  const handleNameChange = (event) => {
    setNewName(event.target.value)
  }

  const handleNumberChange = (event) => {
    setNewNumber(event.target.value)
  }

  const deleteContact = (id) => {
    if (
      window.confirm(
        `Are you sure you want to delete ${
          persons.find((p) => p.id === id).name
        }?`
      )
    ) {
      axios.delete(`http://localhost:3001/persons/${id}`).then((response) => {
        setPersons(persons.filter((p) => p.id !== id))
      })
    }
  }

  const addPerson = (event) => {
    event.preventDefault()
    if (persons.some((p) => p.name === newName)) {
      setNewName("")
      setNewNumber("")
      alert("This person has already been added")
    } else {
      const newPerson = {
        name: newName,
        number: newNumber,
      }
      axios
        .post("http://localhost:3001/persons", newPerson)
        .then((response) => {
          setPersons(persons.concat(response.data))
        })
      setNewName("")
      setNewNumber("")
    }
  }

  return (
    <div>
      <Form
        name={newName}
        number={newNumber}
        onNameChange={handleNameChange}
        onNumberChange={handleNumberChange}
        addPerson={addPerson}
      />
      <Contacts persons={persons} deleteContact={deleteContact} />
    </div>
  )
}

export default App
