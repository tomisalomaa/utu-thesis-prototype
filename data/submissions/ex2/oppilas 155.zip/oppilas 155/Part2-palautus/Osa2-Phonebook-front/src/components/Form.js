import React from 'react';

const Form = (props) => {
    
    return(
        <div>
            <h2>Puhelinluettelo</h2>
            <form onSubmit={props.addEntry}>
                <div>
                    nimi: <input value={props.newName} onChange={props.handleNameChange}/>
                </div>
                <div>
                    numero: <input value={props.newNumber} onChange={props.handleNumberChange}/>
                </div>
                <div>
                    <button type="submit">lisää</button>
                </div>
            </form>
            <h2>Numerot</h2>
        </div>
    )

}


export default Form