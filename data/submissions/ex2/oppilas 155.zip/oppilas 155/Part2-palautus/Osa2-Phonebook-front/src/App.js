import React from 'react';
import Persons from './components/Persons';
import Form from './components/Form';
import axios from 'axios'

const baseUrl='http://localhost:3001/persons'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }
  
  componentDidMount() {
    axios
      .get(baseUrl)
      .then(response => {
        console.log('Kaverit noudettu')
        this.setState({ persons: response.data })
      })
  }

  addEntry = (event) => {
    event.preventDefault()

    if (this.state.persons.map(person => person.name).includes(this.state.newName)) {
      alert("Nimi onkin jo listalla")
      return
    }

    const newPerson = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    axios.post(baseUrl, newPerson)
      .then(response => {
        console.log(response)
        this.setState({
          persons: this.state.persons.concat(response.data)
        })
      })    
  }

  removePerson = (id) => {
    return () => {
      const url = `${baseUrl}/${id}`
      const person = this.state.persons.find(psn => psn.id === id)
      if (window.confirm(person.name + ' poistetaan. Oletko varma?')) {
        axios
        .delete(url, person)
        .then(response => {
          console.log(response.data)
          this.setState({
            persons: this.state.persons.filter(person => person.id !== id)
          })
        })
      }
    }
  }

  handleNameChange= (event) => {
    this.setState( {newName: event.target.value})
  }

  handleNumberChange = (event) => {
    this.setState({newNumber: event.target.value})
  }

  render() {
    return (
      <div>
        <Form
          newName={this.state.newName}
          newNumber={this.state.newNumber}
          addEntry={this.addEntry}
          handleNameChange={this.handleNameChange}
          handleNumberChange={this.handleNumberChange}
        />
        <Persons persons={this.state.persons} removePerson={this.removePerson} />
      </div>
    )
  }
}

export default App

