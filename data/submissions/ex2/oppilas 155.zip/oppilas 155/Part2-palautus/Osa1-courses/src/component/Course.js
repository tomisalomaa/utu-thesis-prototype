import React from 'react'

//siirretty komponentit omaan moduliin

  const Header = (props) => {
    return (
      <>
      <h1>{props.course.name}</h1>
      </>
    )
  }
  
  const Part = (props) => {
    return (
      <div>
        <p> {props.part} {props.exercises}</p>
      </div>
    )
  }
  
  const Total = (props) => {
  
//  vanha versio kurssien laskusta, muokattu uusiksi, että kestää kurssien muutokset
//  const t = props.course.parts
//  <p>Total {t[0].exercises+t[1].exercises+t[2].exercises} exercises</p>
      
    return(
      <>
      <p>Total {props.course.parts.map(part => part.exercises).reduce((previousValue, currentValue) => previousValue + currentValue,0)} exercises</p>
      </>
    )
  }
  
  const Contents = (props) => {

/*  Vanha versio, muokattu, että kestää kurssien muutokset
    const t = props.course.parts
      <Part part={t[0].name} exercises={t[0].exercises}/>
      <Part part={t[1].name} exercises={t[1].exercises}/>
      <Part part={t[2].name} exercises={t[2].exercises}/>
*/

    return(
      <>
      {props.course.parts.map(part => <Part key={part.id} part={part.name} exercises={part.exercises}/>)}
      </>
    )
  }

  const Course = (props) => {
    return(
        <div>
            <Header course = {props.course}></Header>
            <Contents course = {props.course}></Contents>
            <Total course = {props.course}></Total>
        </div>
    )
  }

  export default Course