import Part from './Part';

import styles from './shared.module.css';

const Contents = (props) => {

	const { parts } = props;

	if (parts === undefined || parts === []) {
		return <p className={styles.Row} />;
	}

	return parts.map( (part) => <Part key={part.name} name={part.name} count={part.exercises} /> );

};

export default Contents;