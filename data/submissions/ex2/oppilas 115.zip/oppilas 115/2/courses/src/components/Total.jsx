import styles from './shared.module.css';

const Total = (props) => {

	const { parts } = props;

	if (parts === undefined || parts === []) {
		return <p className={styles.Row} />;
	}

	let sum = 0;

	for (const part of parts) {
		if (part.exercises && typeof part.exercises === 'number') {
			sum += part.exercises;
		}
	}

	return (
		<p className={styles.Row}>
			Total {sum} exercises
		</p>
	)
};

export default Total;