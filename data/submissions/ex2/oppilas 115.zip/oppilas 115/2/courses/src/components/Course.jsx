import Header from './Header';
import Contents from './Contents';
import Total from './Total';

const Course = (props) => {
	return (
		<>
			<Header course={props.course.name} />
			<Contents parts={props.course.parts} />
			<Total parts={props.course.parts} />
		</>
	)
};

export default Course;