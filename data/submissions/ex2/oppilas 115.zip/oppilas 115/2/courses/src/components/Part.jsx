import styles from './shared.module.css';

const Part = (props) => {
	return (
		<p className={styles.Row}>
			{ props.name && props.name } { props.count && props.count }
		</p>
	);
};

export default Part;