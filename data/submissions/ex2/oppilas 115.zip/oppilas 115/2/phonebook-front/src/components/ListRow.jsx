import styles from './ListRow.module.css';

const ListRow = (props) => {
	return (
		<div className={styles.ListRow}>
			<div className={styles.Column}>
				{props.name}
			</div>
			<div className={styles.Column}>
				{props.number}
			</div>
			<div className={styles.Column}>
				<button type={'button'}
						onClick={props.onClick}
				>
					Poista
				</button>
			</div>
		</div>
	);
};

export default ListRow;