const SubmitButton = (props) => {
	return (
		<button type={'button'} onClick={props.onClick}>
			Lisää
		</button>
	);
};

export default SubmitButton;