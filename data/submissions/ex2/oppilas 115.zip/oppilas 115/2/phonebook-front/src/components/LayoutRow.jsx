import styles from './LayoutRow.module.css';

const LayoutRow = (props) => {
    return (
        <div className={styles.LayoutRow}>
            {props.children}
        </div>
    );
};

export default LayoutRow;