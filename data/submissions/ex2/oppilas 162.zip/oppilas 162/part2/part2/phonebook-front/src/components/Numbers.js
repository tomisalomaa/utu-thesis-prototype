import React from 'react';

const Numbers = (props) => {
  return(
    <ul>
      {props.persons.map(person => 
      <li key={person.name}>
        <div>
          {person.name} {person.number}
          <button value={person.id} onClick={props.handleEntryDelete} >poista</button>
        </div>
      </li>)}
    </ul>
  )
}

export default Numbers