import React from 'react';
import axios from 'axios';
import Form from './components/Form'
import Numbers from './components/Numbers'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }

  addNumber = (event) => {
    event.preventDefault()
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    const names = this.state.persons.map(person => person.name)
    if (!names.includes(this.state.newName)) {
      axios
        .post('http://localhost:3001/persons', personObject)
        .then(response => {
          this.setState({ 
            persons: this.state.persons.concat(response.data),
            newName: '',
            newNumber: ''
          })
        })
    }
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  handleEntryDelete = (event) => {
    const personToDelete = this.state.persons.find(p => p.id == event.target.value)

    if(window.confirm(`Poistetaanko ${personToDelete.name}`)) {
      axios
        .delete(`http://localhost:3001/persons/${event.target.value}`)
        .then(response => {
          this.setState({
            persons: this.state.persons.filter(p => p.id != event.target.value)
          })
        })
    }
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form addNumber={this.addNumber} newName={this.state.newName} newNumber={this.state.newNumber}
          handleNameChange={this.handleNameChange} handleNumberChange={this.handleNumberChange} />
        <h2>Numerot</h2>
        <Numbers persons={this.state.persons} handleEntryDelete={this.handleEntryDelete} />
      </div>
    )
  }
}

export default App