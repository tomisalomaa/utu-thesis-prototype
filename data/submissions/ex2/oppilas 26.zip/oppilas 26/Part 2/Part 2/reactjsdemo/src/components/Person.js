import React from 'react'

const Person = (props, deletePerson) => {
    return (
      <div>{props.name}  {props.number} <button onClick={props.deletePerson}>Poista</button></div>
    )
  }

  export default Person