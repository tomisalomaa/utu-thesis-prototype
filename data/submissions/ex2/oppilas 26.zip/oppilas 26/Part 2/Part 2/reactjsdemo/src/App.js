import React, { useState, useEffect } from "react"
import NewPerson from "./components/AddPerson"
import Persons from "./components/Persons"
import personsDB from "./services/PersonsDB"
import Notification from "./components/Notification"

const App = () => {
  const [persons, setPersons] = useState([])
  const [uusiNimi, setNewName] = useState("")
  const [uusiNumero, setNewNumber] = useState("")
  const [newSearch, setNewSearch] = useState("")
  const [errorMessage, setErrorMessage] = useState(null)

  const handleNameChange = event => {
    setNewName(event.target.value)
  }

  const handleNumberChange = event => {
    setNewNumber(event.target.value)
  }

  const handleSearchChange = event => {
    setNewSearch(event.target.value)
  }

  const handleDeletePerson = (name, id) => {
    return () => {
      if (window.confirm("Poistetaanko ${name}")) {
        personsDB
          .deletePerson(id)
          .then(() => {
            setPersons(persons.filter(n => n.id !== id))
            setNewName("")
            setNewNumber("")
          })
          .catch(error => {
            setPersons(persons.filter(n => n.name !== name))
          })
        setTimeout(() => {
          setErrorMessage(null)
        }, 5000)
      }
    }
  }

  useEffect(() => {
    personsDB.getAll().then(response => {
      setPersons(response)
    })
  }, [])

  const addPerson = event => {
    event.preventDefault()

    const personObject = {
      name: uusiNimi,
      number: uusiNumero,
      id: Math.floor(Math.random() * 101)
    }

    if (
      persons.filter(person => person.name === personObject.name).length > 0
    ) {
      if (
        window.confirm(
          "${ personObject.name } on puhelinluettelossa jo."
        )
      ){
        const previousPerson = persons.find(n => n.name === uusiNimi)
        personsDB
          .update(previousPerson.id, { ...previousPerson, number: uusiNumero })
          .then(updatedPerson => {
            setPersons(
              persons.map(n => (n.name === uusiNimi ? updatedPerson : n))
            )
          })
      }
    } else {
      personsDB
        .create(personObject)
        .then(uusiHenkilö => {
          setPersons(persons.concat(uusiHenkilö))
          setNewName("")
          setNewNumber("")
        })
        .catch(error => {
          setErrorMessage("${error.response.data.error}")
          console.log(error.response.data)
        })
      setTimeout(() => {
        setErrorMessage(null)
      }, 5000)
    }
  }

  return (
    <div>
      <h1>Puhelinluettelo</h1>
      <Notification message={errorMessage} />
      
      <NewPerson
        uusiNimi={uusiNimi}
        uusiNumero={uusiNumero}
        handleNameChange={handleNameChange}
        handleNumberChange={handleNumberChange}
        addPerson={addPerson}
      />
      <h2>Numerot</h2>
      <Persons
        persons={persons}
        newSearch={newSearch}
        handleDeletePerson={handleDeletePerson}
      />
    </div>
  )
}

export default App