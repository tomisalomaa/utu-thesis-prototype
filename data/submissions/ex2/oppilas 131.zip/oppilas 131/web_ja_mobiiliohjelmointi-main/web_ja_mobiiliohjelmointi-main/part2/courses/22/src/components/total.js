import React from 'react';

const Total = ({ course }) => {
  const exercises = course.parts.map((part) => part.exercises);

  return (
    <div>
      <p>Total: {exercises.reduce((a, b) => a + b, 0)}</p>
    </div>
  );
};

export default Total;
