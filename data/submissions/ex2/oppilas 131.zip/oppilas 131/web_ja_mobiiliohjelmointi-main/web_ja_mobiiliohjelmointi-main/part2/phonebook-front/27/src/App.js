import React from 'react';
import Form from './components/form';
import Person from './components/person';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      persons: [{ name: 'Arto Hellas', number: '040 123456' }],
      newName: '',
      newNumber: '',
    };
  }

  addPerson = (event) => {
    event.preventDefault();
    if (
      this.state.persons.find(
        (person) => person.name.toUpperCase() === this.state.newName.toUpperCase()
      )
    ) {
      alert(`${this.state.newName} on jo luettelossa!`);
      this.setState({ persons: this.state.persons, newName: '', newNumber: '' });
      return;
    }
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber,
    };
    const persons = this.state.persons.concat(personObject);
    this.setState({
      persons,
      newName: '',
      newNumber: '',
    });
  };

  handlePersonChange = (event) => {
    this.setState({ newName: event.target.value });
  };

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value });
  };

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form
          state={this.state}
          addPerson={this.addPerson}
          handleNumberChange={this.handleNumberChange}
          handlePersonChange={this.handlePersonChange}
        />
        <h2>Numerot</h2>
        {this.state.persons.map((person) => (
          <Person key={person.name} person={person} />
        ))}
      </div>
    );
  }
}

export default App;
