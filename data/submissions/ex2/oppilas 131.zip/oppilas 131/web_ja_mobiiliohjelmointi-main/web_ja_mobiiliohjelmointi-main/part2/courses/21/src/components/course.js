import React from 'react';
import Header from './header';
import Contents from './contents';

const Course = ({ course }) => {
  return (
    <div>
      <Header course={course} />
      <Contents course={course} />
    </div>
  );
};

export default Course;
