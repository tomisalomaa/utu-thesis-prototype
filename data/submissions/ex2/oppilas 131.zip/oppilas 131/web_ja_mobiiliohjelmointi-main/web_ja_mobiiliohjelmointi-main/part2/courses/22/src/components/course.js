import React from 'react';
import Header from './header';
import Contents from './contents';
import Total from './total';

const Course = ({ course }) => {
  return (
    <div>
      <Header course={course} />
      <Contents course={course} />
      <Total course={course} />
    </div>
  );
};

export default Course;
