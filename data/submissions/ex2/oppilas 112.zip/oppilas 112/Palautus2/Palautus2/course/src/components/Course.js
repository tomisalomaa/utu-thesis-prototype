import React from 'react'

const Course = ({course}) => {
  
    return (
      <div>
        <Header course={course} />
        <Contents course={course} />
        <Total course={course} />
      </div>
    )
  }
  const Header = ({course}) => {
    return (
      <div>
        <h1>{course.name}</h1>
      </div>
    )
  }
  
  
  const Part = ({course}) => {
    return (
      <div>
           {course.parts.map((course) =><p key={course.name}> {course.name} {course.exercises}</p>)}
      </div>
    )
  }
  
  const Contents = ({course}) => {
  
    return (
      <div>
        <Part course = {course} />
      </div>
    )
  }
  
  const Total = ({course}) => {
    return (
      <div>
        <p>Total: {course.parts.reduce((osittaisSumma, a) => osittaisSumma + a.exercises, 0)}</p>
      </div>
    )
  }

export default Course