import React from 'react'

const Course = ({course}) => {
    return (
      <ul>
        <Header course={course}/>
        <Contents course={course}/>
        <Total course={course}/>
      </ul>
    )
  }
  
  const Header =  ({course}) => {
    return (
        <div><h1>{course.name}</h1></div>
    )
  }
  
  const Contents = ({course}) => {
    return (
      course.parts.map(part => <Part key={part.id} part={part}/>)
    )
  }
  
  
  const Part = ({part}) => {
    return (
      <div>
        {part.name} {part.exercises}
      </div>
    )
  }
  
  const Total = ({course}) => {
    var totalAmount = course.parts.reduce(function(sum, exercise) {
      return sum + exercise.exercises
    }, 0)
  
    
    return (
      <div>
        <p>Total: {totalAmount}</p>
      </div>
    );
  }


export default Course