import axios from "axios"
import React from "react"

const Form = (props) => {
return(
  <div>
    <form onSubmit={props.addNimi}>
          <div>
            nimi: <input value={props.newName}
            onChange={props.nimenAnto}/>
            </div><div>
            numero: <input value={props.newNum}
            onChange={props.numeronAnto}/>


          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        </div>
)
}

const Numerot = (props) => {
  const people = props.numerot
  console.log(people)

  return(
    <div>
    <h2>Numerot</h2>
        <ul>
          {people.map(person=><p key={person.name}>{person.name}: {person.number}</p>)}
        </ul>
    </div>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNum:''
    }
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(res => {
        this.setState({persons: res.data})
      })
  }

  addNimi = (event)=> { 
    event.preventDefault()
    console.log("nappi painettu")
    console.log(event.target)
    const person = {
      name: this.state.newName,
      num: this.state.newNum
    }
    if(this.state.persons.map(person=>person.name).includes(person.name)){
      alert(person.name+ " on jo lisätty")
    }
    else{
    const persons = this.state.persons.concat(person)
    this.setState({
      persons:persons,
      newName:"",
      newNum:""
    })
  }
  
  

  }
  nimenAnto = (event) => {
    console.log(event.target.value)
    this.setState({newName: event.target.value})
  }
  numeronAnto = (event) => {
    console.log(event.target.value)
    this.setState({newNum: event.target.value})
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form addNimi={this.addNimi} newName={this.newName} nimenAnto={this.nimenAnto} newNum={this.newNum} numeronAnto={this.numeronAnto}/>
        <Numerot numerot={this.state.persons}/>
      </div>
    )
  }
}

export default App