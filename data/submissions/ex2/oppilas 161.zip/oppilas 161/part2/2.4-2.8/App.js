import React from 'react'
import Info from './Info'
import Form from './Form'
import axios from 'axios'

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      persons: [],
      newName: '',
      newNum: ''
    }
  }
  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }
  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }
  handleNumChange = (event) => {
    this.setState({ newNum: event.target.value })
  }
  addName = (event) => {
    event.preventDefault()
    const nameNumber = {name: this.state.newName, number: this.state.newNum}
    let checkName = this.state.persons.find(e => e.name === nameNumber.name)
    let checkNumber = this.state.persons.find(e => e.number === nameNumber.number)
    if ((checkName !== undefined || checkNumber !== undefined) || (checkName !== undefined && checkNumber !== undefined)) {
        alert('Name or number match');
        this.setState({
          newName: '',
          newNum: ''
        })
    } else{
      const newInfo = this.state.persons.concat(nameNumber)
      this.setState({
        persons: newInfo,
        newName: '',
        newNum: ''
      })
    }
  }

  render() {
    return (
      <div>
        <h2>Telephone Directory</h2>
        <Form newName={this.state.newName} newNum={this.state.newNum} addName={this.addName}
          handleNameChange={this.handleNameChange} handleNumChange={this.handleNumChange}/>
        <h2>Numbers</h2>
        <ul>
          {this.state.persons.map(e => <Info keyid={e.name} name={e.name} number={e.number}/>)}
        </ul>
      </div>
    )
  }
}
export default App;