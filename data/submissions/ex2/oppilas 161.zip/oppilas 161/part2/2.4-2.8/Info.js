import React from 'react'

const Info = ({keyid, name, number }) => {
  return (
    <li key={keyid}>{name} {number}</li>
  )
}

export default Info;