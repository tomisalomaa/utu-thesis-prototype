import React from 'react';

const Names = ({ names, clickToRemove }) => {
  return (
    <tr>
      <td>{names.name}</td><td>{names.number}</td><td><button onClick={clickToRemove}>poista</button></td>
    </tr>
  )
}

export default Names