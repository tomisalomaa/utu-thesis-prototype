import React from 'react'


const Course = (props) => {
    return (
  
      <div>
        <Header course = {props.course.name} />
        <Contents parts = {props.course.parts} />
        <Total parts = {props.course.parts} />
      </div>
    )
  }
  
  const Header = (props) => {
    return (
      <div>
        <h1>{props.course}</h1>
      </div>
    )
  }
  
  const Contents = (props) => {
    return (
  
      <div>
        {/* vanha taulukko
        <Part partsi={props.parts[0].name} tehtavat={props.parts[0].exercises} />
        <Part partsi={props.parts[1].name} tehtavat={props.parts[1].exercises} />
        <Part partsi={props.parts[2].name} tehtavat={props.parts[2].exercises} />
        */}
  
        <Part partsi = {props.parts.map(part => <p key={part.id}>{part.name}{part.exercises}</p>)} />
        
      </div>
    )
  }
  
  //1.2
  const Part = (props) => {
    return (
  
      <div>
        <p>{props.partsi} {props.tehtavat}</p>
      </div>
    )
  }
  //2.1 ->
  const Total = (props) => {
    let sum = 0;
    props.parts.map(exercise => sum += exercise.exercises)
    return (
  
      <div>
        <p>Total: {sum}</p>
      </div>
    )
  }

  export default Course