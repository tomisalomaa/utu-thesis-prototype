import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

const courses = [
  {
    id: 1,
    name: 'Basics of React',
    exercises: 8
  },
  {
    id: 2,
    name: 'Using props',
    exercises: 10
  },
  {
    id: 3,
    name: 'Component states',
    exercises: 11
  }
]


ReactDOM.render(
  <App courses={courses} />,
  document.getElementById('root')
)
