import React from 'react'

const Part = ({ part }) => {
  return (
    <li key={part.id}>{part.name} {part.exercises}</li>
  )
}

const Course = (props) => {
    const { course } = props
    // const rivit = () => course.parts.map(part => <li key={part.id}>{part.name} {part.exercises}</li>)
    return (
      <div>
        <h1>{course["name"]}</h1>
        <ul>
          {course.parts.map( part => <Part part={part}/>)}
        </ul>
        <p>Total {course.parts[0].exercises + course.parts[1].exercises + course.parts[2].exercises} exercises</p>
      </div>
    )
  }


export default Course