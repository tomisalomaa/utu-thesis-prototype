import React from 'react'

const Course = (props) =>{
    return(
      <div>
        <Header course = {props.course}/>
        <Contents course = {props.course}/>
        <Total course = {props.course}/>
      </div>
    )
  }
  const Header = (props) => {
    return (
      <div>
        <h1>{props.course.name}</h1>
      </div>
    )
  }
  const Contents = (props) => {
    return (
      <div>
        {props.course.parts.map(nimi =><Part key = {nimi.name} name = {nimi.name} exercises = {nimi.exercises} />)}
      </div>
    )
  }
  const Total = (props) => {
    return (
      <div>
        <p>Total: {props.course.parts.reduce((total, current) => total + current.exercises, 0)} </p>
      </div>
    )
  }
  const Part = (props) =>{
    return(
      <div>
        <p>{props.name} {props.exercises}</p>
      </div>
    )
  }
export default Course