import React from 'react';

const Form = (props) => {
  return(
    <div>
      <form onSubmit={props.addName}>
        <div>
          nimi: <input value={props.newName} onChange = {props.handleNameChange}/>
        </div>
        <div>
          numero: <input value={props.newNumber} onChange = {props.handleNumberChange}/>
        </div>
        <div>
          <button type="submit">lisää</button>
        </div>
        </form>
    </div>
    )
}

const List = (props) => {
  return(
    <div>
      <table>
      <tbody>
        <tr>
          <td>{props.persons.map(nimi => <div key={props.getKey()} >{nimi.name}</div>)}</td>
          <td>{props.persons.map(numero => <div key={props.getKey()} >{numero.number}</div>)}</td>
        </tr>
      </tbody>
      </table>
    </div>

  )
}


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { name: 'Arto Hellas' ,
         number: '040-1234567'} 
      ],
        newName: '',
        newNumber: ''
      }
    this.keyCount = 0;
    this.getKey = this.getKey.bind(this);
  }

  getKey(){
    return this.keyCount++;
  }
  addName = (event) => {
    event.preventDefault()
    if (this.state.persons.some(person => this.state.newName === person.name)) {
      alert('Tämä nimi löytyy jo.')
    }else {
        const nameObject = {
          name: this.state.newName,
          number: this.state.newNumber
        }
        const persons = this.state.persons.concat(nameObject)
  
      this.setState({
        persons: persons,
        newName: '',
        newNumber: ''
      })
    }
  }

  handleNameChange = (event) => {
    this.setState({newName: event.target.value})
  }
    
  handleNumberChange = (event) => {
    this.setState({newNumber: event.target.value})
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form addName = {this.addName} newName = {this.state.newName} handleNameChange = {this.handleNameChange} handleNumberChange = {this.handleNumberChange} newNumber = {this.state.newNumber}/>
        <h2>Numerot</h2>
        <List getKey = {this.getKey} persons = {this.state.persons}/>
      </div>
    )
  }
}

export default App