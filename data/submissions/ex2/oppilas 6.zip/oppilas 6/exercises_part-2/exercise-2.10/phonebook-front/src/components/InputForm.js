import React from "react";

const InputForm = (props) => {
  return (
    <form onSubmit={props.addPerson}>
      <div>
        nimi: <input 
          value={props.state.newName}
          onChange={props.handleNameChange}
        />
      </div>
      <div>
        numero: <input 
          value={props.state.newNumber}
          onChange={props.handleNumberChange}
        />
      </div>
      <div>
        <button type="submit">lisää</button>
      </div>
    </form>
  )
}

export default InputForm