import React from 'react';
import PersonList from './components/PersonList';
import InputForm from './components/InputForm';
import personService from './services/persons';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    personService
      .getAll()
      .then(response => {
        this.setState({ persons: response })
      })
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  addPerson = (event) =>{
    event.preventDefault()
    if (this.state.persons.filter(person => person.name === this.state.newName).length > 0) {
      window.alert("Kyseinen nimi on jo puhelinluettelossa")
      return
    }
    
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    personService
      .create(personObject)
      .then(newPerson => {
        this.setState({
          persons: this.state.persons.concat(newPerson),
          newName: '',
          newNumber: ''
        })
      })

  }

  removePerson = (id) => {
    return () => {
      const person = this.state.persons.find(p => p.id === id)
      
      if (window.confirm(`Poistetaanko ${person.name}?`)) {
        personService.remove(id)
          
        this.setState({ 
          persons: this.state.persons.filter(p => p.id !== id) 
        })
          
      }

    }
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <div>
          <InputForm
            state={this.state}
            addPerson={this.addPerson}
            handleNameChange={this.handleNameChange}
            handleNumberChange={this.handleNumberChange}
          />
        </div>
        <h2>Numerot</h2>
        <div>
          <PersonList 
            persons={this.state.persons}
            removePerson={this.removePerson}
          />
        </div>
      </div>
    )
  }
}

export default App
