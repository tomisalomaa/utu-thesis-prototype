import React from 'react';
import PersonList from './components/PersonList';
import InputForm from './components/InputForm';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { 
          name: 'Arto Hellas',
          number: '040-123456' 
        }
      ],
      newName: '',
      newNumber: ''
    }
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  addPerson = (event) =>{
    event.preventDefault()
    if (this.state.persons.filter(person => person.name === this.state.newName).length > 0) {
      window.alert("Kyseinen nimi on jo puhelinluettelossa")
      return
    }
    
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    const persons = this.state.persons.concat(personObject)

    this.setState({
      persons: persons,
      newName: '',
      newNumber: ''
    })
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <div>
          <InputForm this={this}/>
        </div>
        <h2>Numerot</h2>
        <div>
          <PersonList persons={this.state.persons}/>
        </div>
      </div>
    )
  }
}

export default App
