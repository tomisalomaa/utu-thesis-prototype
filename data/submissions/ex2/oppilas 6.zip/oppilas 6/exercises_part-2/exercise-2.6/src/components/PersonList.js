import React from "react"

const PersonList = ({ persons }) => {
  return (
    <table>
      <tbody>
        {persons.map(person => <Person key={person.name} person={person} />)}
      </tbody>
    </table>
  )
}

const Person = ({ person }) => {
  return (
  <tr>
    <td>{person.name}</td>
    <td>{person.number}</td>
  </tr>
  )
}

export default PersonList