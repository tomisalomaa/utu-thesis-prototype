import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
 


/*const Total = (props) => {
  return (
    <div>
      <p>Total {props.parts[0].exercises + props.parts[1].exercises + props.parts[2].exercises} exercises</p>
    </div>
  )
}*/




ReactDOM.render(
  <App />,
  document.getElementById('root')
)