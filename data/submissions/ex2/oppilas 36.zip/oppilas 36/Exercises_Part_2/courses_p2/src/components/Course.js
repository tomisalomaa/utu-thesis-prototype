import React from "react"

const Course = ({course}) => {
    return (
      <div>
        <Header name={course.name} />
        <Content parts={course.parts}/>
        <Total parts={course.parts}/>
      </div>
    )
}
  
const Header = ({name}) => {
    return <h1>This courses nameth is {name}</h1>;
}
  
const Total = ({parts}) => {
    var sum = parts.reduce((preVal, curVal) => preVal + curVal.exercises, 0)
    return (
      <p>Total numb'r of ex'rcises: {sum}</p>
    )
}
  
const PART = ({part}) => {
    return (
      <p>{part.name} hast numb'r of {part.exercises} ex'rcises</p>
    )
}
  
const Content = ({parts}) => {
    return (
      <div>
        {parts.map((part) => (<PART key={part.id} part={part} />))}
      </div>
    )
}

export default Course