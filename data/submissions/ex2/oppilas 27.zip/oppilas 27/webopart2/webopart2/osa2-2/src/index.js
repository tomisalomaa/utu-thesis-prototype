import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import axios from 'axios'






function Rivit(props) {
  return (
    <p>{props.person.name} {props.person.numero}</p>
  );
}

const Header = (props) => {
  return (
    <h2>{props.h}</h2>
  )
}



class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [], 
      newName: '',
      newNumero: ""
    }
  }

  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3001/api/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  addNote = (event) => {
    event.preventDefault()
    const exists = this.state.persons.find(player => player.name === this.state.newName)
    if (exists) {
      console.log('already on list!');
    } else {
      const noteObject = {
        name: this.state.newName,
        numero: this.state.newNumero
      }
    
      
    axios.post('http://localhost:3001/api/persons', noteObject)
      .then(response => {
        console.log(response)
        this.setState({
          persons: this.state.persons.concat(response.data),
          newName: '',
          newNumero: ''
        })
      })
      }
    
  }

  

  handleNoteChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
  }

  handleNumChange = (event) => {
    console.log(event.target.value)
    this.setState({ newNumero: event.target.value })
  }
  


  render() {
    return (
      <div>
        <Header h="Puhelinluettelo"/>
        <form onSubmit={this.addNote}>
          <div>
            nimi: <input value={this.state.newName}
            onChange={this.handleNoteChange}
            />
            
          </div>
            numero: <input value={this.state.newNumero}
              onChange={this.handleNumChange}
              />
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <Header h="Numerot"/>
        {this.state.persons.map((person, i) => <Rivit key={i} person={person}/>)}
      </div>
    )
  }
}

export default App


ReactDOM.render(
  <App />,
  document.getElementById('root')
)
