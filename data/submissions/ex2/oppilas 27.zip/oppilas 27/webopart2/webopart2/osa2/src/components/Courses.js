import React from 'react'


const Rivit = (props) => {
    return(
      <p>{props.course.name} {props.course.exercises}</p>
    )
  }

  export default Rivit