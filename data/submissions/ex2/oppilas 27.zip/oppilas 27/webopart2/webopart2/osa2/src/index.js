import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import reportWebVitals from './reportWebVitals';
import Rivit from './components/Courses';

const Header = (props) => {
  return (
    <div>
      <h1> {props.he}</h1>
    </div>
  )
}





const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8,
        id: 1
      },
      {
        name: 'Using props',
        exercises: 10,
        id: 2
      },
      {
        name: 'Component states',
        exercises: 12,
        id: 3
      }
    ]
  }
  

 
  const total = () => course.parts.map(part => part.exercises)
  
  return (
    <div>
      <Header he={course.name}/>
      <ul>
        {course.parts.map(part => <Rivit key={part.id} course={part}/>)}
        <p>total {total()[0]+total()[1]+total()[2]}</p>
      </ul>
      
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)