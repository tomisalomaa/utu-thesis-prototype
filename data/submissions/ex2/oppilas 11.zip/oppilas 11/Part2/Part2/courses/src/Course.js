const Course = (props) => {
    let total = 0
    for(let i=0; i<props.course.parts.length; i++){
      total+=props.course.parts[i].exercises
    }
  
    return (
      <div>
        <h1>{props.course.name}</h1>
        <p>
          {props.course.parts.map(course => <li key={course.id}>{course.name} {course.exercises}</li>)}
        </p>
        <p>Total: {total}</p>
      </div>
    )
  
    
  }

  export default Course