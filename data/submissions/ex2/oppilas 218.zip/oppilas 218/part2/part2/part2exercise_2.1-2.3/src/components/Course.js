import React from 'react'

const Header = (props) => {
    return (
      <div>
        <h1> {props.course} </h1>
      </div>
    )
  }
  
  const Contents = (props) => {
    return (
      <div>
        <Part exercise={props.parts.map(part => <p key={part.id}> The part is named "{part.name}" and it contains {part.exercises} exercises!</p>)}/>
      </div>
    )
  }
  
  const Part = (props) => {
    return (
      <div>
        {props.exercise}
      </div>
    )
  }
  
  const Total = (props) => {
    let total = 0
    for (let i=0; i<props.parts.length; i++) {
        total += props.parts[i].exercises
    }
    return (
      <div>
        <p>The total amount of exercises is {total}!</p>
      </div>
    )
  }
  
  const Course = (props) => {
    return (
      <div>
        <Header course={props.course} />
        <Contents parts={props.parts} />
        <Total parts={props.parts}/>
      </div>
    )
  }

export default Course