import React from 'react'
import ReactDOM from 'react-dom'
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: '',
    }
  }

  componentDidMount() {
    axios.get('http://localhost:3001/persons')
    .then(response => {
      this.setState({persons: response.data})
    })
  }

  addNameAndNumber = (event) => {
    event.preventDefault()
    const object = {
      name: this.state.newName,
      number: this.state.newNumber,
      id: this.state.persons.length + 1
    }

    if (!(this.state.persons.filter(name => name.name === this.state.newName).length > 0)) {
      axios.post('http://localhost:3001/persons', object)
      .then(response => {
        this.setState({
          persons: this.state.persons.concat(response.data),
          newName: '',
          newNumber: ''
        })
      })
      } else {
        alert("The phonebook already contains the name!")
      }
    }
  
  handleNameChange = (event) => {
    this.setState({newName: event.target.value})
  }

  handleNumberChange = (event) => {
    this.setState({newNumber: event.target.value})
  }

  removeNameAndNumber = (event) => {
    event.preventDefault()
    //axios.delete('http://localhost:3001/persons/'+ id?)
    .then(response => {
      window.confirm("Are you sure you want to delete?");
      this.setState({
        persons: this.state.persons
      })
    })
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.addNameAndNumber} onReset={this.removeNameAndNumber}>
            <Input value={'nimi'} put={<input value={this.state.newName} onChange={this.handleNameChange}/>}/>
            <Input value={'numero'} put={<input value={this.state.newNumber} onChange={this.handleNumberChange}/>}/>
          <div>
            <button type="submit">Lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
          <List list={this.state.persons.map(name => <p key={name.id}>{name.name} {name.number} <button onClick={this.removeNameAndNumber} >Poista</button></p>)}/>
      </div>
    )
  }
}

export default App

const Element = ({props, removeNameAndNumber}) => {
  return (
    <div>
      <p>{props.name} {props.number}</p>
      <button onClick={removeNameAndNumber}></button>
    </div>
  )
}

const Input = (props) => {
  return (
    <div>
      Kirjoita {props.value}: {props.put}
    </div>
  )
}

const List = (props) => {
  return (
    <div>
      {props.list} {props.button}
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)