import React from 'react'
import ReactDOM from 'react-dom'

const Course = (props) => {
  let tehtavienMaara = 0
  let kurssinNimi = <h1>{props.course.name}</h1>
  let osat = props.course.parts.map(osa => <p key={osa.id}>{osa.name} {osa.exercises}</p>)
  let totals = props.course.parts.map(tehtavat => tehtavat.exercises)
  totals.forEach(element => {tehtavienMaara += element})
  return(
    <div>
      {kurssinNimi}
      {osat}
      <p>Total: {tehtavienMaara}</p>
    </div>
    )
}

export default Course