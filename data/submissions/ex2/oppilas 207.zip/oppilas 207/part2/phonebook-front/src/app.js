import React from 'react';
import Ihminen from "./components/ihminen"

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { name: 'Arto Hellas' }
      ],
      newName: ''
    }
  }

  lisaaNimi = (event) =>{
    event.preventDefault()
    const nameObject = {
      name: this.state.newName
    }

    const persons = this.state.persons.concat(nameObject)

    this.setState({
      persons: [
        { name: 'Arto Hellas' }
      ],
      newName: ''
    })
  }

  handlePersonsChange = (event) => {
    console.log(event.target.value)
    this.setState({newName: event.target.value})
  }

  render() {
    console.log(this.state.persons)
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <ul>
          {this.state.persons.map(ihminen => <Ihminen key={ihminen.name} ihminen={ihminen} />)}
        </ul>
        <form onSubmit={this.lisaaNimi}>
          <div>
            nimi: <input
              value={this.state.newName}
              onChange={this.handlePersonsChange}  
            />
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
      </div>
    )
  }
}

export default App