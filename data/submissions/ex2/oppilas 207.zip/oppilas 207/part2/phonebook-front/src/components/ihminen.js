import React from 'react'
import ReactDOM from 'react-dom'

const Ihminen = (ihminen) => {
    console.log(ihminen)
    //let ihmiset = ihminen.map(osa => <p key={ihminen.name}>{ihminen.name}</p>)
    let nimiReturn = <p>{ihminen.name}</p>
  return(
    nimiReturn
  )
}

export default Ihminen