import React from 'react'

const Form = ({ name, number, changeName, changeNumber, onSubmit }) => (
  <form onSubmit={onSubmit}>
    <div className='padded'>
      nimi: <input value={name} onChange={changeName} />
    </div>
    <div className='padded'>
      numero: <input value={number} onChange={changeNumber}/>
    </div>
    <div className='padded'>
      <button type="submit">lisää</button>
    </div>
  </form>
)

export default Form
