import React from 'react';
import Entry from './components/Entry';
import Form from './components/Form';
import personService from './services/persons';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    personService
      .getAll()
      .then(persons => {
        this.setState({ persons })
      })
  }

  containsName = (name) => {
    return this.state.persons.some(p => p.name === name)
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  addContact = (event) => {
    event.preventDefault()
    if (this.containsName(this.state.newName)) {
      return
    }
    const newPerson = {
      name: this.state.newName,
      number: this.state.newNumber
    }
    personService
      .create(newPerson)
      .then(person => {
        this.setState({
          persons: this.state.persons.concat(person),
          newName: '',
          newNumber: ''
        })
      })
  }

  removeContact = (id, name) => () => {
    if (!window.confirm(`Poistetaanko ${name}?`)) {
      return
    }
    personService
      .remove(id)
      .then(response => {
        this.setState({
          persons: this.state.persons.filter(p => p.id !== id)
        })
      })
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form 
          name={this.state.newName}
          number={this.state.newNumber}
          changeName={this.handleNameChange}
          changeNumber={this.handleNumberChange}
          onSubmit={this.addContact}
        />
        <h2>Numerot</h2>
        <table>
          <tbody>
            {this.state.persons.map(p => 
              <Entry 
                key={p.id} 
                person={p} 
                remove={this.removeContact(p.id, p.name)}
              />
            )}
          </tbody>
        </table>
      </div>
    )
  }
}

export default App
