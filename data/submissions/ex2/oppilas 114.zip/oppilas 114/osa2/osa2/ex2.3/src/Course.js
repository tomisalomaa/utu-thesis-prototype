import React from 'react'

const Part = (props) => {
    return (
      <div>
        {props.name} {props.exercises}
      </div>
    )
  }
  
  const Contents = (props) => {
    return (
      props.parts.map(part => <Part key={part.id} name={part.name} exercises={part.exercises}/>)
    )
  }
  
  const Header = (props) => {
    return (
      <h1>
        {props.name}
      </h1>
    )
  }
  
  const Total = (props) => {
    const reducer = (previousValue, currentValue) =>  {
      if(typeof  previousValue.exercises !== "undefined") {
        return (
          previousValue.exercises + currentValue.exercises
        )
      }
      else {
        return (
          currentValue.exercises
        )
      }
    }
  
    return (
      <div>
        Total: {props.parts.reduce(reducer)}
      </div>
    )
  }
  
  const Course = (props) => {
    return (
      <div>
        <Header name={props.course.name}/>
        <Contents parts={props.course.parts}/>
        <Total parts={props.course.parts}/>
      </div>
    )
  }

  export default Course;