import React from 'react'

const AddContact =({addPerson, newPerson, newNumber, handleNumberChange, handlePersonChange}) => {
    return (
        <div>
            <h2>Lisää yhteystieto</h2>
            <form onSubmit={addPerson}>
                Nimi: 
                <input value={newPerson} onChange={handlePersonChange}/>
                <br></br>
                Numero: 
                <input value={newNumber} onChange={handleNumberChange}/>
                <br></br>
                <button type="submit">tallenna</button>
            </form>
        </div>
    )
}

export default AddContact