import React from "react";
import Person from './Person'

const Display = ({persons, deletePerson}) => {
    return (
        <div>
            <table>
            {persons.map(person => 
                <Person key={person.id} person={person} deletePerson={deletePerson(person.id)} />
            )}
        </table>
      </div>
    )
}

export default Display