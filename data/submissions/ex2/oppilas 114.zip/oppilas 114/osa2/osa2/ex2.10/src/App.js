import React, { useState, useEffect } from 'react'
import AddContact from './components/AddContact'
import Display from './components/Display'
import axios from 'axios'

const App = () => {
  const [persons, setPersons] = useState([])
  const [newPerson, setNewPerson] = useState('')
  const [newNumber, setNewNumber] = useState('')

  useEffect(() => {
    console.log('effect')
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        setPersons(response.data)
      })
  }, [])
  console.log('render', persons.length, 'notes')

  const addPerson = (event) => {
    event.preventDefault()
    const personObject = {
      name: newPerson,
      number: newNumber
      }
  
    axios.post('http://localhost:3001/persons', personObject)
      .then(response => {
        console.log(response)
        window.location.reload();
      })
  }

  const handlePersonChange = (event) => {
    console.log(event.target.value)
    setNewPerson(event.target.value)
  }

  const handleNumberChange = (event) => {
    console.log(event.target.value)
    setNewNumber(event.target.value)
  }

  const deletePerson = (id) => () => {
    if (window.confirm(`Haluatko varmasti poistaa yhteystiedon ${JSON.parse(JSON.stringify(persons.find(person => person.id===id))).name}`)) {
      axios.delete(`http://localhost:3001/persons/${id}`)
      .then(response => {
        console.log(response)
      })
    }
  }

  return (
    <div>
      <h1>Puhelinluettelo</h1>   
      <Display persons={persons} deletePerson={deletePerson}/>
      <AddContact addPerson={addPerson} newPerson={newPerson} newNumber={newNumber} handleNumberChange={handleNumberChange} handlePersonChange={handlePersonChange} /> 
    </div>
  )
}

export default App