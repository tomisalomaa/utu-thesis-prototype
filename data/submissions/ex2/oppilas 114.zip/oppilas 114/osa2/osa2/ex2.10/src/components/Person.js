import React from 'react'

const Person = ({ person, deletePerson }) => {
  return (
    <tbody>
      <tr>
        <td>{person.name}</td>
        <td>{person.number}</td>
        <td><form onSubmit={deletePerson}><button type="submit">poista</button></form></td>
      </tr>
    </tbody>
  )
}

export default Person