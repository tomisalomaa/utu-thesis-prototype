import React from 'react'

function Part(props){
    return<p>{props.part} {props.exercises}</p>
}
export default Part;