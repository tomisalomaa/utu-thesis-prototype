import React from 'react'

function Total(props){
    return(<p>Total {props.parts.reduce((total, curr)=> total = total + curr.exercises,0)} exercises</p>);
}
export default Total;