import React from 'react'
import Header from "./Header.js"
import Contents from "./Contents.js"
import Total from "./Total.js"

function Course(props){
    return(
      <div>
    <Header course={props.name} />
    <Contents parts={props.parts}/>
    <Total parts={props.parts}/>
    </div>
    );
  }

export default Course;