import React from 'react'
import Part from "./Part.js"

function Contents(props){
    return(<div>
        {props.parts.map(prt=><Part part={prt.name} exercises={prt.exercises} />)}

    </div>);
}
export default Contents;