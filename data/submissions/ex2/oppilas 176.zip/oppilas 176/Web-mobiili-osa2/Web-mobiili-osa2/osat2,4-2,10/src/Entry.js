import React from 'react';

function Entry(prop){

    function handleClick(){
        if(window.confirm("Haluatko varmasti poistaa: " + prop.name)){
            prop.delete(prop.id);
        }
        
    }

    return(
        <tr>
        <td key={prop.name + " name"}>{prop.name}</td><td key={prop.number + " numero"}>{prop.number}</td><td><button onClick={handleClick}>Poista</button></td>
        </tr>
    );
}

export default Entry;