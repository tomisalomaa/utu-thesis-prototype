import React from 'react'

const Course = ({ course }) => {
    return (
      <div>
      <Header course={course} />
      <Contents parts={course.parts} />
      <Total parts={course.parts}/>
      </div>  
    )
    
  }
  
  const Header = ({ course }) => {
    return (
      <div>
      <h1>{course.name}</h1>
      </div>
    )
  }
  
  const Contents = ({ parts }) => {
    return (
      <div>
        {parts.map(parts=><Part key={parts.id} parts={parts} />)}
      </div>
    )
  }
  
  const Part = ({ parts }) => {
    return (
      <div>
      <p>{parts.name} {parts.exercises} </p>
      </div>
    )
  }
  
  const Total = ({ parts }) => {
    return (
      <div>
       <p> Total: {parts.map(parts=>parts.exercises).reduce((a, b) => a + b, 0)} </p>
      </div>
    )
  }
  

export default Course
