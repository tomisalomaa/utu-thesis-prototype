import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8,
        id: 1
      },
      {
        name: 'Using props',
        exercises: 10,
        id: 2
      },
      {
        name: 'Component states',
        exercises: 12,
        id: 3
      }
    ]
  }

  return (
    <div>
      <Course course={course} />
    </div>
  )
}

const Course = ({ course }) => {
  return (
    <div>
    <Header course={course} />
    <Contents parts={course.parts} />
    </div>
  )
}

const Header = ({ course }) => {
  return (
    <div>
    <h1>{course.name}</h1>
    </div>
  )

}

const Contents = ({ parts }) => {
  return (
    <div>
      {parts.map(parts=><Part key={parts.id} parts={parts}/>)}
    </div>
  )

}

const Part = ({ parts }) => {
  return (
    <div>
    <p>{parts.name} {parts.exercises} </p>
    </div>
  )

}


ReactDOM.render(
  <App />,
  document.getElementById('root')
)
