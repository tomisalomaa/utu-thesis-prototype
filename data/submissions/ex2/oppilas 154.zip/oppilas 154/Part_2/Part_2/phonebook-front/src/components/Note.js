import React from 'react'

const Note = ({ note }) => {
    console.log(note);
  return (
    <p>{note.name}</p>
  )
}

export default Note
