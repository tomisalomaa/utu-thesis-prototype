import React from 'react'

const NoteRow = ({ note }) => {
  return (
    <tr>
    <td>{note.name}</td>
    <td>{note.number}</td>
    </tr> 
  )
}

export default NoteRow
