import React from 'react';
import Note from './components/Note'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { name: 'Arto Hellas' }
      ],
      newName: ''
    }
  }

  addName = (event) => {
    event.preventDefault()
    console.log('nappia painettu', this.state.newName);
    const checkList = this.state.persons.map(persons=>persons.name);
    console.log(checkList)

// Check for duplicates

    if (checkList.includes(this.state.newName)) {
      alert("Virhe: Nimi on jo listassa.");

    }
    else {
        const Name = {
          name: this.state.newName
        }
      const persons = this.state.persons.concat(Name)
    
      this.setState({
        persons: persons,
        newName: ''
      })
    }
  }

  handleNameChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
  }
  
  render() {
    <div>
      debug: {this.state.newName}
    </div>
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.addName}>
        
          <div>
            nimi: <input
            value={this.state.newName}
            onChange={this.handleNameChange}
          />
          </div>
          <p></p>
          <div>
            <button type="submit">Lisää nimi</button>
          </div>
        </form>
        <h2>Numerot</h2>
        <ul>
        {this.state.persons.map(note => <Note key={this.state.persons.name} note={note} />)}
      </ul>
      </div>
    
    )
  }
}

export default App
