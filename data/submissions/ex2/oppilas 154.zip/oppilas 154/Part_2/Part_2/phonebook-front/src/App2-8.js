import React from 'react';
import axios from 'axios'
import NoteRow from './components/NoteRow'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
      // { name: 'Arto Hellas', number: '040-123456' }
      ],
      newName: '',
      newNumber: ''
    }
    console.log('constructor')
  }

  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  addName = (event) => {
    event.preventDefault()
    console.log('nappia painettu', this.state.newName);
    const checkList = this.state.persons.map(persons=>persons.name);
    console.log(checkList)

    // Check for duplicates

    if (checkList.includes(this.state.newName)) {
      alert("Virhe: Nimi on jo listassa.");

    }
    else {
        const NameNumber = {
          name: this.state.newName, number: this.state.newNumber
        }

      const persons = this.state.persons.concat(NameNumber)
    
      this.setState({
        persons: persons,
        newName: '',
        newNumber: ''
      })
    }
  }

  handleNameChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value })
  }
  
  render() {
    console.log('render')
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.addName}>
        
          <div>
            nimi: <input
            value={this.state.newName}
            onChange={this.handleNameChange}
          />
          </div>
          <div>
            numero: <input
            value={this.state.newNumber}
            onChange={this.handleNumberChange}
          />
          </div>
          <p></p>
          <div>
            <button type="submit">Lisää tiedot</button>
          </div>
        </form>

        <h2>Numerot</h2>     
        <table>
        <tbody>
        {this.state.persons.map(note => <NoteRow key={this.state.persons.name} note={note} />)}
        </tbody>
        </table>
      </div>
    
    )
  }
}

export default App
