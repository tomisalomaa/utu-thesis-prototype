import React from 'react'
import axios from 'axios'
//import Form from './components/Form'
import Person from './components/Person'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: ''
    }
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }

  addPerson = (event) => {
    event.preventDefault()
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    const result = this.state.persons.find( ({ name }) => name === this.state.newName  )

    if(typeof result !== 'undefined')
    {
      alert('Nimi löytyy jo. Ei voi lisätä.')
    }
    else
    {
      //const persons = this.state.persons.concat(personObject)
      axios
        .post('http://localhost:3001/persons', personObject)
        .then(newName => {
          this.setState({
            persons: this.state.persons.concat(personObject),
            newName: '',
            newNumber: ''
        })
      })
    }
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  delPerson = (name) => {
    return () => {
      console.log(name)
      const id = 6
      axios
        .delete(`http://localhost:3001/persons/${id}`)
    }
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.addPerson}>
          <div>
            nimi: <input
                    value={this.state.newName}
                    onChange={this.handleNameChange}
                  />
          </div>
          <div>
            numero: <input
                      value={this.state.newNumber}
                      onChange={this.handleNumberChange}
                    />
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
        <table>
          <tbody>
          {this.state.persons.map(person =>
              <Person
                key={person.name}
                person={person}
                poistaPersoona={this.delPerson(person.name)}
              />)}
          </tbody>
        </table>
      </div>      
    )
  }
}

export default App
