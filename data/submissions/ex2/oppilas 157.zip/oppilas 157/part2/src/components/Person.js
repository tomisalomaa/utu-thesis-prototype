import React from 'react'

const Person = ({person, poistaPersoona}) => {
    return (
        <tr>
            <td>{person.name}</td>
            <td>{person.number}</td>
            <td><button onClick={poistaPersoona}>poista</button></td>
        </tr>
    )
}

export default Person