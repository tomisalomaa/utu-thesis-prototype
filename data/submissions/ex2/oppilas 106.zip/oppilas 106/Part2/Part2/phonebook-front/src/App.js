import React from 'react';
import Person from './Person';
import axios from 'axios';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { name: 'Arto Hellas' }
      ],
      newName: '',
      newNumber: '',
      id: 0
    }
  }

  componentDidMount() {
    console.log('did mount') 
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data})
      })
  }

  addPerson = (event) => {
    event.preventDefault()
    console.log('new person added')
    console.log(event.target)
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber,
      id: this.state.persons[this.state.persons.length - 1].id + 1
    }

    const persons = this.state.persons.concat(personObject)

    if (this.state.persons.some(x => x.name === personObject.name)) {
      alert("Henkilö on jo luettelossa.")
    } else {
      axios
        .post('http://localhost:3001/persons', personObject)
        .then(response => {
          console.log(response)
          this.setState({
            persons: persons,
            newName: '',
            newNumber: '',
            id: 0
          })
        })
    }
  }

  handleNameChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
      
  }

  handleNumberChange = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value })
      
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.addPerson}>
          <div>
            nimi: <input 
              value={this.state.newName} 
              onChange={this.handleNameChange}
            />
          </div>
          <div>
            numero: <input 
              value={this.state.newNumber} 
              onChange={this.handleNumberChange}
              />
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
        <table>
          <tbody>
            {this.state.persons.map(person => 
              <Person 
                key={person.name} name={person.name}
                number={person.number} id={person.id}
              />)}
          </tbody>
        </table>
      </div>
    )
  }
}

export default App