import React from 'react'

const Header = ({course}) => {
  return (
    <div>
      <h1>{course}</h1>
    </div>
  )
}

const Part = ({part}) => {
  return (
    <p>{part.name} {part.exercises}</p>
  )
}

const Contents = ({parts}) => {
  return (
    <div>
      {parts.map((part, i) => <Part key={i} part={part} />)}
    </div>
  )
}

const Total = ({parts}) => {
  let sum = 0
  parts.forEach((part) => {
    sum = sum + part.exercises
  });

  return (
    <p>Total {sum} exercises</p>
  )
}

const Course = ({course}) => {
  return (
    <div>
      <Header course={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
  )
}

export default Course
