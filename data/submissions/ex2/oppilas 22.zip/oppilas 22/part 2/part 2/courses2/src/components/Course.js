import React from 'react'

const Course = (c) => {
    const stuff = c.course.parts
    var tot = 0;
    for (let i = 0; i < stuff.length; i++) {
    tot += stuff[i].exercises}
    return(
      <div>
        <h1> {c.course.name} </h1>
        <ul>
          {stuff.map(s => <p key={s.id}>{s.name} {s.exercises}</p>)}
        </ul>
        <ul>
        <p>Total: {tot}</p>
        </ul>
      </div> 
    )
  }
  export default Course