import React from 'react'
import ReactDOM from 'react-dom'

class Course extends React.Component {
    render() {
      return (
        <div class="coursecontainer">
          <h1>{this.props.course.name}</h1> 
          {this.props.course.parts.map(
            element => (
            <p>{element.name} : {element.exercises}</p>
            )
          )
          }
          <p>Total: <Exerciseamount course={this.props.course} /></p>
        </div>
      );
    }
  }
  
  class Exerciseamount extends React.Component {
    render() {
      return (
        this.calculateExercises(this.props.course.parts)
      );
    }
  
    calculateExercises(array)
    {
      let count = 0;
      array.forEach(element => {
        count = count + element.exercises;
      });
      return count;
    }
  }

export default Course