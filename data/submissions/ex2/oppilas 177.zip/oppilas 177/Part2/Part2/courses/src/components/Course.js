import React from 'react'

const Total = (props) => {
    // Lasketaan yhteen osien harjoitusmäärät
    const result = props.parts.reduce((total, currentValue) => total = total + currentValue.exercises,0);
    return (
      <div>
        <p>Total {result} exercises</p>      
      </div>
    )
  }
  
  const Header = (props) => {
    return (
      <div>
        <h1>{props.course}</h1>
      </div>
    )
  }
  
  const Contents = (props) => {
    return (
      <div>
      {props.parts.map((part, i) => (
          <Part key={part.id} part = {part} />
        ))}
      </div>
    )
  }
  
  const Course = (props) => {
    return (
      <div>
        <Header course={props.course.name} />
        <Contents parts = {props.course.parts} />
        <Total parts = {props.course.parts} />
      </div>
    )
  }
  
  const Part = (props) => {
    return (
      <div>
        <p>{props.part.name} {props.part.exercises}</p>
      </div>
    )
  }

  export default Course