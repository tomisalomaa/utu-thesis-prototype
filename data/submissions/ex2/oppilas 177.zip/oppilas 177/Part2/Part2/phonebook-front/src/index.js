import React from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  addPerson = (e) => {
    e.preventDefault()
    if(this.state.persons.some(person => person.name == this.state.newName))
    {
      this.setState({persons: this.state.persons,newName:'',newNumber:''});
      alert('Henkilö löytyy jo');
    }
    else {
        const person = {name: this.state.newName, number: this.state.newNumber};
        
        axios
        .post('http://localhost:3001/persons', person)
        .then(response => {
          const tmpPersons = this.state.persons.concat(response.data);
          this.setState({persons: tmpPersons,newName:'',newNumber:''});
        })
    }
  }

  removePerson = (e,person) => {
      e.preventDefault()
      if(window.confirm('Poistetaanko henkilö ' + person.name))
      {
          axios
          .delete('http://localhost:3001/persons/' + person.id)
          .then(response => {
            const tmpPersons = this.state.persons.filter(function(person2) { return person2 !== person });

              this.setState({persons: tmpPersons,newName: '',newNumber: ''});
          })
      }
  }

    setNameNumber = (newName,newNumber) => {
        this.setState({
          persons: this.state.persons, 
            newName,
            newNumber
        })
    }

    componentDidMount() {
        axios
          .get('http://localhost:3001/persons')
          .then(response => {
            this.setState({ persons: response.data })
          })
      }

  render() {
    return (
      <div>
        <PersonsForm state = {this.state} setNameNumber = {this.setNameNumber} addPerson={this.addPerson}/>
        <Persons state = {this.state} removePerson = {this.removePerson}/>
      </div>
    )
  }
}

const PersonsForm = (props) => {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={props.addPerson}>
          <div>
            nimi: <input value={props.state.newName}
          onChange ={(e) => props.setNameNumber(e.target.value, props.state.newNumber)}/> 
          </div>
          <div>
            numero: <input value={props.state.newNumber}
          onChange={(e) => props.setNameNumber(props.state.newName, e.target.value)}/> 
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
      </div>
    )
}

const Persons = (props) => {
    return (
    <div>
    <h2>Numerot</h2>
    <table> 
        <tbody>
            {props.state.persons.map(person => 
            <tr key={person.id}>
                <td>{person.name}</td>
                <td>{person.number}</td>
                <td><button onClick={(e) => props.removePerson(e,person)}>poista</button></td>
            </tr>)}
        </tbody>
    </table>
    </div>)
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)