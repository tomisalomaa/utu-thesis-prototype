import React from 'react'
import ReactDOM from 'react-dom'

const course = [
  {
    name: 'Basics of React',
    exercises: 8,
    id:1
  },
  {
    name: 'Using props',
    exercises: 10,
    id:2
  },
  {
    name: 'Component states',
    exercises: 12,
    id:3
  }
]

const Course = ({ course }) =>{
  return(
    <li>{course.name}</li>
  )
}

const App = () => {
  return (
    <div>
      <h1>Superadvanced web and mobile programming</h1>
      <ul>
        {course.map(course =>
          <Course key={course.id} course={course} />
        )}
      </ul>
      <p>Total 30 exercises</p>
    </div>
  )
}

ReactDOM.render(
  <App course={course}/>,
  document.getElementById('root')
)