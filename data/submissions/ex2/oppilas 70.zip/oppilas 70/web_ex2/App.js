import React, { useState, useEffect } from 'react'
import axios from 'axios'

    const App = (props) => {
        const [persons, setPersons] = useState([])
        const [newName, setNewName] = useState(
          'a new name...'
        ) 
        const [newNumber, setNewNumber] = useState(
          'a new number...'
        )

        useEffect(() => {
          console.log('effect')
          axios
            .get('http://localhost:3001/persons')
            .then(response => {
              console.log('promise fulfilled')
              setPersons(response.data)
            })
          }, [])
        console.log('render', persons.length, 'persons')
  
    const addName = (event) => {
      event.preventDefault()
      const noteObject = {
        name: newName,
        number: newNumber,
        id: persons.length + 1,
      }
    

    setPersons(persons.concat(noteObject))
    setNewName('')
    setNewNumber('')
  }

  const handleNameChange = (event) => {
    console.log(event.target.value)
    setNewName(event.target.value)
    if (persons.some((person) => person.name === event.target.value)) {
      alert("Name exist! Please stop adding!");
      return
    }
  }

  const handleNumberChange = (event) => {
    console.log(event.target.value)
    setNewNumber(event.target.value)
    if (persons.some((person) => person.number === event.target.value)) {
      alert("Number exist! Please stop adding!");
      return
    }
  }
  
    
      return (
        <div>
          <h2>Puhelinluettelo</h2>
          <form onSubmit={addName}>
            <div>
              nimi: 
              <input 
              value={newName}
              onChange={handleNameChange}
              />
            </div>
            <div>
              numero: 
              <input 
              value={newNumber}
              onChange={handleNumberChange}
              />
            </div>
            <div>
              <button type="submit">lisää</button>
            </div>
          </form>
          <h2>Numerot</h2>
          <ul>
            {persons.map(person =>
              <Person key={person.id} person={person} />
              )}
          </ul>
        </div>
      )
    }
  export default App