import React from 'react'

const Header = (props) => {
    return(
    <div>
      <h1>{props.course.name}</h1>
    </div>
    )
}

const Contents = (props) =>{
    const  parts = props.parts;
    const lines = () => parts.map(part => <p key={part.id}>{part.name} {part.exercises}</p>)
  
    return (
      <div>
        {lines()}
      </div>
    )
}

const Total = (props) => {
    var total = 0
    for( let i = 0; i < props.parts.length; i++){
      total += props.parts[i].exercises;
    }
    return(
      <div>
        <p>Total: {total} exercises</p>
      </div>
    )
}

const Course = (props) => {
    return (
      <div>
        <Header course={props.course}/>
        <Contents parts={props.course.parts}/>
        <Total parts={props.course.parts}/>
      </div>
    )
}

export default Course