import React from 'react';
import Formi from './components/Formi'
import Display from './components/Display'
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }
  componentDidMount() {
    console.log('did mount')
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        console.log('promise fulfilled')
        this.setState({ persons: response.data })
      })
  }

  handleNameChange = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
  }
  handleNumberChange = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value })
  }

  addPerson = (event) => {
    event.preventDefault()
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    const names = this.state.persons.map(person => person.name)
    const numbers = this.state.persons.map(person => person.number)

    if(!names.includes(personObject.name) & !numbers.includes(personObject.number)){
    
    axios.post('http://localhost:3001/persons', personObject)
    .then(response => {
      this.setState({
        persons: this.state.persons.concat(response.data),
        newName: '',
        newNumber: ''
      })
    })
    }
}

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
          <Formi persons={this.state.persons} handleNameChange={this.handleNameChange} 
          handleNumberChange={this.handleNumberChange} addPerson={this.addPerson}
          newName={this.state.newName} newNumber={this.state.newNumber} />
        
        <h2>Numerot</h2>
        <Display persons={this.state.persons}/>
      </div>
    )
  }
}

export default App