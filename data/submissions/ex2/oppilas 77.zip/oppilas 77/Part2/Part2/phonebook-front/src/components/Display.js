import React from 'react'

const Display = (props) =>{
    
    return(
        <div>
        {props.persons.map(person => <li key={person.name}>{person.name} {person.number}</li>)}
        </div>
    )
}

export default Display