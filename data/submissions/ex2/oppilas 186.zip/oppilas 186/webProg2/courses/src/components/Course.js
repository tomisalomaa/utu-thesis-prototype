const Course = ({course}) => {
    return (
      <div>
        <Header name={course.name}/>
        <Contents parts={course.parts}/>
      </div>
    )
  }
  const Header = ({name}) => <div><h1>{name}</h1></div>
  const Contents = ({parts}) => {
    const osat = () => parts.map( (p, i) => <Part part={parts[i]}/>)
    
  
    return (
      <div>
        {osat()}
        <Total parts={parts}/>
      </div>
    )
  }
  const Part = ({part}) => <div>{part.name}, {part.exercises}</div>
  const Total = ({parts}) => {
    let sum = 0
    parts.forEach(p => sum += p.exercises)
    return(
      <div>
        Total: {sum}
      </div>
    )
  }

  export default Course