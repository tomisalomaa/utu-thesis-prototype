import React from "react";

const Form = ({nameVal, numberVal, onNameChng, onNumChng, onSbmt}) => {
    
    return(
        <div>
            <form onSubmit={onSbmt}>
            <div>
                nimi: <input value={nameVal} onChange={onNameChng}/>
            </div>
            <div>
                numero: <input value={numberVal} onChange={onNumChng}/>
            </div>
            <div>
                <button type="submit">lisää</button>
            </div>
            </form>
        </div>
    )
}

export default Form