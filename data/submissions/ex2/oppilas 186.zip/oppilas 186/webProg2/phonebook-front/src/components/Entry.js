import React from 'react'

const Entry = ({name, number, handle}) => {
    return(
        <div>
            {name}  {number} <button onClick={handle}>poista</button>
        </div>
    )
}

export default Entry