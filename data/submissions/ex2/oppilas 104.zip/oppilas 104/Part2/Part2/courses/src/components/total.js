const Total = (props)=> {
    let totals = 0
    props.parts.forEach((part)=>{
        totals = totals + part.exercises
    })
    return (
        <div>
            Total number of exercises {totals}
        </div>
    )
}
export default Total