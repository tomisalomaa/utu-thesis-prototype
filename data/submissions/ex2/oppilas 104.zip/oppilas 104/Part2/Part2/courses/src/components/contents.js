import Part from "./part";

const Contents = (props)=> {
    return (
        <div>
            {props.parts.map((p)=>{
                return(
                    <Part key={p.name} name={p.name} exercises={p.exercises}>

                    </Part>
                )



            })}
        </div>
    )
}
export default Contents