import Contents from "./contents";
import Header from "./header";
import Total from "./total";

const Course = (props) => {
    const course = props.course

    return (
        <div>
            <Header course={course.name} />
            <Contents parts={course.parts} />
            <Total parts={course.parts}/>
        </div>
    )
}

export default Course;
