import React from "react";

const List = (props) => {
    const name = "Puhelinluettelo"
    const persons = props.persons

    return (
        <div>
            <h2>{name}</h2>
            <table>
                <tbody>
                {persons.map((person)=>{
                    return(
                        <tr key={person.name} >
                            <td>{person.name}</td>
                            <td>{person.number}</td>
                            <td><button onClick={()=>props.onDelete(person.id)}>Delete</button></td>
                        </tr>
                    )

                })}
                </tbody>
            </table>
        </div>
    )
}
export default List;