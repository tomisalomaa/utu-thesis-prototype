import React from 'react';
import Header from "./components/Header"
import List from "./components/List"
import axios from "axios";

class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            persons: [
            ],
            newName: '',
            newPhone: ""
        }
        this.onInputChange = this.onInputChange.bind(this)
        this.onSubmit = this.onSubmit.bind(this)
        this.onPhoneInputChange = this.onPhoneInputChange.bind(this)
        this.onDelete = this.onDelete.bind(this)
    }
    componentDidMount() {
        this.refreshData()
    }

    onInputChange(event){
        this.setState({
            newName: event.target.value
        }
    )}
    onPhoneInputChange(event){
        this.setState({
                newPhone: event.target.value
            }
        )}

    onSubmit(event){
        event.preventDefault()
        let newperson = this.state.newName
        let newphone = this.state.newPhone
        let dublicate = this.state.persons.find((person)=> person.name === newperson)
        if(dublicate){
            alert("Dublicate number")
        }
        else{
            this.setState({
                persons: [
                    ...this.state.persons,
                    {
                        name:newperson,
                        number:newphone,
                    }
                ],

            },()=>{
                axios.post("http://localhost:3001/persons",{
                    name:newperson,
                    number:newphone,
                })
            })
        }

    }
    onDelete(id){
        let result = window.confirm("Are you sure you want to delete this number ?")
        if(result){
            axios.delete("http://localhost:3001/persons/"+id).then(()=>this.refreshData())
       }
    }
    refreshData(){
        const promise = axios.get("http://localhost:3001/persons")

        promise.then(response => {
            this.setState({
                persons: response.data,
            })
        })
    }

    render() {
        return (
            <div>
                <Header/>
                <form onSubmit={this.onSubmit}>
                    <div>
                        nimi: <input onChange={this.onInputChange} />
                    </div>
                    <div>
                        numero: <input onChange={this.onPhoneInputChange} />
                    </div>
                    <div>
                        <button type="submit">lisää</button>
                    </div>
                </form>
                <List persons={this.state.persons} onDelete={this.onDelete}/>
            </div>
        )
    }
}

export default App