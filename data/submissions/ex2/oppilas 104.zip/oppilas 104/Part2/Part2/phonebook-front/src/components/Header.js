
const Header = () => {
    const header = "Puhelinluettelo"

    return (
        <div>
            <h2>{header}</h2>
        </div>
    )
}
export default Header