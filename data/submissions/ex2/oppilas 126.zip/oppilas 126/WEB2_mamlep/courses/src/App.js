import React from 'react'

const App = (props) => {
    const { course } = props;


    return (
        <div>
            <Header course={course.name} />
            <Contents course={course} />
        </div>

    )
}

const Header = (props) => {

    return (
        <div>
            <h1>{props.course}</h1>
        </div>
    )
}

const Contents = (props) => {
    const { course } = props;
    return (
        <div>
            <Part course={course} />
        </div>
    )

}

const Part = (props) => {
    const { course } = props;
    return (
        <div>
            {course.parts.map(part => <p>{part.name + " " + part.exercises}</p>)}
            <p> Total: {course.parts.length} </p>
        </div>
    )
}


export default App
