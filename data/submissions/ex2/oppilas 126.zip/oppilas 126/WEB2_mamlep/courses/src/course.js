import React from 'react'

const Course = ({ course }) => {
  return (
      <li>{course.name}</li>
  )
}

export default Course