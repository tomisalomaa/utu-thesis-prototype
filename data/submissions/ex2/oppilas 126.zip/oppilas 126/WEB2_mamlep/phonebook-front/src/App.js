﻿import React from 'react';
import ReactDOM from 'react-dom'
import axios from 'axios'



class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            persons: [
                { name: 'Arto Hellas', number: '0504426890'}
            ],
            newName: '',
            newNum: ''
        }
    }

    componentDidMount() {
        console.log('did mount')
        axios
            .get('http://localhost:3001/persons')
            .then(response => {
                console.log('promise fulfilled')
                this.setState({ persons: response.data })
            })
    }

    handleNameChange = (event) => {
        console.log(event.target.value)
        this.setState({ newName: event.target.value })
    }

    handleNumChange = (event) => {
        console.log(event.target.value)
        this.setState({ newNum: event.target.value })
    }


    render = () => {
        console.log(this.state.persons.length)
        { console.log(this.state.persons) }
        return (
            <div>
                <h2>Puhelinluettelo</h2>
                <form onSubmit={this.addTo}>
                    <div>
                        nimi:
                        <input
                            value={this.state.newName}
                            onChange={this.handleNameChange}
                        />
                    </div>
                    <div>
                        numero: <input
                            value={this.state.newNum}
                            onChange={this.handleNumChange}
                        />
                    </div>
                    <div>
                        <p>{this.state.persons.name}</p>
                    </div>
                    <button type="submit">lisää</button>
                    <div>
                        debug: {this.state.newName}
                    </div>
                </form>
                <h2>Numerot</h2>
                {this.state.persons.map(pers => <li>{pers.name + " " + pers.number}
                    <button id={pers.name} >poista</button> </li>
                )}
            </div>

        )
    }

    addTo = (event) => {

        console.log(event.target)
        var exist = false
        for (let i = 0; i < this.state.persons.length; i++) {
            console.log(this.state.persons[i].name.includes(this.state.newName))
            if (this.state.persons[i].name.includes(this.state.newName) == true) {
                console.log("täällä ollaan")
                exist = true
            }
        }
        if (exist == false) {
            axios.post('http://localhost:3001/persons', { name: this.state.newName, number: this.state.newNum })
                .then(response => {
                    console.log(response)
                })
            this.state.persons.push({ name: this.state.newName, number: this.state.newNum })
        }
        ReactDOM.render(
            <React.StrictMode>
                <App />
            </React.StrictMode>,
            document.getElementById('root')
        );
        event.preventDefault()
    }
}


export default App