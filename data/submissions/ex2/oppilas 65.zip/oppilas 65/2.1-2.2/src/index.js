import React from 'react'
import ReactDOM from 'react-dom'
const App = (parts) => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8,
        id: 1
      },
      {
        name: 'Using props',
        exercises: 10,
        id: 2
      },
      {
        name: 'Component states',
        exercises: 12,
        id: 3
      }
    ]
    
  }
  const total = course.parts.reduce((a, b) => a = a + b.exercises,0);

  return (
    <div>
      <h1>{course.name}</h1>
      <ul>
        {course.parts.map(part => <p>{part.name} {part.exercises}</p>)}
        <p>Total: {total}</p>
      </ul>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)