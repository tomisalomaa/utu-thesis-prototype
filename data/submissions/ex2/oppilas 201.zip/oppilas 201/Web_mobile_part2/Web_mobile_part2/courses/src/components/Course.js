import React from "react"

const Course = ({ course }) => {
    return(
      <div>
        <Header name={course.name} />
        <Contents course={course.parts} />
        <Total exercise={course.parts} />
      </div>
    )
  }
  
  const Header = (course) => {
    return(
      <div>
        <h1>{course.name}</h1>
      </div>
    )
  }
  
  const Part = ({ part }) => {
    return(
      <div>
        <p>{part.name} {part.exercises}</p>
      </div>
    )
  }
  
   const Contents = ({ course }) => {
      return(
        <div>
          {course.map(part => <Part key={part.id} part={part}/>)}
        </div>
        )
      }
  
  const Total = ({ exercise }) => {
    return(
      <div>
        <p>Total: {exercise.reduce((a,b) => a + b.exercises, 0)}</p>
      </div>
  
    )
  }

  export default Course