import React from 'react';
import ReactDOM from 'react-dom';
import axios from "axios";

const LisääTieto = (tieto) => {
  return(
    <div>
      {tieto.nimi}: <input name={tieto.name}
      value={tieto.value}
      onChange={tieto.onChange}/>
    </div>
  )
}

const LuoForm = (tieto) => {
  return(
    <form onSubmit={tieto.onSubmit}>
      <LisääTieto nimi={tieto.nimi} name={tieto.name}
        value={tieto.value}
        onChange={tieto.onChange}
      />
    </form>
  )
}

const Numerot = ({ number,poistaYhteistieto }) => {
  return(
    <div>
      <p>{number.name} {number.number} <button onClick={poistaYhteistieto}>poista</button></p>
    </div>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: "",
      newNumero: ""
    }
    console.log("constructor")
  }

  lisääYhteystieto = (event) => {
    event.preventDefault()
    const yhteistieto = {
      name: this.state.newName,
      number: this.state.newNumero
    }

    const person = this.state.persons.find(person => person.name === yhteistieto.name)

    if (person){
      alert("Nimi on jo lisätty yhteistietoihin")
      return
    }

    axios
      .post("http://localhost:3001/persons", yhteistieto)
      .then(response => {
        this.setState({
          persons: this.state.persons.concat(response.data),
          newName: "",
          newNumero: ""
        })
      })
      

    console.log("nappia painettu")
    console.log(event.target)
  }

  muutaYhteystietoa = (event) => {
    console.log(event.target.value)
    this.setState({ [event.target.name]: event.target.value })
  }

  componentDidMount() {
    console.log("did mount")

    axios
      .get("http://localhost:3001/persons")
      .then(response => {
        console.log("promise fulfilled")
        this.setState({ persons: response.data })
      })
  }

  poistaYhteistieto =  ( id ) => {
      const url = `http://localhost:3001/persons/${id}`
      const yhteistieto = this.state.persons.find(p => p.id === id)

      if(window.confirm(`Poistetaanko ${yhteistieto.name}`)){
        
         axios
          .delete(url,yhteistieto)
          .then(
            this.setState({
              persons: this.state.persons,
              newName:"",
              newNumero: ""
            },
            this.componentDidMount)
        )
      }
  }

  render(){
    console.log("render")
    return(
      <div>
        <h2>Puhelinluettelo</h2>
        <LuoForm onSubmit={this.lisääYhteystieto} nimi="Nimi" name="newName" value={this.state.newName}
         onChange={this.muutaYhteystietoa}/>
         <LuoForm onSubmit={this.lisääYhteystieto} nimi="Numero" name="newNumero" value={this.state.newNumero}
         onChange={this.muutaYhteystietoa}/>
         <div>
           <button type="submit">lisää</button>
         </div>
        <h2>Numerot</h2>
          {this.state.persons.map(persons => <Numerot key={persons.name} number={persons} id={persons.id} poistaYhteistieto={() => this.poistaYhteistieto(persons.id)}/>)}
      </div>
    )
  }
}

export default App

ReactDOM.render(
    <App />,
  document.getElementById('root')
);