import React from 'react'
import ReactDOM from 'react-dom'
import Course from './components/Course'

const App = () => {
  
  
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8,
        id: 1
      },
      {
        name: 'Using props',
        exercises: 10,
        id: 2
      },
      {
        name: 'Component states',
        exercises: 12,
        id: 3
      }
      

    ]  
  }
  /**Aikasemman viikon tehtävät muutettu kommentoiksi koska ei toimintoa */

//   const Header = (props) => (
//     <div>
//       <h1>{props.course.name}</h1>
      
//     </div>
    
//   )
  
//   const Contents = (props) => (
//     <div>
//       <Part name={props.contents.parts[0].name} exercises={props.contents.parts[0].exercises} />
//       <Part name={props.contents.parts[1].name} exercises={props.contents.parts[1].exercises} />
//       <Part name={props.contents.parts[2].name} exercises={props.contents.parts[2].exercises} />
//     </div>
//   )
//   const Part = (props) => (
//     <div>
//       <p>{props.name} {props.exercises}</p>
//     </div>
//  )

 
  return (
    <div>
      <Course course={course} />
    </div>
  )
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)

