import React from 'react'

const Course = (props) => {
  const {course} = props;

  const courses = () =>  course.parts.map(course => 
    
    <div key={course.id}>
      {course.name} {course.exercises}
    </div>
  )

  const summa = () => {
  let total = 0
  course.parts.map((course) => total += course.exercises)
  return total
}
  return (
    
    <div>
      <h1>{course.name}</h1>
      {courses()}
      <p>Total: {summa()}</p>
    </div>  
  )
}


export default Course