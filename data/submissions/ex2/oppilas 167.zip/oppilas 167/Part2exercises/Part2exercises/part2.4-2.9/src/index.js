
import React from 'react';
import ReactDOM from 'react-dom'
import Print from './components/Print'
import axios from 'axios'

  // saveInfo yritetty jakaa omaksi komponentiksi mutta ei saatu toimimaan joten vain näkymän tulostus omana komponenttina
  // Part 2.10, toimintoa poistaa entryjä ei tehty.


class App extends React.Component{
  constructor(props) {
    super(props)
    
    this.state = {
      persons: [],   
      newName: '',
      newNumber: ''
  
    }
  }
  componentDidMount() {
    axios
      .get('http://localhost:3001/persons')
      .then(response => {
        this.setState({ persons : response.data })
  })}
  
  eventHandler = (event) => {  
    this.setState(
      {[event.target.id]:event.target.value})
  }
  
 
  
  saveInfo = (event) => {
    
      event.preventDefault()         
      const tiedot= {
        name: this.state.newName,
        number: this.state.newNumber
      }
      if (this.state.persons.some(name => name.name === this.state.newName)) {
        alert('Nimi lisätty jo')
      }
      else {
        axios
    .post('http://localhost:3001/persons', tiedot)
    .then(response => {
      this.setState({
        persons : this.state.persons.concat(response.data),
        newNote: ''
      })
    })
}}

  
  render() {
    return (
      <div>
        
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.saveInfo}>
          <div>
            nimi: <input id="newName" value={this.state.newName} onChange={this.eventHandler} />
          </div>
          <div>
            numero: <input id="newNumber" value={this.state.newNumber} onChange={this.eventHandler} />
          </div>
          <div>
            
          </div>
          <div>
            <button type="submit" onClick={this.onPostDelete}>lisää</button>
          </div>
        </form>
         <div>
            {Print(this.state)}
          </div>
        </div>
    )
  }
  
}


ReactDOM.render(<App />, document.getElementById('root'))
export default App