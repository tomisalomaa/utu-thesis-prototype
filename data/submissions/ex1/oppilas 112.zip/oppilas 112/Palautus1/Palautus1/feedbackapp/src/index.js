import React from 'react';
import ReactDOM from 'react-dom';

const Header = (props) => {
  return (
    <div>
      <h1>{props.teksti}</h1>
    </div>
  )
}

const Statistic = (props) => {
  return (
    <tr>
      <td>{props.teksti}</td>
      <td>{props.counter}</td>
    </tr>
  )
}

const Average  = (props) => {
  var x = (props.hy - props.hu)/(props.hy + props.hu + props.ne)
  return (
    <tr>
      <td>Keskiarvo</td>
      <td>{x.toFixed(2)}</td>
    </tr>
  )
}

const Positive  = (props) => {
  var x = 100*(props.hy)/(props.hy + props.hu + props.ne)
  return (
    <tr>
      <td>Positiivisia</td> 
      <td>{x.toFixed(1)}%</td>
    </tr>
  )
}

const Button = (props) => (
  <button onClick={props.handleClick}>
    {props.teksti}
  </button>
)
const Statistics = (props) => {
  if (props.hy === 0 & props.hu === 0 & props.ne ===0) {
    return (
      <div>
        <b>Ei yhtään palautetta annettu</b>
      </div>
    )
  }
  return(
  <table>
    <tbody>
      <Statistic teksti={"Hyvä"} counter={props.hy}/>
      <Statistic teksti={"Neutraali"} counter={props.ne}/>
      <Statistic teksti={"Huono"} counter={props.hu}/>
      <Average hy={props.hy} hu={props.hu} ne={props.ne}/>
      <Positive hy={props.hy} hu={props.hu} ne={props.ne}/>
    </tbody>
  </table>
  )
  }

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }

    
  }
  asetaHyva = (arvo) => () => this.setState({ hyva: arvo })
  asetaHuono = (arvo) => () => this.setState({ huono: arvo })
  asetaNeutraali = (arvo) => () => this.setState({ neutraali: arvo })

  render() {
    return (
      <div>
        <Header teksti={"Anna palautetta:"}/>
        <Button handleClick={this.asetaHyva(this.state.hyva + 1)}
          teksti="Hyvä"/>
        <Button handleClick={this.asetaNeutraali(this.state.neutraali + 1)}
          teksti="Neutraali"/>
        <Button handleClick={this.asetaHuono(this.state.huono + 1)}
          teksti="Huono"/>  
        <Header teksti={"Statistiikka:"}/>
        <Statistics hy = {this.state.hyva} hu = {this.state.huono} ne = {this.state.neutraali}/> 
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
