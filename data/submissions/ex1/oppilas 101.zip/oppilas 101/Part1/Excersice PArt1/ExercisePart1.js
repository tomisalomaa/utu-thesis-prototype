import React, { Component } from 'react'
import ReactDOM from 'react-dom'

const Button=({handelClick,text}) => (
  <button onClick={handelClick}>
    {text}
  </button>
)
const StatisticDisply =({hyva,neutraali,huono}) => {
  const keskiarvo = ((hyva*1+neutraali*0+huono*-1)/(hyva+neutraali+huono)+0).toFixed(1)
  const Positiviisia = ((hyva)/(hyva+neutraali+huono)*100).toFixed(1)
  if ((hyva+neutraali+huono)===0){
    return(
      <div>no feedback yet</div>
    )
  }

  return(
    <div>
      <table>
        <thead></thead>
        <tbody>
          <tr>
            <td>hyvä</td>
            <td>{hyva}</td>
          </tr>
          <tr>
            <td>neutraali</td>
            <td>{neutraali}</td>
          </tr> 
          <tr>
            <td>Huono</td>
            <td>{huono}</td>
          </tr>
          <tr>
            <td>Keskiarvo</td>
            <td>{keskiarvo}</td>
          </tr>
          <tr>
            <td>Positiivisia</td>
            <td>{Positiviisia}</td>
          </tr>
        </tbody>
      </table>
    </div>
  )

}



class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      neutraali :0,
      huono :0
    }
  }
  feedBack = (fb) => () => {
    if(fb==='hyva'){
      this.setState({ hyva: this.state.hyva +1 })
    }
    if(fb==='neutraali'){
      this.setState({ neutraali: this.state.neutraali +1 })
    }
    if(fb==='huono'){
      this.setState({ huono: this.state.huono +1 })
    }
  }
    
  render() {
    const hyva=this.state.hyva
    const neutraali=this.state.neutraali
    const huono=this.state.huono
    

    return (
      <div>
        <h2>anna palautetta</h2>
        
        <div>
          <Button handelClick={this.feedBack('hyva')} text="hyvä" />
          <Button handelClick={this.feedBack('neutraali')} text="neutraali" />
          <Button handelClick={this.feedBack('huono')} text="huono" />
       </div>
       <h2>Statistika</h2>
       <StatisticDisply hyva={hyva} neutraali={neutraali} huono={huono} />

    </div>
    )
    
  }

}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)