import React from 'react'
import ReactDOM from 'react-dom'

const Header=(props) => {
  return(
    <h2>{props.course_name}</h2>
  )
}

const Part=(props) => {
  return(
    <p>{props.partname.name} {props.partname.exercise}</p>
  )
}

const Contents=(props) => {
  return(
    <div>
      <Part partname={props.parts[0]} />
      <Part partname={props.parts[1]} />
      <Part partname={props.parts[2]} />
    </div>
  )
}

const Total=(props) =>{
  return(
    <p>Total {props.parts[0].exercise+props.parts[1].exercise+props.parts[2].exercise} </p>
  )
}

const App = () => {
  const course = {
    name:'Superadvanced web and mobile programming',
    parts : [
     {
        name:'Basics of React',
        exercise:8
      } ,
      {
        name:'Using props',
        exercise:10
      } ,
      {
        name:'Component states',
       exercise:12
      } 
    ]
  }
  return (
    <div>
      <Header course_name={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)