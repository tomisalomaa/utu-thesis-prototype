import React from 'react'
import ReactDOM from 'react-dom'
import './index.css'


const Stats = (St) =>{
  const ka = keskiarvo(St.n.good, St.n.bad)
  const pos = pros(St.n.good, St.n.neutral, St.n.bad)
  const p=St.n.good
  const n=St.n.bad
  const m=St.n.neutral
  if (p==0 && n==0 && m==0){
    return(
      <div>
      <p>No feedback yet</p>
    </div> )
    }else{
  return(
    <div>
      <p>Average:{ka}</p>
      <p>Positive:{pos}%</p>
    </div> 
  )
}}
const pros = function(a, b, c) {
  return ((a/(a+b+c))*100).toFixed(2)};
const keskiarvo = function(a, b) {
  return ((a+b*(-1))/3).toFixed(2)};

const St = (s) =>{
  const r = s.t
  if (r==0){
    return(
      <div>NaN</div>)
    }else{
    return <div>{s.t}</div>
    }
}

class App extends React.Component {
  constructor() {
  super()
  this.state = {
    h1 : 'Statistics: Give feedback',
    good : 0,
    neutral : 0,
    bad : 0
  }
}
CG = () => {
  this.setState({
    good: this.state.good + 1
  })
}
CN = () => {
  this.setState({
    neutral: this.state.neutral + 1
  })
}
CB = () => {
  this.setState({
    bad: this.state.bad + 1
  })
}

  render() {
      const info = () => this.state
    return (
      <div>
        <h1>{info().h1}</h1>
        <table> 
          <tbody>
            <tr>
            <td><button onClick={this.CG}>Good(1)</button></td>
            <td>Good: <St t={info().good}/></td>
            </tr>
            <tr>
            <td><button onClick={this.CN}>Just Fine(0)</button></td>
            <td>Neutral: <St t={info().neutral}/></td>
            </tr>
            <tr>
            <td><button onClick={this.CB}>Bad(-1)</button></td>
            <td>Bad: <St t={info().bad}/></td>
            </tr>
            <tr>
            <td></td>
            <td><Stats n={info()}/></td>
            </tr>
          </tbody>
        </table>
      </div>
    )
    }
  }
ReactDOM.render( <App />,document.getElementById('root'))