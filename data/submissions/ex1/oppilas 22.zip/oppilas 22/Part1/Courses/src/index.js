import React from 'react'
import ReactDOM from 'react-dom'

//Returns
const Header = (h) => {
  return(
    <div>
      <h1> {h.course.name} </h1>
    </div> 
  )
}
const Contents = (c) =>{
  return(
  <div>
      <Part s={c.parts} n={0}/>
      <Part s={c.parts} n={1}/>
      <Part s={c.parts} n={2}/>
  </div>
  )
}
const Part = (p) => {
  const t =p.s.parts
  return(
    <div>
      <p>{t[p.n].name} has {t[p.n].exercises} exercises</p>
    </div>
  )
}
const Total = (parts) => {
  const p =parts.parts.parts
  var tot = 0;
  for (let i = 0; i < p.length; i++) {
  tot += p[i].exercises
  }
  return(
<div>
  <p>The total number of exercises is {tot}</p>
  </div>
  )
}

//App
const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
    <Header course={course} />
    <Contents parts={course} />
    <Total parts={course} />
    </div>
    )
  
}

ReactDOM.render( <App />,document.getElementById('root'))