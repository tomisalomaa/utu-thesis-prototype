import React from 'react';
import {useState} from "react";
import Button from "./Button.js";
import Statistics from './Statistics.js';



function App(){
    const [hyvä, setHyvä] = useState(0);
    const [neutraali, setNeutraali] = useState(0);
    const [huono, setHuono] = useState(0);
    const [start, setStart] = useState(false);


    function handleClick(event){
        setStart(true);
        if(event==="hyvä"){
            setHyvä((prev)=>{
                return prev + 1;
            });
        }
        else if(event==="neutraali"){
            setNeutraali((prev)=>{
                return prev + 1;
            });
        }
        else if(event==="huono"){
            setHuono((prev)=>{
                return prev +1;
            });
        }
    }
    return(
        <div>
            <h1>anna palautetta</h1>
            <Button name="hyvä" clicked={handleClick}/>
            <Button name="neutraali" clicked={handleClick}/>
            <Button name="huono" clicked={handleClick}/>
            {!start? <div>
                <h1>statistiikka</h1>
                <p>ei yhtään palautetta annettu</p>
            </div> : <Statistics hyvä={hyvä} neutraali={neutraali} huono={huono}/>}
        </div>
    );

}
export default App;