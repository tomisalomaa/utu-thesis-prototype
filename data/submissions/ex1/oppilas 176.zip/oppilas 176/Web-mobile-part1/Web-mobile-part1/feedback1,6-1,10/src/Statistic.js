import React from 'react';

function Statistic(props){
    if(props.text==="positiivisia"){
        return(<tr><td>{props.text}</td><td>{props.calc}%</td></tr>);
    }
    else{
        return(<tr><td>{props.text}</td><td>{props.calc}</td></tr>);
    }
}

export default Statistic;