import React from 'react';
import Statistic from "./Statistic.js";

function Statistics(props){
    return(
        <div>
            <h1>statistiikka</h1>
            <table>
            <tbody>
            <Statistic text="hyvä" calc={props.hyvä} />
            <Statistic text="neutraali" calc={props.neutraali}/>
            <Statistic text="huono" calc={props.huono} />
            <Statistic text="keskiarvo" calc={((props.hyvä-props.huono)/(props.hyvä+props.huono)).toFixed(2)} />
            <Statistic text="positiivisia" calc={((props.hyvä/(props.hyvä+props.neutraali+props.huono))*100).toFixed(1)} />
            </tbody>
            </table>
        </div>
    );
}

export default Statistics;