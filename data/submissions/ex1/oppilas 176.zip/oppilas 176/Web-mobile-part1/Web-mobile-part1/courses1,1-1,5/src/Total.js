import React from 'react'

function Total(props){
    return(<p>Total {props.exercises1 + props.exercises2 + props.exercises3} exercises</p>);
}
export default Total;