import React from 'react'
import Header from "./Header.js"
import Contents from "./Contents.js"
import Total from "./Total.js"

const App = () => {

    const course = {
        name: 'Superadvanced web and mobile programming',
        parts: [
          {
            name: 'Basics of React',
            exercises: 8
          },
          {
            name: 'Using props',
            exercises: 10
          },
          {
            name: 'Component states',
            exercises: 12
          }
        ]
      }
  
    return (
      <div>
        <Header course={course.name} />
        <Contents part1={course.parts[0]} part2={course.parts[1]} part3={course.parts[2]}/>
        <Total exercises1={course.parts[0].exercises} exercises2={course.parts[1].exercises} exercises3={course.parts[2].exercises}/>
      </div>
    )
  }
  export default App;