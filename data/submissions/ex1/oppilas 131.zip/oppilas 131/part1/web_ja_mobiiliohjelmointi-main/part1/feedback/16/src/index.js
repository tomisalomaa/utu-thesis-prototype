import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      good: 0,
      neutral: 0,
      poor: 0,
    };
  }

  render() {
    return (
      <div>
        <h1>Give feedback</h1>
        <button onClick={() => this.setState({ good: this.state.good + 1 })}>Good</button>
        <button onClick={() => this.setState({ neutral: this.state.neutral + 1 })}>Neutral</button>
        <button onClick={() => this.setState({ poor: this.state.poor + 1 })}>Poor</button>
        <h1>Statistics</h1>
        <p>
          Good: {this.state.good}
          <br></br>
          Neutral: {this.state.neutral}
          <br></br>
          Poor: {this.state.poor}
        </p>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
