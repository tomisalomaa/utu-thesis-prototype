import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      good: 0,
      neutral: 0,
      poor: 0,
    };
  }

  getAverage() {
    const goodReviews = this.state.good;
    const neutralReviews = this.state.neutral;
    const poorReviews = this.state.poor;
    const totalReviews = goodReviews + neutralReviews + poorReviews;
    const average = (goodReviews - poorReviews) / totalReviews;
    if (totalReviews === 0) {
      return 0;
    }
    return average.toFixed(2);
  }

  getPositives() {
    const goodReviews = this.state.good;
    const totalReviews = goodReviews + this.state.neutral + this.state.poor;
    const positives = (goodReviews / totalReviews) * 100;
    if (totalReviews === 0) {
      return 0;
    }
    return positives.toFixed(2);
  }

  render() {
    return (
      <div>
        <h1>Give feedback</h1>
        <button onClick={() => this.setState({ good: this.state.good + 1 })}>Good</button>
        <button onClick={() => this.setState({ neutral: this.state.neutral + 1 })}>Neutral</button>
        <button onClick={() => this.setState({ poor: this.state.poor + 1 })}>Poor</button>
        <h1>Statistics</h1>
        <p>
          Good: {this.state.good}
          <br></br>
          Neutral: {this.state.neutral}
          <br></br>
          Poor: {this.state.poor}
          <br></br>
          Average: {this.getAverage()}
          <br></br>
          Positive: {this.getPositives()}%
        </p>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
