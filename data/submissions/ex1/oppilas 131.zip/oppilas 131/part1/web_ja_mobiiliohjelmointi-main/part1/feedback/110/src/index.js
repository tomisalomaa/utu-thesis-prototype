import React from 'react';
import ReactDOM from 'react-dom';

class Button extends React.Component {
  constructor() {
    super();
  }
  render() {
    return <button onClick={this.props.onClick}>{this.props.name}</button>;
  }
}

class Statistics extends React.Component {
  constructor() {
    super();
  }

  getAverage() {
    const goodReviews = this.props.state.good;
    const neutralReviews = this.props.state.neutral;
    const poorReviews = this.props.state.poor;
    const totalReviews = goodReviews + neutralReviews + poorReviews;
    const average = (goodReviews - poorReviews) / totalReviews;
    if (totalReviews === 0) {
      return 0;
    }
    return average.toFixed(2);
  }

  getPositives() {
    const goodReviews = this.props.state.good;
    const totalReviews = goodReviews + this.props.state.neutral + this.props.state.poor;
    const positives = (goodReviews / totalReviews) * 100;
    if (totalReviews === 0) {
      return 0;
    }
    return positives.toFixed(2);
  }

  render() {
    const goodReviews = this.props.state.good;
    const neutralReviews = this.props.state.neutral;
    const poorReviews = this.props.state.poor;
    const totalReviews = goodReviews + neutralReviews + poorReviews;
    return (
      <div>
        <h1>Statistics</h1>
        {totalReviews === 0 ? (
          <p>No feedback</p>
        ) : (
          <table>
            <tbody>
              <Statistic label="Good" state={this.props.state.good} />
              <Statistic label="Neutral" state={this.props.state.neutral} />
              <Statistic label="Poor" state={this.props.state.poor} />
              <Statistic label="Average" state={this.getAverage()} />
              <Statistic label="Positives" state={this.getPositives() + '%'} />
            </tbody>
          </table>
        )}
      </div>
    );
  }
}

class Statistic extends React.Component {
  constructor() {
    super();
  }
  render() {
    return (
      <tr>
        <td>{this.props.label}</td>
        <td>{this.props.state}</td>
      </tr>
    );
  }
}

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      good: 0,
      neutral: 0,
      poor: 0,
    };
  }

  render() {
    return (
      <div>
        <h1>Give feedback</h1>
        <Button onClick={() => this.setState({ good: this.state.good + 1 })} name="Good" />
        <Button onClick={() => this.setState({ neutral: this.state.neutral + 1 })} name="Neutral" />
        <Button onClick={() => this.setState({ poor: this.state.poor + 1 })} name="Poor" />
        <Statistics state={this.state} />
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
