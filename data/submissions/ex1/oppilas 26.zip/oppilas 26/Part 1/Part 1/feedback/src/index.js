//: Tässä on tehtävät 1.6 - 1.9. 
//: Tässä saattaa olla tehtävä 1.10, en ymmärtänyt täysin mitä siinä pitää tehdä. En ainakaan saa mitään erroria.

import React, { useState } from "react";
import ReactDOM from "react-dom";

const Otsikko = (props) => <h1>{props.teksti}</h1>;

const Nappi = (props) => <button onClick={props.onClick}>{props.teksti}</button>;

const Tilasto = (props) => {
  return (
    <tr>
      <td>{props.nimi}</td>
      <td>{props.arvo}</td>
    </tr>
 )
}

const Tilastot = (props) => {
  if (!props.Palaute) {
    return <p>Ei yhtään palautetta annettu</p>;
  }

  return (
    <div>
      <Otsikko teksti="Tilastot" />
      <table>
        <tbody>
          <Tilasto nimi="hyvä" arvo={props.hyvä} />
          <Tilasto nimi="neutraali" arvo={props.neutraali} />
          <Tilasto nimi="huono" arvo={props.huono} />
          <Tilasto nimi="keskiarvo" arvo={props.keskiarvo} />
          <Tilasto nimi="positiivisia" arvo={props.prosenttiPositiivisia + "%"}/>
        </tbody>
      </table>
    </div>
  )
}

const App = () => {
  
  const [hyvä, setHyvä] = useState(0);
  const [neutraali, setNeutraali] = useState(0);
  const [huono, setHuono] = useState(0);
  const [Palaute, setPalaute] = useState(false);

  const yhteensä = hyvä + neutraali + huono;

  const getPercent = (x, yhteensäLasku) => {
    let result = (x / yhteensäLasku) * 100;

    return Math.round(result * 1000) / 1000;
  }

  const prosenttiPositiivisia = getPercent(hyvä, yhteensä);

  //: 59-65 koodirivit katsottu kaverilta, sillä en ihan ymmärrä mitä siinä tapahtuu
  const getWeightedAvg = (weightsArr, yhteensä) => {
    const weights = weightsArr.reduce((acc, item) => {
      return acc + item.number * item.weight;
    }, 0
    )

    let result = weights / yhteensä;

    return Math.round(result * 1000) / 1000;
  }

  const keskiarvo = getWeightedAvg(
    [
      { number: hyvä, weight: 1 },
      { number: neutraali, weight: 0 },
      { number: huono, weight: -1 },
    ],
    yhteensä
  )

  const handleButtonClick = (type) => {
    setPalaute(true);

    switch (type) {
      case "hyvä":
        setHyvä(hyvä + 1);
        break;

      case "neutraali":
        setNeutraali(neutraali + 1);
        break;

      case "huono":
        setHuono(huono + 1);
        break;
    }
  }

  const tilastotProps = { 
  Palaute: Palaute, hyvä: hyvä, neutraali: neutraali, huono: huono, yhteensä: yhteensä, keskiarvo: keskiarvo, prosenttiPositiivisia: prosenttiPositiivisia,
  }

  return (
    <div>
      <Otsikko teksti="Anna palautetta" />
      <Nappi onClick={() => handleButtonClick("hyvä")} teksti="hyvä" />
      <Nappi onClick={() => handleButtonClick("neutraali")} teksti="neutraali" />
      <Nappi onClick={() => handleButtonClick("huono")} teksti="huono" />
      <Tilastot {...tilastotProps} />
    </div>
  )
}

ReactDOM.render(<App />, document.getElementById("root"));