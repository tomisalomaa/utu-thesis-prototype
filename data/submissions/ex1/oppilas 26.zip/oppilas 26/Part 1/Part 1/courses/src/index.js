//: tehtävät 1.1 - 1.5 "courses"

import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return(
    <div>
     <h1> {props.course.otsikko}</h1>
    </div>
  )
}

const Part = (props) => {
  return (
    <p> {props.part} {props.tehtävät}</p>
  )
}

const Contents = (props) => {
  return (
    <div>
      <Part part={props.parts[0].part} tehtävät={props.parts[0].exercises}/>
      <Part part={props.parts[1].part} tehtävät={props.parts[1].exercises}/>
      <Part part={props.parts[2].part} tehtävät={props.parts[2].exercises}/>
    </div>
  )
}

const Total = (props) => {
  return (
    <p> Total {props.parts[0].exercises + props.parts[1].exercises + props.parts[2].exercises} exercises</p>
  )
}

const App = () => {
  const course = {
    otsikko: 'Superadvanced web and mobile programming',
    parts: [
      {part: 'Basics of React', exercises: 8}, 
      {part: 'Using props', exercises: 10},
      {part: 'Component states', exercises: 12}
    ]
  }

  return (
    <div>
      <Header course={course}/> 
      <Contents parts={course.parts}/>
      <Total parts={course.parts}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)