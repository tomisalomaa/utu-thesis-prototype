import "./app.css"
import React from "react";


class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            positive:0,
            neutral: 0,
            negative: 0,
        }
    }

    render(){
        let avg = ((this.state.positive + this.state.negative*-1) / (this.state.positive + this.state.neutral + this.state.negative)).toFixed(2);
        let posper = (this.state.positive / ((this.state.positive + this.state.neutral + this.state.negative)) * 100).toFixed(2)
        let isEmpty = this.state.positive === 0 && this.state.neutral === 0 && this.state.negative === 0
        return (
            <div className="App">
                <div>
                    <header className="header">
                        Anna palautetta
                    </header>
                    <button type="button" onClick={()=>{
                        this.setState({
                            positive: this.state.positive +1
                        })
                    }}>
                        Hyvä
                    </button>
                    <button type="button" onClick={()=>{
                        this.setState({
                            neutral: this.state.neutral +1
                        })
                    }}>
                        Neutraali
                    </button>
                    <button type="button" onClick={()=>{
                        this.setState({
                            negative: this.state.negative +1
                        })
                    }}>
                        Huono
                    </button>
                </div>
                <div>
                    <header className="header">
                        Statistiikka
                    </header>
                    {isEmpty ?
                    <p>Ei yhtään palautetta ole annettu</p>
                    :
                        <table>
                            <tbody>
                                <tr>
                                    <td>
                                        Hyvä
                                    </td>
                                    <td>
                                        {this.state.positive}
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Neutraali
                                    </td>
                                    <td>
                                        {this.state.neutral}
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Huono
                                    </td>
                                    <td>
                                        {this.state.negative}
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Keskiarvo
                                    </td>
                                    <td>
                                        {avg}
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Positiivisia
                                    </td>
                                    <td>
                                        {posper}%
                                    </td>
                                </tr>
                            </tbody>
                        </table>}

                </div>

            </div>
        );
    }


}

export default App;
