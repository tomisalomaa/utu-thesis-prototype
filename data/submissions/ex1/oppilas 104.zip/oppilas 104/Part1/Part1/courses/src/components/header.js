const Header = (props)=> {
    return (
        <div>
            {props.course}
        </div>
    )
}
export default Header