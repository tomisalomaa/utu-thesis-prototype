const Total = (props)=> {
    let totals = props.parts.length
    return (
        <div>
            Total number of parts {totals}
        </div>
    )
}
export default Total