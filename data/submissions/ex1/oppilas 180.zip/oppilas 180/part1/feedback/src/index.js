import React from 'react'
import ReactDOM from 'react-dom'


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      huono: 0,
      hyva: 0,
      neutraali: 0,
      ka: 0,
    }
  }

  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      ka: this.state.ka + 1,
    })
  }

  klikHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1,
      ka: this.state.ka + 1,
    })
  }
  klikNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      ka: this.state.ka + 1,
    })
  }


  render() {
    const testi = () => {
      if (this.state.hyva>0 || this.state.huono>0 || this.state.ka>0) {
        return (
        <table>
          <tbody>
            <tr>

            <th>hyvä</th>
            <td>{this.state.hyva}</td>
            </tr>
            <tr>
            <th>neutraali</th>
            <td>{this.state.neutraali}</td>
            </tr>
            <tr>
            <th>huono</th>
            <td>{this.state.huono}</td>
            </tr>
            <tr>
            <th>keskiarvo</th>
            <td>{Math.round((((this.state.hyva+(-1*this.state.huono))/this.state.ka)*10))/10}</td>
            </tr>
            <tr>
            <th>positiivisia</th>
            <td>{Math.round(this.state.hyva/(this.state.hyva+this.state.huono+this.state.neutraali)*1000)/10}%</td>
            </tr>
         </tbody>
        </table>
      
        )
      }
      return (
        <h3>ei yhtään palautetta annettu</h3>
      )
      }
      
    return (
      <div>
        <h1>anna palautetta</h1>
        <div>
          <button onClick={this.klikHyva}>hyvä</button>
          <button onClick={this.klikNeutraali}>neutraali</button>
          <button onClick={this.klikHuono}>huono</button>
          <h1>statistiikka</h1>
          <div>{testi()}</div>
        </div>
      </div>
      
    )

  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)