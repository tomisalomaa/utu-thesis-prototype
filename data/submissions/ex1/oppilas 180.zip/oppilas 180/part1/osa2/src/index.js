import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const Header = (props) => {
    return (
      <div>
        <h1>{props.course}</h1>
      </div>
    )
  }

  const Contents = ({parts}) => {
    return (
      <div>
        <Part p1={parts[0].name} ex1={parts[0].exercises}/>
        <Part p2={parts[1].name} ex2={parts[1].exercises}/>
        <Part p3={parts[2].name} ex3={parts[2].exercises}/>
      </div>
      
    )
  }

  const Total = ({parts}) => {
    return (
      <div>
        <p>Total {parts[0].exercises+parts[1].exercises+parts[2].exercises} exercises</p>
      </div>
    )
  }

  const Part = ({p1, p2, p3, ex1, ex2, ex3}) => {
    return (
      <div>
        <p>{p1} {ex1} </p>
        <p>{p2} {ex2} </p>
        <p>{p3} {ex3} </p>
      </div>
    )
  }

  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course.name} />
      <Contents parts={course.parts}/>
      <Total parts={course.parts}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)