import React from 'react'
import ReactDOM from 'react-dom'


//Napit
const Button = (props) => {
  return(
    <div>
      <button onClick={props.button1}>{props.name1}</button>
      <button onClick={props.button2}>{props.name2}</button>
      <button onClick={props.button3}>{props.name3}</button>
    </div>
  )
}

//luo taulukon johon sijoitetaan tilastot arvoineen
const Statistics = (props) => {
  return (
    <table>
      <tbody>
        <Statistic name={props.name1} value={props.stats1} />
        <Statistic name={props.name2} value={props.stats2} />
        <Statistic name={props.name3} value={props.stats3} />
        <Statistic name={props.name4} value={props.stats4} />
        <Statistic name={props.name5} value={props.stats5} />
      </tbody>
    </table>
    )
  }

//palauttaa kentät jossa on tilaston nimi ja arvo
const Statistic = (props) => {
  return(  
    
    <tr>
      <td>{props.name}</td><td>{props.value}</td>
    </tr>
    
  )
}



class App extends React.Component {
  constructor() {
    super()
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0,
      total: 0,
      averagecounter: 0,
      mainheader: 'anna palautetta',
      statisticsheader: 'statistiikka',
      goodtext: 'Hyvä ',
      neutraltext: 'Neutraali ',
      badtext: 'Huono ',
      averagetext: 'Keskiarvo ',
      positivetext: 'Positiivisia ',
      nofeedback: 'ei yhtään palautetta annettu',
      feedbackYes: false
    }

    this.addOneGood = this.addOneGood.bind(this)
    this.addOneNeutral = this.addOneNeutral.bind(this)
    this.addOneBad = this.addOneBad.bind(this)
    
  }
  
  addOneGood = () => {
    this.setState({ good: this.state.good + 1 })
    this.setState({ total: this.state.total + 1})
    this.setState({ averagecounter: this.state.averagecounter + 1})
    this.setState({ feedbackYes: true})
  }

  addOneNeutral = () => {
    this.setState({ neutral: this.state.neutral + 1 })
    this.setState({ total: this.state.total + 1})
    this.setState({ feedbackYes: true})
  }

  addOneBad = () => {
    this.setState({ bad: this.state.bad + 1 })
    this.setState({ total: this.state.total + 1})
    this.setState({ averagecounter: this.state.averagecounter - 1})
    this.setState({ feedbackYes: true})
  }

  render() {
    {/*1.9 kattaa if lauseen*/}
    if (this.state.feedbackYes == false) {
      return (

        <>
        <div><h1>{this.state.mainheader}</h1></div>
        <Button
          button1={this.addOneGood} name1={this.state.goodtext}
          button2={this.addOneNeutral} name2={this.state.neutraltext}
          button3={this.addOneBad} name3={this.state.badtext}        
        />
        <div><h1>{this.state.statisticsheader}</h1></div>
        <div>{this.state.nofeedback}</div>
        </>
      )
    }
   
    return (
      <div>

        {/* 1.6 - 1.7
        <div><h1>{this.state.mainheader}</h1></div>

        <div>
          <button onClick={this.addOneGood}>Hyvä</button>
          <button onClick={this.addOneNeutral}>Neutraali</button>
          <button onClick={this.addOneBad}>Huono</button>
        </div>

        <div><h1>{this.state.statisticsheader}</h1></div>
        
        <div><p>Hyvä {this.state.good}</p></div>
        <div><p>Neutraali {this.state.neutral}</p></div>
        <div><p>Huono {this.state.bad}</p></div>
        <div><p>Keskiarvo {(this.state.averagecounter / this.state.total).toFixed(1)}</p></div>
        <div><p>Positiivisia {((this.state.good / this.state.total) * 100).toFixed(1)} %</p></div>
        */}

        {/*1.8 - 1.10*/}
        <div><h1>{this.state.mainheader}</h1></div>

        <Button
          button1={this.addOneGood} name1={this.state.goodtext}
          button2={this.addOneNeutral} name2={this.state.neutraltext}
          button3={this.addOneBad} name3={this.state.badtext}       
        />

        <div><h1>{this.state.statisticsheader}</h1></div>
                 
        <Statistics
            name1={this.state.goodtext} stats1={this.state.good}
            name2={this.state.neutraltext} stats2={this.state.neutral}
            name3={this.state.badtext} stats3={this.state.bad}
            name4={this.state.averagetext} stats4={(this.state.averagecounter / this.state.total).toFixed(1)}
            name5={this.state.positivetext} stats5={((this.state.good / this.state.total) * 100).toFixed(1) + "%"}
          />
        
      </div>
    )
  }
}


ReactDOM.render(
  <App />,
  document.getElementById('root')
)