import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <h1>{props.course}</h1>
    </div>
  )
}


const Contents = (props) => {
  return (
    <div>

      {/*1.1
      <p>{props.part1} {props.exercise1}</p>
      <p>{props.part2} {props.exercise2}</p>
      <p>{props.part3} {props.exercise3}</p>
      */}
      
      <Part partsi={props.parts[0].name} tehtavat={props.parts[0].exercises} />
      <Part partsi={props.parts[1].name} tehtavat={props.parts[1].exercises} />
      <Part partsi={props.parts[2].name} tehtavat={props.parts[2].exercises} />
      

    </div>
  )
}


//1.2
const Part = (props) => {
  return (
    <div>

      <p>{props.partsi} {props.tehtavat}</p>

    </div>
  )
}


const Total = (props) => {
  return (
    <div>
      <p>Total {props.parts[0].exercises + props.parts[1].exercises + props.parts[2].exercises} exercises</p>
    </div>
  )
}







const App = () => {
  
  //1.5
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

/* 1.0 -> 1.4
  const course = 'Superadvanced web and mobile programming'
*/

/* 1.0 - 1.2
  const part1 = 'Basics of React'
  const exercises1 = 8
  const part2 = 'Using props'
  const exercises2 = 10
  const part3 = 'Component states'
  const exercises3 = 12
  */

/* 1.3
const part1 = {
  name: 'Basics of React',
  exercises: 8
}
const part2 = {
  name: 'Using props',
  exercises: 10
}
const part3 = {
  name: 'Component states',
  exercises: 12
}
*/

/*1.4
  const parts = [
    {
      name: 'Basics of React',
      exercises: 8
    },
    {
     name: 'Using props',
     exercises: 10
    },
    {
     name: 'Component states',
     exercises: 12
    }
  ]
*/



  return (
    <div>

      {/*
      1.0 - 1.3
      <Header course={course} />
      1.0 - 1.2
      <Contents  part1={part1} part2={part2} part3={part3} exercise1={exercises1} exercise2={exercises2} exercise3={exercises3}/>
      1.3
      <Contents part1={part1.name} exercise1={part1.exercises} part2={part2.name} exercise2={part2.exercises} part3={part3.name} exercise3={part3.exercises}/>
      1.3 modified from 1.0-1.2
      <Total kurssi1={part1.exercises} kurssi2={part2.exercises} kurssi3={part3.exercises} />
      */}

      {/*1.4
      <Header course={course} />
      
      <Contents parts={parts} />
      
      <Total parts={parts} />
      */}

      {/* 1.5 */}
      <Header course={course.name} />
      
      <Contents parts={course.parts} />
      
      <Total parts={course.parts} />


    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)