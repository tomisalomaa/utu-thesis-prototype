import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state= {
      hyvät: 0,
      neutraalit: 0,
      huonot: 0
    }
  }

  render() {
    return (
      <div>
        <h1>anna palautetta</h1>
        <Button handleClick={() =>this.setState({hyvät: this.state.hyvät+1})} text="Hyvä"/>
        <Button handleClick={() =>this.setState({neutraalit: this.state.neutraalit+1})} text="Neutraali"/>
        <Button handleClick={() =>this.setState({huonot: this.state.huonot+1})} text="Huono"/>
        <h1>statistiikka</h1>
        <Statistics hyvät={this.state.hyvät} neutraalit={this.state.neutraalit} huonot={this.state.huonot}/>
      </div>
    )
  }
}

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = (props) => {
  if (props.hyvät == 0 && props.neutraalit == 0 && props.huonot == 0) {
    return(
      <div>
        <p>ei yhtään palautetta annettu</p>
      </div>
    )
  }
  return (
    <table>
      <tr>
        <td>hyvä </td>
        <td>{props.hyvät}</td>
      </tr>
      <tr>
        <td>neutraali </td>
        <td>{props.neutraalit}</td>
      </tr>
      <tr>
        <td>huono </td>
        <td>{props.huonot}</td>
      </tr>
      <tr>
        <td>keskiarvo</td>
        <Statistic calculation={() => ((props.hyvät-props.huonot)/(props.hyvät+props.neutraalit+props.huonot)).toFixed(1)}/>
      </tr>
      <tr>
        <td>positiivisia</td>
        <Statistic calculation={() => ((props.hyvät/(props.hyvät+props.neutraalit+props.huonot))*100).toFixed(1)} merkki="%"/>
      </tr>
    </table>
  )
}

const Statistic = (props) => {
  return (
    <td>{props.calculation()} {props.merkki}</td>
  )
}

ReactDOM.render(<App />, document.getElementById('root'))