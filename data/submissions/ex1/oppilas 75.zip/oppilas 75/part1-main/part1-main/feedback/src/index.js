import React from 'react';
import ReactDOM from 'react-dom';


  class Laskuri extends React.Component {
    constructor(props){
      super(props)
      this.state = {
        countHyvä: 0,
        countNeutraali: 0,
        countHuono: 0,
        ka: 0,
        total: 0,
        palautetta: false
      }
     this.lisääHyvä = this.lisääHyvä.bind(this);
     this.lisääNeutraali = this.lisääNeutraali.bind(this);
     this.lisääHuono = this.lisääHuono.bind(this);
    }
    lisääHyvä = () =>{
      this.setState({countHyvä: this.state.countHyvä + 1})
      this.setState({total: this.state.total + 1})
      this.setState({ka: this.state.ka + 1})
      this.setState({palautetta: true})
    }
    lisääNeutraali = () =>{
      this.setState({countNeutraali: this.state.countNeutraali + 1})
      this.setState({total: this.state.total + 1})
      this.setState({palautetta: true})
      
    }
    lisääHuono = () =>{
      this.setState({countHuono: this.state.countHuono +1})
      this.setState({total: this.state.total + 1})
      this.setState({ka: this.state.ka - 1})
      this.setState({palautetta: true})
    }
     
    render() {
      const otsikko = 'Statistiikka'
      const onkoPalautetta = this.state.palautetta
      return(
        <div>
          <Button toiminto1={this.lisääHyvä} name1="Hyvä" toiminto2={this.lisääNeutraali} name2="Neutraali" toiminto3={this.lisääHuono} name3="Huono" />
          <Header otsikko={otsikko}/>
          {onkoPalautetta
         ?<Statistics
            name1={"Hyvä"} stats1={this.state.countHyvä}
            name2={"Neutraali"} stats2={this.state.countNeutraali}
            name3={"Huono"} stats3={this.state.countHuono}
            name4={"Keskiarvo"} stats4={(this.state.ka/this.state.total).toFixed(1)}
            name5={"Positiivisia"} stats5={((this.state.countHyvä/this.state.total) * 100).toFixed(1) + "%"}
          />
          :<p>Ei yhtään palautetta annettu.</p>}
        </div>
      )
    }
  }
  const Header = (props) =>{
    return(
        <div>
          <h1>{props.otsikko}</h1>
        </div>
      )
  }
  const Button = (props) => {
    return(
      <div>
        <button onClick={props.toiminto1}>{props.name1}</button>
        <button onClick={props.toiminto2}>{props.name2}</button>
        <button onClick={props.toiminto3}>{props.name3}</button>
      </div>
    )
  }
  const Statistic = (props) => {
    return(  
      
      <tr>
        <td>{props.name}</td><td>{props.arvo}</td>
      </tr>
      
    )
  }
  const Statistics = (props) => {
    return(
      
        <table>
          <tbody>
            <Statistic name={props.name1} arvo={props.stats1} />
            <Statistic name={props.name2} arvo={props.stats2} />
            <Statistic name={props.name3} arvo={props.stats3} />
            <Statistic name={props.name4} arvo={props.stats4} />
            <Statistic name={props.name5} arvo={props.stats5} />
          </tbody>
      </table>
    )
  }

  const App = (props) => {
    const otsikko = 'Anna palautetta'
     return(
       <div>
         <Header otsikko={otsikko} />
         <Laskuri />
       </div>
     )
   }
ReactDOM.render(
  <App />,
  document.getElementById('root')
)