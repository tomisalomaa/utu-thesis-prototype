import { render } from '@testing-library/react'
import React from 'react'
import ReactDOM from 'react-dom'
import './index.css'



class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {

      hyvä: 0,
      neutraali: 0,
      huono: 0,
      kaikki: []
    }
  }

  Hyvä = () => {
    this.setState({
      hyvä: this.state.hyvä + 1,
      kaikki: this.state.kaikki.concat('hy')
    })
  }
  Neutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      kaikki: this.state.kaikki.concat('ne')
    })
  }
  Huono = () => {
    this.setState({
      huono: this.state.huono + 1,
      kaikki: this.state.kaikki.concat('hu')
    })
  }

  render() {
    const tyhja = () => {
      if (this.state.kaikki.length === 0) {
        return (
          <div>
            <em>ei yhtään palautetta annettu</em>
          </div>
        )
      }
      else{
        return(
          <div>
          <td>
          <Statistics counter={this.state.hyvä}text="Hyvä: "/>
          <Statistics counter={this.state.neutraali}text="Neutraali: "/>
          <Statistics counter={this.state.huono}text="Huono: " />
          <Statistic  arvo={(this.state.hyvä-this.state.huono)/(this.state.hyvä+this.state.neutraali+this.state.huono)}/>
          <Statistics counter={((this.state.hyvä)/(this.state.neutraali+this.state.huono+this.state.hyvä)*100)}text="Positiivisia " text2=" prosenttia"/>
          </td>
          </div>
        )
      }
    }

    return (

        <div>
        <h1>Anna palautetta</h1>
        <td>
        <Button handleClick={this.Hyvä} text="Hyvä"/>
        <Button handleClick={this.Neutraali}text="Neutraali"/>
        <Button handleClick={this.Huono}text="Huono"/>
        <h2>Statistiikka</h2>
        <di>{tyhja()}</di>
        </td>
       </div>

    )
  }
}

class Statistic extends React.Component {
  render() {
    return(
      <div>Keskiarvo: {this.props.arvo}</div>
    )
  }
 }
 
const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = ({ counter, text, text2 }) => 
<div>{text}{counter}{text2}</div>


ReactDOM.render(
  <App />,
  document.getElementById('root')
)