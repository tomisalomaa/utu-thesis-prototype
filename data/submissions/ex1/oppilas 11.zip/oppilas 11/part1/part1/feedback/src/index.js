import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';


class Feedback extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyvä: 0,
      neutraali: 0,
      huono: 0,
    }
  }

  render() {
    const s = this.state
    const total = (s.hyvä + s.huono + s.neutraali)
    const average = (s.hyvä * good + s.neutraali * neutral + s.huono * poor)
      / total
    const pos = (s.hyvä / total) * 100
    const shouldShowStats = total > 0

    return <div>
      <h1>anna palautetta</h1>
      <Button onClick={() => this.setState(incrementHyva)} label="hyvä" />
      <Button onClick={() => this.setState(incrementNeutraali)} label="neutraali" />
      <Button onClick={() => this.setState(incrementHuono)} label="huono" />
      <h1>statistiikka</h1>
      {shouldShowStats
        ? <Statistics {...this.state} average={average} pos={pos} />
        : 'ei yhtään palautetta annettu'
      }
    </div>
  }
}
let good = 1
let neutral = 0
let poor = -1

function Button(props) {
  return (
    <button onClick={props.onClick}>{props.label}</button>
  )
}
function Statistics(props) {
  return (
    <table>
      <tbody>
        <Statistic stat="hyvä" value={props.hyvä} />
        <Statistic stat="neutraali" value={props.neutraali} />
        <Statistic stat="huono" value={props.huono} />
        <Statistic stat="keskiarvo" value={props.average} fractionDigits={1} />
        <Statistic stat="positiivisia" value={props.pos} fractionDigits={1} suff="%" />
      </tbody>
    </table>
  )
}
function Statistic(props) {
  return (<tr>
      <td>{props.stat}</td>
      <td>{(props.value || 0).toFixed(props.fractionDigits || 0)} {props.suff}</td>
    </tr>
  )
}

function incrementHyva(state) {
  return {
    hyvä: state.hyvä + 1,
  }
}
function incrementNeutraali(state) {
  return {
    neutraali: state.neutraali + 1,
  }
}
function incrementHuono(state) {
  return {
    huono: state.huono + 1,
  }
}

ReactDOM.render(
  <React.StrictMode>
    <Feedback />
  </React.StrictMode>,
  document.getElementById('root')
);
