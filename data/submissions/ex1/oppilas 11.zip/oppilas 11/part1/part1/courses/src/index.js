import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  let total = 0
  for(let i=0; i<course.parts.length; i++){
    total+=course.parts[i].exercises
  }

  return (
    <div>
      <Header course={course} />

      {course.parts.map(part => (
        <Part key={part.name} {...part} />
      ))}

      <Total total={total}/>
    </div>
  )
}
const Header = (props) => {
  return (
    <div>
      <h1>{props.course.name}</h1>
    </div>
  )

}
const Part = (props) => {
  return (
    <div>
      <p>{props.name} {props.exercises}</p>
    </div>
  )
}
const Total = (props) => {
  return (
    <div>
      <p>Total {props.total} exercises</p>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
