import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      bad: 0,
      ugly: 0
    }
  }

  clickGood = () => {
    this.setState({
      good: this.state.good + 1
    })
  }

  clickBad = () => {
    this.setState({
      bad: this.state.bad + 1
    })
  }

  clickUgly = () => {
    this.setState({
      ugly: this.state.ugly + 1
    })
  }

  render() {
    return (
      <div>
        <div>
          <h1>Give feedback</h1>
          <button onClick={this.clickGood}>Good</button>
          <button onClick={this.clickBad}>Bad</button>
          <button onClick={this.clickUgly}>Ugly</button>
          <h1>Stats</h1>
          <p>Good: {this.state.good}</p>
          <p>Bad: {this.state.bad}</p>
          <p>Ugly: {this.state.ugly}</p>
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)