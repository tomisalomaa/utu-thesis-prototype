import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <h1>Welcome to {props.course.name}!</h1>
  )
}

const Part = (props) => {
  return (
    <p>{props.part.name}, which consists of {props.part.exercises} exercises.</p>
  )
}

const Total = (props) => {
  return (
    <p>Making the total ammount of exercises {props.course.parts[0].exercises + props.course.parts[1].exercises + props.course.parts[2].exercises}</p>
  )
}

const Contents = (props) => {
  return (
    <div>
      <Part part = {props.course.parts[0]} />
      <Part part = {props.course.parts[1]} />
      <Part part = {props.course.parts[2]} />
    </div>
  )
}

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return(
    <div>
      <Header course={course} />
      <Contents course={course} />
      <Total course={course} />
    </div>
)}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)