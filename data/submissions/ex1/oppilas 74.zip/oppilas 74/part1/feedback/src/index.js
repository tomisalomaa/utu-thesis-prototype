import React from 'react';
import ReactDOM from 'react-dom';

const Palaute = () => <div><h1>anna palautetta</h1></div>

const Statistics = ({state}) => {
  const positiivisia = () => Number((state.good / state.kaikki * 100).toFixed(1))+" %"
  const keskiarvo = () => Number((state.keskiarvo / state.kaikki).toFixed(1))
  
  if (state.kaikki === 0) {
    return (
      <div>
        <h1>statistiikka</h1>
        <p>ei yhtään palautetta annettu</p>
      </div>
    )
  }
  return (
      <table>
        <caption><h1>statistiikka</h1></caption>
        <tbody>
          <tr>
            <td>hyvä</td>
            <Statistic statistic={state.good}/>
          </tr>
          <tr>
           <td>neutraali</td>
            <Statistic statistic={state.neutral}/>
          </tr>
          <tr>
            <td>huono</td>
            <Statistic statistic={state.poor}/>
          </tr>
          <tr>
            <td>keskiarvo</td>
            <Statistic statistic={keskiarvo()}/>
          </tr>
          <tr>
            <td>positiivisia</td>
            <Statistic statistic={positiivisia()}/>
          </tr>
        </tbody>
      </table>
  ) 
}


const Statistic = ({statistic, }) => {
  return (
    <td>  {statistic} </td>
  )
}

const Button = ({handleClick, text }) => (
  <button onClick = {handleClick}>
    {text}
  </button>
)

class App extends React.Component{
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      poor: 0,
      kaikki: 0,
      keskiarvo: 0
    }
  }

  clickGood = () => {
    this.setState( (prevState) =>({
      good: prevState.good + 1,
      kaikki: prevState.kaikki + 1,
      keskiarvo: prevState.keskiarvo + 1
    }))
  }

  clickNeutral = () => {
    this.setState( (prevState) => ({
      neutral: prevState.neutral + 1,
      kaikki: prevState.kaikki + 1
    }))
  }

  clickPoor = () => {
    this.setState((prevState) => ({
      poor: prevState.poor + 1,
      kaikki: prevState.kaikki + 1,
      keskiarvo: prevState.keskiarvo - 1
    }))
  }

  render() {
    return (
      <div>
        <Palaute />
          <Button 
            handleClick={this.clickGood}
            text ="hyvä"
            />
          <Button 
            handleClick={this.clickNeutral}
            text= "neutraali"
            />
          <Button 
            handleClick={this.clickPoor}
            text="huono"
            />
        <Statistics state={this.state}/>
          
      </div>
    )
  }
}



ReactDOM.render(
    <App />,
  document.getElementById('root')
);
