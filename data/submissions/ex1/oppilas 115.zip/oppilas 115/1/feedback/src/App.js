import { useState } from 'react';

import Header from './components/Header';
import Button from './components/Button';
import FeedbackButtonContainer from './components/FeedbackButtonContainer';
import Statistics from './components/Statistics';

import styles from './App.module.css';

const App = () => {

    const [positiveFeedback, setPositiveFeedback] = useState(0);
    const [neutralFeedback, setNeutralFeedback] = useState(0);
    const [negativeFeedback, setNegativeFeedback] = useState(0);

    const positiveOnClick = (event) => {
        event.preventDefault();
        setPositiveFeedback((oldState) => oldState + 1);
    };

    const neutralOnClick = (event) => {
        event.preventDefault();
        setNeutralFeedback((oldState) => oldState + 1);
    };

    const negativeOnClick = (event) => {
        event.preventDefault();
        setNegativeFeedback((oldState) => oldState + 1);
    };

    const results = [
        { title: 'Hyvä', count: positiveFeedback },
        { title: 'Neutraali', count: neutralFeedback },
        { title: 'Huono', count: negativeFeedback }
    ];

    return (
        <div className={styles.App}>

            <Header title={'Anna palautetta'} />

            <FeedbackButtonContainer>

                <Button value={'Hyvä'} onClick={positiveOnClick} />

                <Button value={'Neutraali'} onClick={neutralOnClick} />

                <Button value={'Huono'} onClick={negativeOnClick} />

            </FeedbackButtonContainer>

            <Header title={'Statistiikka'} />

            <Statistics results={results} />

        </div>
    );
};

export default App;
