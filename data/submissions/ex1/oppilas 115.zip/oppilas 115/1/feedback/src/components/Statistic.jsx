const Statistic = (props) => {
	return (
		<tr>
			<td>
				{ props.title && props.title }
			</td>
			<td>
				{ props.count && props.count }
			</td>
		</tr>
	);
};

export default Statistic;