import Statistic from './Statistic';

import styles from './Statistics.module.css';

const Statistics = (props) => {

	const results = props.results;

	if (results === undefined || results === [])  {
		return (<table />);
	}

	let negativeCount = 0;
	let neutralCount = 0;
	let positiveCount = 0;

	let sum = 0;

	for (const result of results) {

		if (result.count) {

			if (result.title === 'Hyvä') {

				positiveCount += result.count;
				sum += result.count;

			} else if (result.title === 'Huono') {

				negativeCount += result.count;
				sum -= result.count;

			} else if (result.title === 'Neutraali') {

				neutralCount += result.count;

			}

		}

	}

	const totalCount = negativeCount + neutralCount + positiveCount;

	const average  = (negativeCount === 0  || positiveCount === 0)
		? 0
		: (sum / (totalCount)).toFixed(1);

	let positivePercentage = ((positiveCount * 100) / (totalCount)).toFixed(1);

	if (positiveCount === 0 && totalCount === 0) {
		positivePercentage = (0).toFixed(1);
	}

	if (totalCount === 0) {
		return (
			<p>
				Ei yhtään palautetta annettu
			</p>
		);
	}

	return (
		<table className={styles.Statistics}>
			<tbody>

			{
				results.map( (result) => <Statistic key={result.title} title={result.title} count={result.count} /> )
			}

			<tr>
				<td>
					Keskiarvo
				</td>
				<td>
					{ average }
				</td>
			</tr>

			<tr>
				<td>
					Positiivisia
				</td>
				<td>
					{ positivePercentage } %
				</td>
			</tr>

			</tbody>
		</table>
	)
};

export default Statistics;