const FeedbackButtonContainer = (props) => {
	return (
		<div>
			{ props.children }
		</div>
	);
};

export default FeedbackButtonContainer;