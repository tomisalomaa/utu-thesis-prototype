import styles from './Button.module.css';

const Button = (props) => {
	return (
		<input className={styles.Button}
		       type={'button'}
		       value={props.value}
		       onClick={props.onClick}
		/>
	);
};

export default Button;