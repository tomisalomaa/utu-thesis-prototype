import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0,
      keskiarvo: 0,
      positiiviset: 0
    }
  }
  laskeKeskiarvo = () => {
    let ka = (this.state.hyva - this.state.huono)/(this.state.hyva + this.state.neutraali + this.state.huono)
    let roundedKa = Math.round(ka * 10) / 10
    this.setState({keskiarvo: roundedKa})
  }

  laskePositiiviset = () => {
    let positiiviset = ((this.state.hyva/(this.state.hyva + this.state.neutraali + this.state.huono))*100)
    let roundedPos = Math.round(positiiviset * 10) / 10
    this.setState({positiiviset: roundedPos})
  }

  render(){

    const palauteHyva = (uusiArvo) => () => {
      this.setState({ hyva: uusiArvo})
    }
    const palauteNeutraali = (uusiArvo) => () => {
      this.setState({ neutraali: uusiArvo})
    } 
    const palauteHuono = (uusiArvo) => () => {
      this.setState({ huono: uusiArvo})
    }
    const laskeKeskiarvo = () => () => {
      this.laskeKeskiarvo()
    }
    const laskePositiiviset = () => () => {
      this.laskePositiiviset()
    }

    return (
      <div>
        <div>
          <h1>Anna palautetta</h1>
          <button onClick={palauteHyva(this.state.hyva + 1)}>hyvä</button>
          <button onClick={palauteNeutraali(this.state.neutraali + 1)}>neutraali</button>
          <button onClick={palauteHuono(this.state.huono + 1)}>huono</button>
        </div>
        <div>
          <h1>Statistiikka</h1>
          <ul>
            <li>Hyvä: {this.state.hyva}</li>
            <li>Neutraali: {this.state.neutraali}</li>
            <li>Huono: {this.state.huono}</li>
            <li>Keskiarvo: {this.state.keskiarvo} <button onClick={laskeKeskiarvo()}>laske</button></li>
            <li>Positiivisia: {this.state.positiiviset} % <button onClick={laskePositiiviset()}>laske</button></li>
          </ul>
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)