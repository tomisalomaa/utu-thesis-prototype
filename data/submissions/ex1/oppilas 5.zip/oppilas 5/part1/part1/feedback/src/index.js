import React from 'react'
import ReactDOM from 'react-dom'

const Header = () => {
  return(
  <div>
    <h1>give feedback</h1>
  </div>
  )
}
const Stat = () => {
  return(
    <div>
      <h1>statistics</h1>
    </div>
  )
}


class App extends React.Component {
  constructor() {
    super()
    this.state = {
      good: 0,
      neutral: 0,
      poor: 0
    }
    
    this.countGood = this.countGood.bind(this)
    this.countNeutral = this.countNeutral.bind(this)
    this.countPoor = this.countPoor.bind(this)
  }

  countGood(){
    this.setState({good: this.state.good + 1})
  }

  countNeutral(){
    this.setState({neutral: this.state.neutral + 1})
  }

  countPoor(){
    this.setState({poor: this.state.poor + 1})
  }
  

  render() {
    return (
      <div>
        <Header/>
        <div>
          <button onClick={this.countGood}>
            good
          </button>
          <button onClick={this.countNeutral}>
            neutral
          </button>
          <button onClick={this.countPoor}>
            poor
          </button>
        </div>
        <Stat/>
        <div>
          {'good ' + this.state.good}
        </div>
        <div>
          {'neutral ' + this.state.neutral}
        </div>
        <div>
          {'poor ' + this.state.poor}
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)