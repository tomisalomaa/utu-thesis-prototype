import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(){
    super()
    this.state = {
      hyväLaskuri: 0,
      neutraaliLaskuri: 0,
      huonoLaskuri: 0,
      kaikki: 0
    }
  }

  prosentti(){
    if(this.state.kaikki==0){
      return (0).toFixed(1)
    }else{
      return ((this.state.hyväLaskuri/(this.state.kaikki))*100).toFixed(1)
    }
  }

  keskiarvo(){
    if(this.state.kaikki==0){
      return (0).toFixed(1)
    }else{
      return (((this.state.hyväLaskuri-this.state.huonoLaskuri)/(this.state.kaikki))).toFixed(1)
    }
  }

  render(){
    
    return(
      <div>
        <h1>anna palautetta</h1>
        <Button handleClick={() => this.setState({hyväLaskuri: this.state.hyväLaskuri+1, kaikki: this.state.kaikki+1})} text="hyvä" />
        <Button handleClick={() => this.setState({neutraaliLaskuri: this.state.neutraaliLaskuri+1, kaikki: this.state.kaikki+1})} text="neutraali" />
        <Button handleClick={() => this.setState({huonoLaskuri: this.state.huonoLaskuri+1, kaikki: this.state.kaikki+1})} text="huono" />
        <h1>statistiikka</h1>
        <Statistics hy_value={this.state.hyväLaskuri}
                    ne_value={this.state.neutraaliLaskuri}
                    hu_value={this.state.huonoLaskuri}
                    ka_value={this.keskiarvo()} 
                    pr_value={this.prosentti()}/>
      </div>
    )
  }
}

const Button = (props) => {
  return(
    <button onClick={props.handleClick}>{props.text}</button>
  )
}

const Statistics = (props) => {
  return(
    <div>
      <Statistic text="hyvä" value={props.hy_value}/>
      <Statistic text="neutraali" value={props.ne_value}/>
      <Statistic text="huono" value={props.hu_value}/>
      <Statistic text="keskiarvo" value={props.ka_value}/>
      <Statistic text="positiivisia" value={props.pr_value} symbol="%"/> 
    </div>)
}

const Statistic = (props) => {
  return(
    <p>{props.text} {props.value} {props.symbol}</p>
  )
}

ReactDOM.render(
  <App />, 
  document.getElementById('root')
)