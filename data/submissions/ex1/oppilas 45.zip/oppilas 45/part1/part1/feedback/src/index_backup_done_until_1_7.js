import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(){
    super()
    this.state = {
      hyväLaskuri: 0,
      neutraaliLaskuri: 0,
      huonoLaskuri: 0,
      kaikki: 0
    }
  }

  prosentti(){
    if(this.state.kaikki==0){
      return '0.0'
    }else{
      return ((this.state.hyväLaskuri/(this.state.kaikki))*100).toFixed(1)
    }
  }

  keskiarvo(){
    if(this.state.kaikki==0){
      return '0.0'
    }else{
      return (((this.state.hyväLaskuri-this.state.huonoLaskuri)/(this.state.kaikki))).toFixed(1)
    }
  }

  render(){
    
    return(
      <div>
        <h1>anna palautetta</h1>
        <button onClick={() => this.setState({hyväLaskuri: this.state.hyväLaskuri+1, kaikki: this.state.kaikki+1})}>hyvä</button>
        <button onClick={() => this.setState({neutraaliLaskuri: this.state.neutraaliLaskuri+1, kaikki: this.state.kaikki+1})}>neutraali</button>
        <button onClick={() => this.setState({huonoLaskuri: this.state.huonoLaskuri+1, kaikki: this.state.kaikki+1})}>huono</button>
        <h1>statistiikka</h1>
        <p>hyvä {this.state.hyväLaskuri}</p>
        <p>neutraali {this.state.neutraaliLaskuri}</p>
        <p>huono {this.state.huonoLaskuri}</p>
        <p>keskiarvo {this.keskiarvo()}</p>
        <p>positiivisia {this.prosentti()} %</p>
  </div>
    )
  }
}


ReactDOM.render(
  <App />, 
  document.getElementById('root')
)