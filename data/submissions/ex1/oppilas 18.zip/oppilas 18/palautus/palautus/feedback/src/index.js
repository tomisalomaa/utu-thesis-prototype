import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

const Title = ({ title }) => (
  <div id="header-container">
    <h1 id="header">{title}</h1>
  </div>
)

const Subheading = ({ text }) => (
    <h3 id="subheading">{text}</h3>
)

const Button = ({ button }) => {
    return (
      <button className={button.class} id={button.id} onClick={button.handleClick}>
        {button.text}
      </button>
    )
}

const ButtonContainer = ({buttons}) => {
  const [button1, button2, button3] = buttons
  return(
    <div className="buttonContainer">
      <Button button={button1} />
      <Button button={button2} />
      <Button button={button3} />
    </div>
  )
}

const FeedbackInfo = ({feedback}) => {
  let amount = feedback.amount
  if (feedback.isPercentage) {
    amount = amount + '%'
  }
  return <tr className="feedbackInfo"><td>{feedback.type}</td>
                                      <td>{amount}</td></tr>
}

const FeedbackContainer = ({ amount, feedback }) => {
  if (amount === 0) {
    return <div className="feedbackContainer"><p>ei yhtään palautetta annettu</p></div>
  } else {
    return (
      <table className="feedbackContainer">
        <tbody>
          <FeedbackInfo feedback={feedback[0]} />
          <FeedbackInfo feedback={feedback[1]} />
          <FeedbackInfo feedback={feedback[2]} />
          <FeedbackInfo feedback={feedback[3]} />
          <FeedbackInfo feedback={feedback[4]} />
        </tbody>
      </table>
    )
  }
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
        good: 0,
        neutral: 0,
        bad: 0
    }
  }

  goodFeedback = () => {
    this.setState({ good: this.state.good + 1 })
  }
  neutralFeedback = () => {
    this.setState({ neutral: this.state.neutral + 1 })
  }
  badFeedback = () => {
    this.setState({ bad: this.state.bad + 1 })
  }

  feedbackAmount = () => {
    return this.state.good + this.state.neutral + this.state.bad
  }

  averageFeedback = () => {
    if (this.feedbackAmount() === 0) {
      return 0
    }
    return ((this.state.good * 1  + this.state.bad * -1) / this.feedbackAmount()).toFixed(2)
  }

  positivePercentage = () => {
    if (this.feedbackAmount() === 0) {
      return 0
    }
    return (this.state.good/this.feedbackAmount()*100).toFixed(2)
  }

  render() {

    const buttons = [
      {
        text: "Hyvä",
        id: "goodButton",
        class: "rateButton",
        handleClick: this.goodFeedback
      },
      {
        text: "Neutraali",
        id: "neutralButton",
        class: "rateButton",
        handleClick: this.neutralFeedback
      },
      {
        text: "Huono",
        id: "badButton",
        class: "rateButton",
        handleClick: this.badFeedback
      }
    ]

    const feedBack = [
      {
        type: "Hyvä",
        amount: this.state.good
      },
      {
        type: "Neutraali",
        amount: this.state.neutral
      },
      {
        type: "Huono",
        amount: this.state.bad
      },
      {
        type: "Keskiarvo",
        amount: this.averageFeedback()
      },
      {
        type: "Positiivisia",
        amount: this.positivePercentage(),
        isPercentage: true
      }
    ]

    return (
      <div id='app'>
        <Title title="Anna palautetta" />
        <ButtonContainer buttons={buttons} />
        <Subheading text="Palaute"/>
        <FeedbackContainer amount={this.feedbackAmount()} feedback={feedBack} />
      </div>
    )
  }
}


ReactDOM.render(<App />,document.getElementById('root'));
