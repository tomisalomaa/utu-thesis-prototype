import React from 'react'
import ReactDOM from 'react-dom'

const Button = (props) => (
  <button onClick={props.handleClick}>
    {props.text}
  </button>
)

const Statistic = (props) => (
  <div>
    <p>{props.nimi} {props.luku}</p>
  </div>
)

const Statistics = (props) => {
  if (props.yhteensa === 0) {
    return (
      <div>
        <p>Vielä ei ole näytettävää statistiikkaa</p>
      </div>
    )
  }
  return (
  <div>
    <h1>Statistiikka</h1>
    <table>
      <tbody>
        <tr>
          <td><Statistic nimi="Hyvä" /></td>
          <td><Statistic luku={props.hyva} /></td>
        </tr>
        <tr>
          <td><Statistic nimi="Neutraali" /></td>
          <td><Statistic luku={props.neutraali} /></td>
        </tr>
        <tr>
          <td><Statistic nimi="Huono" /></td>
          <td><Statistic luku={props.huono} /></td>
        </tr>
        <tr>
          <td><Statistic nimi="Keskiarvo" /></td>
          <td><Statistic luku={props.keskiarvo} /></td>
        </tr>
        <tr>
          <td><Statistic nimi="Positiivisia" /></td>
          <td><Statistic luku={props.positiv} /></td>
        </tr>
      </tbody>
    </table>
  </div>
  )
}


class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyvamaara: 0,
      neutraalimaara: 0,
      huonomaara: 0,
      yhteensa: 0
    }
  }

  //Koitin tehdä näistä aseta metodeista kauan yleiskäyttöistä metodia, siis simmoista missä parametriksi voisi vain laittaa
  //yhden this.state:n ominaisuuksista mutten saanut toimimaan millään. Olisi kiva nähdä miten kysyinen oikein toteutettaisiin?
  //Tälläistä ja monia muita koitin
  
  // Aseta = (y,x) => {
  //   this.setState({y: x+1})
  // }

  AsetaHyva = () => {
    this.setState({hyvamaara: this.state.hyvamaara + 1})
    this.setState({yhteensa: this.state.yhteensa + 1})
  }

  AsetaHuono = () => {
    this.setState({huonomaara: this.state.huonomaara + 1})
    this.setState({yhteensa: this.state.yhteensa + 1})
  }

  AsetaNeutraali = () => {
    this.setState({neutraalimaara: this.state.neutraalimaara + 1})
    this.setState({yhteensa: this.state.yhteensa + 1})
  }
  
  

  render() {
    const Keskiarvo = (this.state.hyvamaara + this.state.neutraalimaara + this.state.huonomaara)/3
    const positivmaara = this.state.hyvamaara/(this.state.hyvamaara + this.state.neutraalimaara + this.state.huonomaara)*100
    return (
      <div>
        <h1>Anna palautetta</h1>
        <Button handleClick={() => this.AsetaHyva()} text="Hyvä" />
        <Button handleClick={() => this.AsetaNeutraali()} text="Neutraali" />
        <Button handleClick={() => this.AsetaHuono()} text="Huono" />
        <Statistics yhteensa={this.state.yhteensa} hyva={this.state.hyvamaara} neutraali={this.state.neutraalimaara}
                    huono={this.state.huonomaara} keskiarvo={Keskiarvo} positiv={positivmaara}/>
      </div>
    )
  }
}




ReactDOM.render(<App />, document.getElementById('root'))
