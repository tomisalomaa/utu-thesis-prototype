import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

const Button = (props) => (
  <button id={props.id} onClick={props.func}> {props.name} </button>
)

const Statistic = (props) => {
  if (props.decimal) {
    return (
      <tr>
        <td> {props.prompt} </td>
        <td> {props.value.toFixed(1)} </td>
      </tr>
    )
  }

  return (
    <tr>
      <td id={props.identifier}> {props.prompt} </td>
      <td id={props.identifier}> {props.value.toFixed(1)} </td>
    </tr>
  )
}

const Statistics = (props) => (
  <div>
    <table>
      <tbody>
        <Statistic identifier='goodText' prompt='Good' value={props.good}> </Statistic>
        <Statistic identifier='neutralText' prompt='Neutral' value={props.neutral}> </Statistic>
        <Statistic identifier='badText' prompt='Bad' value={props.bad}> </Statistic>
        <Statistic prompt='Average' value={props.average} decimal={1}> </Statistic>
        <Statistic prompt='Positive%' value={props.percent} decimal={1}> </Statistic>
      </tbody>
    </table>
  </div>
)

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0,
      totalVote: 0
    }
  }

  incrementState = (feedback) => {
    return () => {
      if (feedback == 1)
        this.setState({ good: this.state.good + 1 })
      else if (feedback == 0)
        this.setState({ neutral: this.state.neutral + 1 })
      else if (feedback == -1)
        this.setState({ bad: this.state.bad + 1 })
      this.setState({ totalVote: this.state.totalVote + 1 })
    }
  }

  findAverage = () => {
    if (this.state.totalVote === 0) return 0;
    const point = this.state.good - this.state.bad
    const average = point / this.state.totalVote

    return average;
  }

  findPositivePercent = () => {
    if (this.state.totalVote == 0) return 0;
    return (this.state.good / this.state.totalVote) * 100;
  }

  showFeedback = (num) => {
    if (num == 0)
      return (<p> No feedback given! </p>)

    return (
      <Statistics
        good={this.state.good} neutral={this.state.neutral}
        bad={this.state.bad} average={this.findAverage()}
        percent={this.findPositivePercent()}>
      </Statistics>
    )
  }

  render() {
    return (
      <div>
        <h1>  Feedback App </h1>
        <div id='container'>
          <Button id='good' name="Good" func={this.incrementState(1)}> </Button>
          <Button id='neutral' name="Neutral" func={this.incrementState(0)}> </Button>
          <Button id='bad' name="Bad" func={this.incrementState(-1)}> </Button>
        </div>

        <h2> Statistics </h2>

        <div>
          {this.showFeedback(this.state.totalVote)}
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
