import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => (
  <div>
    <h1>{props.course.name}</h1>
  </div>
)

const Contents = (props) => (
  <div>
    <Part name={props.course.parts[0].name} number={props.course.parts[0].exercises}> </Part>
    <Part name={props.course.parts[1].name} number={props.course.parts[1].exercises}> </Part>
    <Part name={props.course.parts[2].name} number={props.course.parts[2].exercises}> </Part>
  </div>
)

const Total = (props) => (
  <div>
    <p> Total {props.course.parts[0].exercises + props.course.parts[1].exercises + props.course.parts[2].exercises} exercises </p>
  </div>
)

const Part = (props) => (
  <div>
    <p> {props.name} {props.number}</p>
  </div>
)

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course}> </Header>
      <Contents course={course}> </Contents>
      <Total course={course}> </Total>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)