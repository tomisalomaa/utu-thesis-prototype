import React from 'react';
import ReactDOM from 'react-dom';






class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyvä : 0 ,
      neutraali : 0,
      huono : 0 
    
   
    }
  }
    klikHyvä = () =>{
      
      this.setState({
        hyvä : this.state.hyvä +1
      })
    }
    klikNeutraali = () =>{
      
      this.setState({
        neutraali : this.state.neutraali +1
      })
    }
    klikHuono = () =>{
      
      this.setState({
        huono : this.state.huono +1
      })
    }
      render() {
        return(
        <div>
          <div>
          <h1>Anna Palautetta!</h1>
          <button onClick={this.klikHyvä}>hyvä</button>    <button onClick={this.klikNeutraali}>neutraali</button>    <button onClick={this.klikHuono}>huono</button>
          
          </div>
          <h2>Tulokset:</h2>
          <div> 
            Hyvä= {this.state.hyvä}</div>
          <div>Neutraali= {this.state.neutraali}</div>
          <div>Huono= {this.state.huono}</div>
          </div>
        )
  }

}

ReactDOM.render(
    <App />,
  document.getElementById('root')
)