import React from 'react';
import ReactDOM from 'react-dom';

const Part = (props) => {
  return(
    <p>{props.part} {props.exercises}</p>
  )
}

const Header = (props) =>{
return(
  <div>
    <h1>{props.course}</h1>
  </div>
  )
}

const Total = (props) =>{
    let sum = 0
    const list = props.course.parts.map(function(item){
      sum=sum+item.exercises
    })
  return(
    <p>Total {sum} exercises</p>
  )
}  
const Contents = (props) =>{
    const list = props.course.parts.map(function(item){
  return(
  <div>
    <p>{item.name}:{item.exercises}</p>
  </div>
  )
     })
     return list
};
const App = () => {
  const course = { 
    name: 'Superadvanced web and mobile programming',
    parts: [
    {
    name: 'Basics of React ',
    exercises: 8
    },
    {
    name: 'Using props ',
    exercises: 10
    },
    {
    name:'Component states ',
    exercises: 12
    }
  ]
}

  return (
    <div>
      <Header course={course.name}/>
      <Contents course={course}/>
      <Total course={course}/>
      </div>
  )
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)