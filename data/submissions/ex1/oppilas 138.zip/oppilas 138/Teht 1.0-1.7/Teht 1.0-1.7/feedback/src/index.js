import React, { useState } from 'react';
import ReactDOM from 'react-dom';

const Nappi = () => {

}
const Statistics = (props) => {
  <div>
  <p>hyvä {props.hyvä}</p>
  <p>neutraali {props.neutraali}</p>
  <p>huono {props.huono}</p>
  </div>
}
const Statistic = (props) => {
  return(
    <p>keskiarvo {(props.hyvä-props.huono)/(props.hyvä+props.huono+props.keskiarvo)}</p>
  )
}

const App = () => {
  const [hyvä, setHyvä] = useState(0)
  const [neutraali, setNeutraali] = useState(0)
  const [huono, setHuono] = useState(0)
  
return(
  <div>
    <h1>Anna Palautetta</h1>
    <button onClick={() => setHyvä(hyvä +1)}>Hyvä</button>
    <button onClick={() => setNeutraali(neutraali +1)}>Neutraali</button>
    <button onClick={() => setHuono(huono +1)}>Huono</button>
    
    <h1>statistiikka</h1>
    <p>hyvä {hyvä}</p>
    <p>neutraali {neutraali}</p>
    <p>huono {huono}</p>
    <p>keskiarvo {((hyvä-huono)/(hyvä+neutraali+huono)).toFixed(2)}</p>
    <p>positiivisia {((hyvä)/(hyvä+neutraali+huono)*100).toFixed(1)}%</p>

  </div>
)}

ReactDOM.render(
  <App />,
  document.getElementById('root'))
