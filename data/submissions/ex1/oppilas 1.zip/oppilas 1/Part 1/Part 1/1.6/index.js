import { render } from '@testing-library/react';
import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component{
  constructor(){
    super()
    this.state ={
      counter1:0,
      counter2:0,
      counter3:0
    }
  }

  render(){
    return(
      <div>
        <h1>Anna palautetta</h1>
        <div>
          <button onClick={()=> this.setState({counter1:this.state.counter1 + 1})}>
            hyvä
          </button>
          <button onClick={()=> this.setState({counter2:this.state.counter2 + 1})}>
            neutraali
          </button>
          <button onClick={()=> this.setState({counter3:this.state.counter3 + 1})}>
            huono
          </button>
          <h2>Statistiikka</h2>
          <p>hyvä {this.state.counter1}</p>
          <p>neutraali {this.state.counter2}</p>
          <p>huono {this.state.counter3}</p>
        </div>
      </div>
    )
  }
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)