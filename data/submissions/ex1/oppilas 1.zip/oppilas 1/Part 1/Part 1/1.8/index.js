import { render } from '@testing-library/react';
import React from 'react';
import ReactDOM from 'react-dom';

const Button = ({handleClick,name}) => (
  <button onClick={handleClick}>
    {name}
  </button>
)

const Statistics =(props) =>{
  return(
  <div>
    <Statistic name={props.name1} counter= {props.counter1}/>
    <Statistic name={props.name2} counter= {props.counter2}/>
    <Statistic name={props.name3} counter= {props.counter3}/>
    <Statistic name={props.name4} counter= {props.counter4}/>
    <Statistic name={props.name5} counter= {props.counter5}/>
  </div>
  )
}
const Statistic =(props) =>{
  return(
      <p> {props.name}: {props.counter}</p>
  )
}

class App extends React.Component{
  
  constructor(){
    super()
    this.state ={
      counter1:0,
      counter2:0,
      counter3:0,
      counter4: 0
    }
  }

  lisaaHyva = (counter,arvo) => {
    return () =>{
      this.setState({ counter1: arvo})
      this.setState({counter4:this.state.counter4+1})
    }
  }
  lisaaNeutraali = (counter,arvo) => {
    return () =>{
      this.setState({ counter2: arvo})
      this.setState({counter4:this.state.counter4+1})
    }
  }
  lisaaHuono = (counter,arvo) => {
    return () =>{
      this.setState({ counter3: arvo})
      this.setState({counter4:this.state.counter4+1})
    }
  }


  render(){
    return(
      <div>
        <h1>Anna palautetta</h1>
        <div>
          <Button name= 'hyvä' handleClick={this.lisaaHyva(this.state.counter1,this.state.counter1 + 1)}/>
          <Button name= 'neutraali' handleClick={this.lisaaNeutraali(this.state.counter2,this.state.counter2 + 1)}/>
          <Button name= 'huono' handleClick={this.lisaaHuono(this.state.counter3,this.state.counter3 + 1)}/>
          <Statistics name1= 'hyvä' name2= 'neutraali' name3='huono' name4='keskiarvo' name5='positiivisia' counter1= {this.state.counter1} counter2= {this.state.counter2} counter3= {this.state.counter3} counter4= {(this.state.counter1-this.state.counter3)/this.state.counter4} counter5= {this.state.counter1*100/this.state.counter4}/>
          
          

          
        </div>
      </div>
    )
  }
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)