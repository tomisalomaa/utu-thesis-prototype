import React from 'react';
import ReactDOM from 'react-dom';

const Header = (props) =>{
  return (
    <div>
      <h1>{props.course}</h1>
    </div>
  )
}

const Contents = (props)=>{
  return(
    <div>
    <Part part={props.part1} ex={props.ex1}/>
    <Part part={props.part2} ex={props.ex2}/>
    <Part part={props.part3} ex={props.ex3}/>
    </div>
  )
}

const Total = (props) =>{
  return(
    <div>
      <p>Yhteensä {props.ex1+props.ex2+props.ex3} tehtävää
      </p>
    </div>
  )
}

const Part =(props)=>{
  return(
    <p>{props.part}: {props.ex} tehtävää</p>
  )

}

const App = () =>{
  const course = 'Superadvanced web and mobile programming'
  const part1 = {
    name: 'Basics of  React',
    exercises: 8
  }
  const part2 = {
    name: 'Using props',
    exercises: 10
  }
  const part3 = {
    name: 'Component states',
    exercises: 12
  }

  return (
    <div>
      <Header course={course}/>
      <Contents part1 = {part1.name} ex1= {part1.exercises} part2 = {part2.name} ex2= {part2.exercises} part3 = {part3.name} ex3= {part3.exercises}/>
      <Total ex1 = {part1.exercises} ex2={part2.exercises} ex3={part3.exercises}/>
    </div>
  )
}

ReactDOM.render(
    <App />,
  document.getElementById('root')
)

