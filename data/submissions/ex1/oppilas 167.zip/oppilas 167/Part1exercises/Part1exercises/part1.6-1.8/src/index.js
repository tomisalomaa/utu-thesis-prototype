import { render } from '@testing-library/react'
import React from 'react'
import ReactDOM from 'react-dom'
import './index.css'



class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      
      hyvä: 0,
      neutraali: 0,
      huono: 0
    }
  }
  
  klikHyvä = () => {
    this.setState({
      hyvä: this.state.hyvä + 1
    })
  }
  klikNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1
    })
  }
  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1
    })
  }
  render() {
    
    return (
        
        <div id="koira" >
        <h1>Anna palautetta</h1>
        <td>
        <Button handleClick={this.klikHyvä} text="Hyvä"/>
        <Button handleClick={this.klikNeutraali}text="Neutraali"/>
        <Button handleClick={this.klikHuono}text="Huono"/>
        <h2>Statistiikka</h2>
        
        <Statistics counter={this.state.hyvä}text="Hyvä: "/>
        <Statistics counter={this.state.neutraali}text="Neutraali: "/>
        <Statistics counter={this.state.huono}text="Huono: " />
        <Statistic  arvo={(this.state.hyvä-this.state.huono)/(this.state.hyvä+this.state.neutraali+this.state.huono)}/>
        <Statistics counter={((this.state.hyvä)/(this.state.neutraali+this.state.huono+this.state.hyvä)*100)}text="Positiivisia " text2="%"/>
        </td>
       </div>
      
    )
  }
}
class Statistic extends React.Component {
  render() {
    return(
      <div>Keskiarvo: {this.props.arvo}</div>
    )
  }
 }
const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)
const Statistics = ({ counter, text, text2 }) => <div>{text}{counter}{text2}</div>



  


ReactDOM.render(
  <App />,
  document.getElementById('root')
)