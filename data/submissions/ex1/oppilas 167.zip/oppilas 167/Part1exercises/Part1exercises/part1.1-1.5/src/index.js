import React from 'react'
import ReactDOM from 'react-dom'
const Header = (props) => {
  return (
    <div>

      <h1>{props.course.name}</h1>
    </div>
  )
}
const Part = (props) => {
   
  return(
    <div>
       <p>{props.contents.parts[0].name} {props.contents.parts[0].exercises}</p>
       <p>{props.contents.parts[1].name} {props.contents.parts[1].exercises}</p>
       <p>{props.contents.parts[2].name} {props.contents.parts[2].exercises}</p> 
    </div>
    
  )
}
const Contents = (props) => {
  
  return (
    <div>
      <Part contents={props.contents}/> 
    </div>
  )
}
const Total = (props) => {
  
  return (
    <div>
      <p>{props.total.parts[0].exercises + props.total.parts[1].exercises + props.total.parts[2].exercises} </p>
    </div>
  )
}
const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course}/>
      <Contents contents={course}/>
      <Total total={course}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
