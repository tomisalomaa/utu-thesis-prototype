import React from 'react'
import ReactDOM from 'react-dom'

const Header=(props)=> {
  return (
    <div>
      <h1>{props.course.name}</h1>
    </div>
  )
}

const Part=(props)=> {
  return (
    <><p>{props.part} {props.ex}</p></>
  )
}

const Contents=(props)=> {
  return (
    <><Part part={props.course.parts[0].name} ex={props.course.parts[0].exercises}/>
    <Part part={props.course.parts[1].name} ex={props.course.parts[1].exercises}/>
    <Part part={props.course.parts[2].name} ex= {props.course.parts[2].exercises}/></>
  )
}



const Total=(props)=> {
  return (
    <div>
       <p>Total {props.course.parts[0].exercises + props.course.parts[1].exercises+ props.course.parts[2].exercises} exercises</p>
    </div>
  )
}
const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      < Header course ={course}/>
      <Contents course={course}/>
      <Total course={course}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
//reportWebVitals();
