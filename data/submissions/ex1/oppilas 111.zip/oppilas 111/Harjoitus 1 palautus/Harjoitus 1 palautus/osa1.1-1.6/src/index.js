import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0, neutraali: 0, huono:0, yhteensa:0
    }
    
  }
  kasvataHyva = () => {
    this.setState({ 
      hyva: this.state.hyva + 1, 
      yhteensa:this.state.yhteensa+1})
  }
  kasvataNeutraali = () => {
    this.setState({ 
      neutraali: this.state.neutraali + 1,
      yhteensa:this.state.yhteensa+1})
  }
  kasvataHuono = () => {
    this.setState({ 
      huono: this.state.huono + 1,
      yhteensa:this.state.yhteensa+1})
  }
  
  

  render() {
    return (
      <div>
        <h1>Anna palautetta</h1>
        <div>
        <Button
          handleClick={this.kasvataHyva}
          text="Hyvä"
        />
        <Button
          handleClick={this.kasvataNeutraali}
          text="Neutraali"
        />
        <Button
          handleClick={this.kasvataHuono}
          text="Huono"
        />
        </div>
        <Statistics stats= {this.state}/>
      </div>
    )
  }
}

const Button = ({handleClick, text}) =>(
  <button onClick={handleClick}>
    {text}
  </button>

)

const Statistic = (props) =>{
  return(
    <tr>
      <td>{props.nimi}</td>
      <td>{props.stat}</td>
    </tr>
  )
}
  

const Statistics = (props) =>{
  const otsikko = 'Statistiikka:'

  if (props.stats.yhteensa===0){
    return(
      <div>
        <h1>{otsikko}</h1>
        <em> Ei yhtään palautetta annettu</em>
      </div>
    )
  }

  return (
    <div>
      <h1>{otsikko}</h1>
      <table>
        <tbody>
          <Statistic stat={props.stats.hyva} nimi="Hyvä: " />
          <Statistic stat={props.stats.neutraali} nimi="Neutraali: " />
          <Statistic stat={props.stats.huono} nimi="Huono: " />
          <Statistic stat={props.stats.yhteensa} nimi="Yhteensä: " />
          <Statistic stat={(props.stats.hyva * 1 + props.stats.neutraali * 0 + props.stats.huono * -1) / props.stats.yhteensa} nimi="Keskiarvo: " />
          <Statistic stat={(props.stats.hyva / props.stats.yhteensa) * 100} nimi="Positiivisia prosentteina:" />
        </tbody>
      </table>

      
    </div>
  )
}


ReactDOM.render(
  <App />,
  document.getElementById('root')
)
