import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props)=>{
  return(<div><h2>{props.course}</h2></div>)
  
}

const Contents = (props)=>{
  return(<div>{props.part1}
  {props.part2}
  {props.part3}</div>)
  
}
const Total = (props)=>{
  return(
    <div>{props.sum}</div>
  )
  
}


const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = 'Basics of React'
  const exercises1 = 8
  const part2 = 'Using props'
  const exercises2 = 10
  const part3 = 'Component states'
  const exercises3 = 12
  const sum = exercises1 + exercises2 + exercises3
  return (
    <div>
      <Header course={course} />
      <Contents part1 = {part1}   />
      <Contents part2 = {part2} />
      <Contents part3 = {part3} />
      Total of <Total sum = {sum} /> exercisesasdads
      
    </div>)
  
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)