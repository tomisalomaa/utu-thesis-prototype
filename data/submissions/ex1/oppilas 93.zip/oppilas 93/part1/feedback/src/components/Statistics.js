import Statistic from "./Statistic";

const Statistics = ({ feedback }) => {
    if (feedback.good === 0 && feedback.neutral === 0 && feedback.poor === 0) {
        return <p>ei yhtään palautetta annettu</p>
    }

    const avg = ((feedback.good * 1 + feedback.poor * -1) / (feedback.good + feedback.neutral + feedback.poor)).toFixed(1);
    const positive = ((feedback.good * 100) / (feedback.good + feedback.neutral + feedback.poor)).toFixed(1);

    return (
        <table>
            <tbody>
                <Statistic name="hyvä" value={feedback.good} />
                <Statistic name="neutraali" value={feedback.neutral} />
                <Statistic name="huono" value={feedback.poor} />
                <Statistic name="keskiarvo" value={avg} />
                <Statistic name="positiivisia" value={`${positive} %`} />
            </tbody>
        </table>
    );
}

export default Statistics;