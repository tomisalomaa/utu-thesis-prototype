import React, { useState } from "react";
import ReactDOM from "react-dom";

import Button from "./components/Button";
import Statistics from "./components/Statistics";

class App extends React.Component {
  constructor() {
    super();

    this.state = {
      goodFeedback: 0,
      neutralFeedback: 0,
      poorFeedback: 0
    }
  }

  render() {
    return (
      <>
        <h2>anna palautetta</h2>
        <Button onClick={() => this.setState({ goodFeedback: this.state.goodFeedback + 1 })}>hyvä</Button>
        <Button onClick={() => this.setState({ neutralFeedback: this.state.neutralFeedback + 1 })}>neutraali</Button>
        <Button onClick={() => this.setState({ poorFeedback: this.state.poorFeedback + 1 })}>huono</Button>

        <h2>statistiikka</h2>
        <Statistics feedback={{
          good: this.state.goodFeedback,
          neutral: this.state.neutralFeedback,
          poor: this.state.poorFeedback
        }} />
      </>
    )
  }
}

/**
 * Hooksit on mulle tutumpia, tein tän ensin.
 * Mut tein tohon ylös myös luokkana tän. Molemmat toimii samanlailla.
 * Tätä voi kokeilla muuttamalla riviltä 66 <App /> -> <AppHooks />
 */
const AppHooks = () => {

  const [goodFeedback, setGoodFeedback] = useState(0);
  const [neutralFeedback, setNeutralFeedback] = useState(0);
  const [poorFeedback, setPoorFeedback] = useState(0);

  return (
    <>
      <h2>anna palautetta</h2>
      <Button onClick={() => setGoodFeedback(goodFeedback + 1)}>hyvä</Button>
      <Button onClick={() => setNeutralFeedback(neutralFeedback + 1)}>neutraali</Button>
      <Button onClick={() => setPoorFeedback(poorFeedback + 1)}>huono</Button>

      <h2>statistiikka</h2>
      <Statistics feedback={{
        good: goodFeedback,
        neutral: neutralFeedback,
        poor: poorFeedback
      }} />
    </>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);