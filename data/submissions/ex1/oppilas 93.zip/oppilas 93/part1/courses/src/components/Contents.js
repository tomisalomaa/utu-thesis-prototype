import Part from "./Part";

const Contents = ({ parts }) => {
    return (
        <>
        {parts.map(part => 
            <Part key={part.name} part={part} />
        )}
        </>
    )
}

export default Contents;