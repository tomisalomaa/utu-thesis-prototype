const Total = ({ parts }) => {
    const total = parts.reduce((a, b) => a + b["exercises"], 0); // a = aiemmin laskettu arvo / aloitusarvo, b = nykyinen arvo

    return (
        <p>Total { total } exercises.</p>
    )
}

export default Total;