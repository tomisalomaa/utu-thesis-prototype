const Header = ({ course }) => {
    return (
        <h2>{ course }</h2>
    )
}

export default Header;