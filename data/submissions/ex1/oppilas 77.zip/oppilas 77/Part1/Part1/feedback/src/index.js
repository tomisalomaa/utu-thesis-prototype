import React from 'react'
import ReactDOM from 'react-dom'


const Button = ({handleClick, text}) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = ({hyva, neutraali, huono}) => {
    return (
      <table>
        <tbody>
        <tr>
          <td>Hyvä</td>
          <td>{hyva}</td>
        </tr>
        <tr>
          <td>Neutraali</td>
          <td>{neutraali}</td>
        </tr>
        <tr>
          <td>Huono</td>
          <td>{huono}</td>
        </tr>
        <Statistic nimi="Keskiarvo" hyva={hyva} neutraali={neutraali}
        huono={huono} />
          <Statistic nimi="Prosentti" hyva={hyva} neutraali={neutraali}
          huono={huono} />
          </tbody>
      </table>
    )
}

const Statistic = ({nimi, hyva, neutraali, huono}) => {
  if (nimi == "Prosentti"){
     var prosentti = hyva/(hyva+neutraali+huono)
    return (
      <tr>
        <td>Positiivisia</td>
        <td>{prosentti}</td>
      </tr>
    )
  }
  var keskiarvo = (hyva + (huono*(-1))) /(hyva+neutraali+huono)
  return (
    <tr>
        <td>Keskiarvo</td>
        <td>{keskiarvo}</td>
    </tr>
  )  
}

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0,
      yhteensa: 0
    }
  }

  render() {
    const statsit = () => {
      if (this.state.yhteensa === 0) {
        return (
          <div>
            <em>Ei yhtään palautetta annettu.</em>
          </div>
        )
      }
      return (
        <Statistics hyva={this.state.hyva} neutraali={this.state.neutraali}
        huono={this.state.huono}/>
      )
    }
    return (
      <div>
        <h1>Anna palautetta</h1>
        <div>
          <Button
          handleClick={() => this.setState({ hyva: this.state.hyva + 1,
          yhteensa: this.state.hyva +1})}
          text="Hyvä"
          />
           <Button
          handleClick={() => this.setState({ neutraali: this.state.neutraali + 1,
            yhteensa: this.state.hyva +1 })}
          text="Neutraali"
          />
           <Button
          handleClick={() => this.setState({ huono: this.state.huono + 1,
            yhteensa: this.state.hyva +1 })}
          text="Huono"
          />
        </div>
        <h2>Statistiikka</h2>
        <div>{statsit()}</div>
      </div>
    )
  }
}

ReactDOM.render(<App />, document.getElementById('root'))
