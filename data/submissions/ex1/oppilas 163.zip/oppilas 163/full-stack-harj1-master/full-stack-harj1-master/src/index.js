import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import reportWebVitals from './reportWebVitals';



class App extends React.Component{
  constructor() {
    super()
    this.state={
      goodFeedback:0,
      neutralFeedback:0,
      poorFeedback:0,
      keskiarvo:null

    }
  }
  

  // #TODO LUE STATEFUL COMPONEN ETEENPÄIN UUDESTAAN JA MIETI TÄÄ ALUSTA ASTI
  
    render(){
      return(
      <div>
        <h2>Anna palautetta</h2>
        <button onClick={()=> this.setState({goodFeedback: this.state.goodFeedback +1})}>Hyvä</button>
        <button onClick={()=> this.setState({neutralFeedback: this.state.neutralFeedback +1})}>Neutraali</button>
        <button onClick={()=> this.setState({poorFeedback: this.state.poorFeedback +1})}>Huono</button>
        <h2>Statistiikka</h2>
        <p>Hyvä {this.state.goodFeedback}</p>
        <p>Neutraali {this.state.neutralFeedback}</p>
        <p>Huono {this.state.poorFeedback}</p>

  
      </div>
    )
  }
}




ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
