import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = {
    name: 'Basics of React',
    exercises: 8
  }
  const part2 = {
    name: 'Using props',
    exercises: 10
  }
  const part3 = {
    name: 'Component states',
    exercises: 12
  }

  const Header = () => {
    return (
      <h1>{course}</h1>
    )
  }

  const Contents = () => {
    return (
      <div>
        <p>{part1.name} {part1.exercises}</p>
        <p>{part2.name} {part2.exercises}</p>
        <p>{part3.name} {part3.exercises}</p>
      </div>
    )
  }

  const Total = () => {
    return (
      <p>Total {part1.exercises + part2.exercises + part3.exercises} exercises</p>
    )
  }

  return (
    <div>
      <Header course={course} />
      <Contents />
      <Total />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)