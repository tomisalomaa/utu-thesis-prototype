import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const parts = [
    {
      name: 'Basics of React',
      exercises: 8
    },
    {
      name: 'Using props',
      exercises: 10
    },
    {
      name: 'Component states',
      exercises: 12
    }
  ]

  const Part = (props) => {
    return (
      <p>{parts[props.index].name} {parts[props.index].exercises}</p>
    )
  }

  const Header = () => {
    return (
      <h1>{course}</h1>
    )
  }

  const Contents = () => {
    return (
      <div>
        <Part index={0} />
        <Part index={1} />
        <Part index={2} />
      </div>
    )
  }

  const Total = () => {
    return (
      <p>Total {parts[0].exercises + parts[1].exercises + parts[2].exercises} exercises</p>
    )
  }

  return (
    <div>
      <Header course={course} />
      <Contents />
      <Total />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)