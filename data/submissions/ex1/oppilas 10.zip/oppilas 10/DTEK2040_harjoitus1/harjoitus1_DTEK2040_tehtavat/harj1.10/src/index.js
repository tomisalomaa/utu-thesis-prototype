import React, { useState } from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      huono: 0,
      neutraali: 0,
      positiiviset: 0,
      aanet: 0,
      kaikkiAanet:0
    }
    
  }

  kasvataYhdellaHyva(){
    this.setState({ hyva: this.state.hyva + 1 })
    this.setState({aanet: this.state.aanet + 1 })
    this.setState({kaikkiAanet: this.state.kaikkiAanet + 1 })
  }
  kasvataYhdellaNeutraali(){
    this.setState({ neutraali: this.state.neutraali + 1 })
    this.setState({aanet: this.state.aanet + 0})
    this.setState({kaikkiAanet: this.state.kaikkiAanet + 1 })
  }
  kasvataYhdellaHuono(){
    this.setState({ huono: this.state.huono + 1 })
    this.setState({aanet: this.state.aanet - 1})
    this.setState({kaikkiAanet: this.state.kaikkiAanet + 1 })
  }
 
  
 
  render() {
    return (
      
      <div id="sivu">
        
        <h3>Anna palautetta</h3>
        <div>
          <button onClick={this.kasvataYhdellaHyva.bind(this)}>
            Hyvä
          </button>
          
          <button onClick={this.kasvataYhdellaNeutraali.bind(this)}>
            Neutraali
          </button>

          <button onClick={this.kasvataYhdellaHuono.bind(this)}>
            Huono
          </button>

        </div>
        
        <h3>Statistiikka</h3>
          <table>
            <tbody>
              <tr>
                <td>Hyvä </td>
                <td>{this.state.hyva}</td>
              </tr>
              <tr>
                <td>Neutraali </td>
                <td>{this.state.neutraali}</td>
              </tr>
              <tr>
                <td>Huono </td>
                <td>{this.state.huono}</td>
              </tr>
              <tr>
                <td>Keskiarvo </td>
                <td>{String(this.state.aanet / this.state.kaikkiAanet)}</td>
              </tr>
              <tr>
                <td>positiivisia </td>
                <td>{((this.state.hyva)/(this.state.neutraali + this.state.huono + this.state.hyva))*100}%</td>
              </tr>
            </tbody>
          </table>
          

      </div>
    )
  }
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)
