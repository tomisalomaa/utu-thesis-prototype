import React from 'react'
import ReactDOM from 'react-dom'


const Part = (props) => {
  return (
    <div>
      Kurssin osa ja harjoitusten määrä:  {props.exercises} {props.name}
    </div>
  )
}

const Header = (props) => {
  return (
    <div>
      <p>Kurssin nimi: {props.course} </p>
    </div>
  )
}
const Contents = (props) => {
  return (
    <div>
      <Part exercises = {props.exercises.part1} name = {props.exercises.exercise1} />
      <Part exercises = {props.exercises.part2} name = {props.exercises.exercise2}/>
      <Part exercises = {props.exercises.part3} name = {props.exercises.exercise3}/>
    </div>
  )
}
const Total = (props) => {
  return (
    <div>
      <p>Harjoitusten määrä: {props.maara}</p>
    </div>
  )
}


const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = {
    name: 'Basics of React',
    exercises: 8
  }
  const part2 = {
    name: 'Using props',
    exercises: 10
  }
  const part3 = {
    name: 'Component states',
    exercises: 12
  }

  return (
     
    <div>
      <Header course={course}/>
      <Contents exercises={{part1:part1.name, exercise1:part1.exercises, part2:part2.name, exercise2:part2.exercises, part3:part3.name, exercise3:part3.exercises}}/>
    
      <Total maara={part1.exercises + part2.exercises + part3.exercises}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

