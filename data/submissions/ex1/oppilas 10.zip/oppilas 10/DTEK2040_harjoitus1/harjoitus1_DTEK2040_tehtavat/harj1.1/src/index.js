import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <p>Kurssin nimi: {props.course} </p>
    </div>
  )
}
const Contents = (props) => {
  return (
    <div>
      <p>{props.part} {props.excercise}</p>
    </div>
  )
}
const Total = (props) => {
  return (
    <div>
      <p>Harjoitusten määrä: {props.maara}</p>
    </div>
  )
}


const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = 'Basics of React'
  const exercises1 = 8
  const part2 = 'Using props'
  const exercises2 = 10
  const part3 = 'Component states'
  const exercises3 = 12


  return (
    <div>
      <Header course={course}/>
      <Contents part={part1} excercise={exercises1} />
      <Contents part={part2} excercise={exercises2} />
      <Contents part={part3} excercise={exercises3} />
      <Total maara={exercises1 + exercises2 + exercises3}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
