import React from 'react'
import ReactDOM from 'react-dom'


const Part = (props) => {
  return (
    <div>
      <p>Kurssin osa ja harjoitusten määrä:  {props.exercises} {props.name}</p>
    </div>
  )
}

const Header = (props) => {
  return (
    <div>
      <p>Kurssin nimi: {props.course} </p>
    </div>
  )
}
const Contents = (props) => {
  return (
    <div>
      <Part exercises = {props.exercises}  />
    </div>
  )
}
const Total = (props) => {
  return (
    <div>
      <p>Harjoitusten määrä: {props.maara}</p>
    </div>
  )
}

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
   
      name1: 'Basics of React',
      exercises1: 8,
      
      name2: 'Using props',
      exercises2: 10,
      
      
      name3: 'Component states',
      exercises3: 12,
      
    
  }

  return (
     
    <div>
      <Header course={course.name}/>
      <Contents exercises={course.name1 + " " + course.exercises1}/>
      <Contents exercises={course.name2 + " " + course.exercises2}/>
      <Contents exercises={course.name3 + " " + course.exercises3}/>
      <Total maara={course.exercises1 + course.exercises2 + course.exercises3}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
//<Contents exercises={{part1:course.parts[0].name, exercise1:course.parts[0].exercises, part2:course.parts[1].name, exercise2:course.parts[1].exercises, part3:course.parts[2].name, exercise3:course.parts[2].exercises}}/>

    
//
