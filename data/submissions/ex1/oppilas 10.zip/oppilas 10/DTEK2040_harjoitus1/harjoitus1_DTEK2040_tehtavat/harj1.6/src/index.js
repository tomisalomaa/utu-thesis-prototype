import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 1,
      huono: 1,
      neutraali: 1
    }
  }

  kasvataYhdellaHyva(){
    this.setState({ hyva: this.state.hyva + 1 })
  }
  kasvataYhdellaNeutraali(){
    this.setState({ neutraali: this.state.neutraali + 1 })
  }
  kasvataYhdellaHuono(){
    this.setState({ huono: this.state.huono + 1 })
  }


  render() {
    return (
      <div>
        <h3>Anna palautetta</h3>
        <div>
          <button onClick={this.kasvataYhdellaHyva.bind(this)}>
            Hyvä
          </button>
          
          <button onClick={this.kasvataYhdellaNeutraali.bind(this)}>
            Neutraali
          </button>

          <button onClick={this.kasvataYhdellaHuono.bind(this)}>
            Huono
          </button>

        </div>
        
        <h3>Statistiikka</h3>
          <div>
            <p>Hyvä: {this.state.hyva}</p> 
            <p>Neutraali: {this.state.neutraali} </p> 
            <p>Huono: {this.state.huono}</p> 

          </div>
          

      </div>
    )
  }
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)
