import React from 'react'
import ReactDOM from 'react-dom'


const Part = (props) => {
  return (
    <div>
      <p>Kurssin osa ja harjoitusten määrä:  {props.exercises} {props.name}</p>
    </div>
  )
}

const Header = (props) => {
  return (
    <div>
      <p>Kurssin nimi: {props.course} </p>
    </div>
  )
}
const Contents = (props) => {
  return (
    <div>
      <Part exercises = {props.exercises}  />
    </div>
  )
}
const Total = (props) => {
  return (
    <div>
      <p>Harjoitusten määrä: {props.maara}</p>
    </div>
  )
}

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
     
    <div>
      <Header course={course.name}/>
      <Contents exercises={course.parts[0].name + " " + course.parts[0].exercises}/>
      <Contents exercises={course.parts[1].name + " " + course.parts[1].exercises}/>
      <Contents exercises={course.parts[2].name + " " + course.parts[2].exercises}/>
      <Total maara={course.parts[0].exercises + course.parts[1].exercises + course.parts[2].exercises}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
//<Contents exercises={{part1:course.parts[0].name, exercise1:course.parts[0].exercises, part2:course.parts[1].name, exercise2:course.parts[1].exercises, part3:course.parts[2].name, exercise3:course.parts[2].exercises}}/>

    
//
