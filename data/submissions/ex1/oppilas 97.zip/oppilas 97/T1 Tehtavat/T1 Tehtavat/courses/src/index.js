import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header kurssi={course.name} />
      <Contents osa1={course.parts[0].name} osa2={course.parts[1].name} osa3={course.parts[2].name} 
      tehtava1={course.parts[0].exercises} tehtava2={course.parts[1].exercises} tehtava3={course.parts[2].exercises}/>
      <Total tehtavat1={course.parts[0].exercises} tehtavat2={course.parts[1].exercises} tehtavat3={course.parts[2].exercises}/>   
    </div>
  )
}

const Header = (props) =>{
  return(
    <div> 
      <h1>{props.kurssi}</h1> 
    </div>
  )
}

const ContentsPart = (props) =>{
return(
  <div>
      <p>{props.osa} {props.tehtava}</p>

  </div>
)
}

const Contents = (props) => {

  return(
    <div>
      <ContentsPart osa={props.osa1} tehtava={props.tehtava1} />
      <ContentsPart osa={props.osa2} tehtava={props.tehtava2} />
      <ContentsPart osa={props.osa3} tehtava={props.tehtava3} />
    </div>

  )
}

const Total = (props) =>{
  return(
    <div>
      <p>Total {props.tehtavat1 + props.tehtavat2 + props.tehtavat3} exercises</p>
    </div>


  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
