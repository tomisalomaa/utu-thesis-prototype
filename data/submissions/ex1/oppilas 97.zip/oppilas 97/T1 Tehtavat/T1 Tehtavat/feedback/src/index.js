import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor() {
    super() 
    
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }
  }

  posPalaute = (arvo) => {
    return () => {
      this.setState({hyva: arvo})
    }
  }

  neuPalaute = (arvo) => {
    return () => {
      this.setState({neutraali: arvo})
    }
  }

  huoPalaute = (arvo) => {
    return () => {
      this.setState({huono: arvo})
    }
  }

  render() {
    return(
      
      <div>
      <Button hyva={this.posPalaute(this.state.hyva + 1)} 
      neutraali={this.neuPalaute(this.state.neutraali + 1)}
      huono={this.huoPalaute(this.state.huono + 1)} 
      />
      
      <Statistics hyva={this.state.hyva} neutraali={this.state.neutraali} 
      huono={this.state.huono} />
    </div>
    )
  }
}
 
const Button = (props) => {
  return(
    <div>
      <h1>Anna palautetta</h1>
      <button onClick={props.hyva}> hyva</button>
      <button onClick={props.neutraali}> neutraali</button>
      <button onClick={props.huono}> huono</button>
    </div>
  )
}

const Statistic = ({keskiarvo}) => <td>{keskiarvo}</td>
const Statistics = (props) => {
  
  if (props.hyva === 0 & props.neutraali === 0 & props.huono === 0) {
    return(    
    <div>
      <em>Anne meille arvostelu!</em>
    </div>)
  }
  return(
    <div>
      <h1>Statistiikka</h1>
        <table>
          <tr>
            <td>hyvä</td> <td>{props.hyva}</td>
          </tr>
          <tr>
            <td>neutraali</td> <td>{props.neutraali}</td>
          </tr>
          <tr>
            <td>huono</td> <td>{props.huono}</td>
          </tr>
          <tr>
          <td>keskiarvo</td> <Statistic keskiarvo={((props.hyva-(props.huono))/(props.hyva + props.neutraali + props.huono)).toFixed(1)}/>
          </tr>
          <tr>
            <td>positiivisia</td> <td>{((100*(props.hyva))/(props.hyva + props.neutraali + props.huono)).toFixed(1)}%</td>
          </tr>
        </table>
    </div>
  )
}


ReactDOM.render(<App />, document.getElementById('root'))
