import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <p> {props.otsikko} </p>
    </div>
  )
}

const Contents = (props) => {
  return (
    <div>
      <Part nimi1={props.osa[0]["name"]} luku1={props.osa[0]["exercises"]}/>
      <Part nimi2={props.osa[1]["name"]} luku2={props.osa[1]["exercises"]}/>
      <Part nimi3={props.osa[2]["name"]} luku3={props.osa[2]["exercises"]}/>
    </div>
  )
}

const Part = (props) => {
  return (
    <div>
      <p> {props.nimi1} {props.luku1} </p>
      <p> {props.nimi2} {props.luku2}</p>
      <p> {props.nimi3} {props.luku3}</p>
    </div>
  )
}

const Total = (props) => {
  return (
    <p> Total {props.osa[0]["exercises"]+props.osa[1]["exercises"]+props.osa[2]["exercises"]} exercises </p>
  )
}

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }


  return (
    <div>
      <Header otsikko={course.name} />
      <Contents osa={course.parts} />
      <Total osa={course.parts} />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
