import React from 'react'
import ReactDOM from 'react-dom'

const Statistics = (props) => {
  let summa = props.luvut[0] + props.luvut[1] + props.luvut[2]
  let prosentti = 100 * (props.luvut[0] / summa)
  let arvosumma = props.luvut[0] * 1 + props.luvut[1] * 0 + props.luvut[2] * (-1)
  let keskiarvo = arvosumma / summa

  if (summa === 0) {
    return (
      <div>
        <em>Ei yhtään palautetta annettu</em>
      </div>
    )
  }
  return (
    <table>
      <tbody>
        <tr>
          <td> Hyvä</td>
          <td>{props.luvut[0]}</td>
        </tr>
      </tbody>
      <tbody>
        <tr>
          <td>Neutraali</td>
          <td>{props.luvut[1]}</td>
        </tr>
      </tbody>
      <tbody>
        <tr>
          <td>Huono</td>
          <td>{props.luvut[2]}</td>
        </tr>
      </tbody>
      <tbody>
        <tr>
          <td>Keskiarvo</td>
          <td>{keskiarvo.toFixed(1)} </td>
        </tr>
      </tbody>
      <tbody>
        <tr>
          <td>Positiivisia</td>
          <td>{prosentti.toFixed(1)}% </td>
        </tr>
      </tbody>
    </table>
  )
}

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }
  }

  asetaHuono = (arvo) => () => this.setState({ huono: arvo })

  asetaNeutraali = (arvo) => () => this.setState({ neutraali: arvo })

  asetaHyva = (arvo) => () => this.setState({ hyva: arvo })

  render() {
    const luvut = [this.state.hyva, this.state.neutraali, this.state.huono]
    return (
      <div>
        <h1>Anna palautetta</h1>
        <div>
          <Button
            handleClick={this.asetaHuono(this.state.huono + 1)}
            text="Huono" />
          <Button
            handleClick={this.asetaNeutraali(this.state.neutraali + 1)}
            text="Neutraali" />
          <Button
            handleClick={this.asetaHyva(this.state.hyva + 1)}
            text="Hyvä" />
        </div>
        <h2>Statistiikka</h2>
        <Statistics luvut={luvut} />
      </div>
    )
  }
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)
