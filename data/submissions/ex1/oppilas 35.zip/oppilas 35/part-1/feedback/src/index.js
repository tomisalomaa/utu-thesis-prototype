import React from 'react'
import ReactDOM from 'react-dom'

const Button = ({clickHandle, text}) => {
  return (<button onClick={clickHandle}>{text}</button>)
}

const Statistic = ({data, text}) => {
  return (
    <tr>
      <td>{text}</td>
      <td>{data}</td>
    </tr>
  )
}

const Statistics = ({state: {good, neutral, bad}}) => {
  const average = () => {
    return ((good-bad) / (good+neutral+bad)).toPrecision(3)
  }

  const positive = () => {
    return ((good / (good+neutral+bad)) * 100).toPrecision(3).concat(" %")
  }

  if ((good+neutral+bad) === 0) {
    return (
      <div>
        <h1>Statistics</h1>
        <p>No feedback available</p>
      </div>
    )
  }

  return (
    <div>
      <h1>Statistics</h1>
      <table>
        <tbody>
          <Statistic data={good} text="Good" />
          <Statistic data={neutral} text="Neutral" />
          <Statistic data={bad} text="Bad" />
          <Statistic data={average()} text="Average" />
          <Statistic data={positive()} text="Positive"/>
        </tbody>
      </table>
    </div>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0
    }
  }

  fb_good = () => {
    this.setState({good: this.state.good + 1})
  }

  fb_neutral = () => {
    this.setState({neutral: this.state.neutral + 1})
  }

  fb_bad = () => {
    this.setState({bad: this.state.bad + 1})
  }

  render(){
    return (
      <div>
        <h1>Give feedback</h1>
        <div>
          <Button clickHandle={this.fb_good} text="Good" />
          <Button clickHandle={this.fb_neutral} text="Netral" />
          <Button clickHandle={this.fb_bad} text="Bad" />
        </div>
        <Statistics state={this.state} />
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
