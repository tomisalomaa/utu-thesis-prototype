import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => <h1>{props.phonebookapp}</h1>
const Part = ({part}) => <p>{part.name} {part.phonenumber}</p>
const Contents = ({parts}) => {
  return (
      <div>
          <Part part={parts[0]} />
          <Part part={parts[1]} />
          <Part part={parts[2]} />
      </div>
  )
}
const App = () => {
    const phonebookapp = {
        name: 'Superadvanced web phonebook app',
        parts: [
          {
            name: 'John Doe',
            phonenumber: '358401234567'

          },
          {
            name: 'Jane Doe',
            phonenumber: '44551234567'
          },
          {
            name: 'Foo bar',
            phonenumber: '000'
          }
        ]
      }

  return (
    <div>
        <Header phonebookapp={phonebookapp.name} />
        <Contents parts={phonebookapp.parts} />
       </div>
  )
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)
