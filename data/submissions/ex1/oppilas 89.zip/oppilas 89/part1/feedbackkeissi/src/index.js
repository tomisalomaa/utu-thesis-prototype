import React from 'react'
import ReactDOM from 'react-dom'

const Statistic = (props) => <tr><td>{props.text}</td><td>{props.value}</td></tr>

const Statistics = (props) => {
  if(props.hyva + props.neutraali + props.huono > 0) {
    return( 
      
      <table>
      <tbody>
        <Statistic text={"Hyvä"}  value={props.hyva}/>
        <Statistic text={"Neutraali"}  value={props.neutraali}/>
        <Statistic text={"Huono"}  value={props.huono}/>
        <Statistic text={"Keskiarvo"}  value={props.keskiarvo}/>
        <Statistic text={"Positiivisia"}  value={props.positiivisia}/>
      </tbody>
      </table>
      )
  }
  else return <p>Palautetta ei anettu.</p>
}

const Button = (props) => (
    <button onClick={props.handleClick}>
        {props.text}
    </button>
)

class Palaute extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            hyva: 0,
            neutraali: 0,
            huono: 0
        };
    }

    hyvaPalaute = ()=> { this.setState({ hyva: this.state.hyva + 1}) }
    neutraaliPalaute = ()=> { this.setState({ neutraali: this.state.neutraali + 1}) }
    huonoPalaute = ()=> { this.setState({ huono: this.state.huono + 1}) }
    
    positiivinen =()=> {
      const jakaja = this.state.huono + this.state.hyva + this.state.neutraali

      if(jakaja>0) 
      return (this.state.hyva / jakaja * 100).toFixed(1) + "%"
      else return "0%"

    }
    keskiarvo = () => {
      const jakaja = this.state.huono + this.state.hyva + this.state.neutraali
      const jaettava = this.state.hyva - this.state.huono

      if(jakaja > 0) 
      return parseFloat(jaettava/jakaja).toFixed(1)
      else return 0

    }
  render() {

      return (
        <div>
            <h1>Anna palautetta</h1>
            <Button handleClick={this.hyvaPalaute} text="Hyvä" />
            <Button handleClick={this.neutraaliPalaute} text="Neutraali" />
            <Button handleClick={this.huonoPalaute} text="Huono" />
            <h1>Statistiikka</h1>
            <Statistics hyva={this.state.hyva} neutraali={this.state.neutraali} huono={this.state.huono} keskiarvo={this.keskiarvo()} positiivisia={this.positiivinen()} />
        </div>
      );
    }
  }

  ReactDOM.render(
    <Palaute />,
    document.getElementById('root')
  );
