import React from 'react'
import ReactDOM from 'react-dom'

const Contents = (props) => {
  return (
    <div>
      <Part name={props.parts[0].name} Part exercises={props.parts[0].exercises}/>
      <Part name={props.parts[1].name} Part exercises={props.parts[1].exercises}/>
      <Part name={props.parts[2].name} Part exercises={props.parts[2].exercises}/>
  </div>
  )
}
const Part = (props) => {
  return (
    <div>
      <p>{props.name} {props.exercises}</p>
    </div>
  )
}
const Header = (props) => {
  return (
    <div>
      {props.course.name}
    </div>
  )
}

const Total = (props) => {
  return (
    <div>
      {(props.course.parts[0].exercises) + (props.course.parts[1].exercises) + (props.course.parts[2].exercises)}
    </div>
  )
}

const App = () => {
  const course = {
    name: <h1>Superadvanced web and mobile programming</h1>,
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course}/>
      <Contents parts={course.parts}/>
      <Total course={course}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)