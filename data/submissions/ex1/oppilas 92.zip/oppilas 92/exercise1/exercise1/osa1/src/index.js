import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <p>{props.course}</p>
    </div>
  )
}

const Contents = (props) => {
  return (
    <div>
      <p>{props.name} {props.exercises}</p>
    </div>
  )
}

const Total = (props) => {
  return (
    <div>
      <p>{props.part}</p>
    </div>
  )
}

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const parts = [
    {
      name: 'Basics of React',
      exercises: 8
    },
    {
      name: 'Using props',
      exercises: 10
    },
    {
      name: 'Component states',
      exercises: 12
    }
  ]

  return (
    <div>
      <Header course={course} />
      <Contents name={parts[0].name} exercises={parts[0].exercises}/>
      <Contents name={parts[1].name} exercises={parts[1].exercises}/>
      <Contents name={parts[2].name} exercises={parts[2].exercises}/>
      <Total part = {parts[0].exercises + parts[1].exercises + parts[2].exercises} />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)