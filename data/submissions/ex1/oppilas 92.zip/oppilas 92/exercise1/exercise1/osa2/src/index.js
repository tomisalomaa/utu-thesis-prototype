import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      Good: 0,
      Neutral: 0,
      Poor: 0,
      good: [],
      neutral : [],
      poor: []
    }
  }

  first = () => {
    this.setState({
      Good: this.state.Good + 1,
      good: this.state.good.concat('x')
    })
  }

  second = () => {
    this.setState({
      Neutral: this.state.Neutral + 1,
      neutral : this.state.neutral .concat('x')
    })
  }

  third = () => {
    this.setState({
      Poor: this.state.Poor + 1,
      poor : this.state.poor .concat('x')
    })
  }

  

  render() {

    const List = (props) => {
      return (
        <div>
          <p>{props.history}</p>
        </div>
        
      )
    }

    const Statistic = (props) => {
      return (
        <div>
          <table>
            <tr>
              <td>average:</td>
              <td>{props.average}</td>
            </tr>
            <tr>
              <td>percentage:</td>
              <td>{props.percentage}</td>
            </tr>
          </table>
        </div>
      )
    }

    const average = () => (this.state.good.length * 1 - this.state.poor.length * 1)/10

    const percentage = () => (this.state.good.length/(this.state.good.length + this.state.neutral.length + this.state.poor.length))*100 + "%"
    
    const History = () => {
      if (this.state.good.length === 0 & this.state.neutral.length ===0 & this.state.poor.length ===0) {
        return (
          <div>
            <p>no feedback yet</p>
          </div>
        )
      }
      return (
        <div>
          <table>
            <tr>
              <td>good:</td>
              <td>{this.state.good.length}</td>
            </tr>
            <tr>
              <td>neutral:</td>
              <td>{this.state.neutral.length}</td>
            </tr>
            <tr>
              <td>poor:</td>
              <td>{this.state.poor.length}</td>
            </tr>
          </table>
          <Statistic average={average()} percentage={percentage()}/>
        </div>
      )
    }

    const Button = ({ handleClick, text }) => (
      <button onClick={handleClick}>
        {text}
      </button>
    )

    return (
      <div>
        <div>
          <h1>Feedback</h1>
          <Button 
            handleClick={this.first}
            text="Good"/>
            <Button 
            handleClick={this.second}
            text="Neutral"/>
            <Button 
            handleClick={this.third}
            text="Poor"/>
          <h1>statistics</h1>
          <List history={History()}/>
        </div>
      </div>
    )
  }
}

ReactDOM.render(<App />, document.getElementById('root'))