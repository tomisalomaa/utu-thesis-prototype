import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  constructor() {
    super()
    this.state = { 
      counterHyva: 0,
      counterNeutraali : 0,
      counterHuono : 0,
      name : 'Anna Palautetta',
      nameStat : 'Statistiikka'


    }
  }

   asetaArvoon = (arvo) => {
    return () => {
      this.setState({ counterHyva: arvo })
    }
  }
  asetaArvoonNeutraali = (arvo) => {
    return () => {
      this.setState({ counterNeutraali: arvo })
    }
  }
  asetaArvoonHuono = (arvo) => {
    return () => {
      this.setState({ counterHuono: arvo })
    }
  }

  render() {
    return (
      <div>
        <div>
      <Header name={this.state.name}/>
      <Button 
        handleClick={this.asetaArvoon(this.state.counterHyva + 1)}
        text="Hyvä"
      />
      <Button 
        handleClick={this.asetaArvoonNeutraali(this.state.counterNeutraali + 1)}
        text="Neutraali"
      />
      <Button 
        handleClick={this.asetaArvoonHuono(this.state.counterHuono + 1)}
        text="Huono"
      />
      </div>
      <div>
      <Header name = {this.state.nameStat}/>
      {/* <Statistics hyva={this.state.counterHyva} neutraali={this.state.counterNeutraali} huono={this.state.counterHuono}/> */}
      <p>hyvä {this.state.counterHyva}</p>
      <p>neutraali {this.state.counterNeutraali}</p>
      huono {this.state.counterHuono}
      <p>keskiarvo <Keskiarvo hyva={this.state.counterHyva * 1} neutraali={this.state.counterNeutraali * 0} huono={this.state.counterHuono * -1}/></p>
      <p>positiivisia <Positiivinen hyva={this.state.counterHyva} neutraali={this.state.counterNeutraali} huono={this.state.counterHuono}/> % </p>
      </div>
      </div>
    

  )
}
}

const Statistics = (props) => {
  return(
    <div>
    <Keskiarvo hyva={props.this.state.counterHyva * 1} neutraali={props.this.state.counterNeutraali * 0} hyva={props.this.state.counterHuono * -1} />
    </div>
  )
}

const Button = (props) => (
  <button onClick={props.handleClick}>
    {props.text}
  </button>
)

const Keskiarvo = (props) => {
  return (props.hyva+props.neutraali+props.huono) / 3
}

const Positiivinen = (props) => {
  return (props.hyva / (props.hyva+props.neutraali+props.huono) * 100)
}

const Header = (props) => {
  return(
    <div>
      <h1>{props.name}</h1>
    </div>
  )
}

// const counter = {
//   value: 1
// }

ReactDOM.render(
  <App name />,
  document.getElementById('root')
)