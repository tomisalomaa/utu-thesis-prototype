import React from 'react'
import ReactDOM from 'react-dom'

// Feedback -tehtävä


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0,
      total: 0,
      current: 'none',
      average: 0,
      percentage: 0
      
    }
  }


  //setState kutsut eivät näköjään toteudu samassa järjestyksessä kuin ne on kirjoitettu koodiin
  
  klikGood = () => {
    this.setState({
      total: this.state.total + 1,
      good: this.state.good + 1,
      current: 'good',
      average: ((this.state.good +1) - this.state.bad) / (this.state.total +1) ,
      percentage: this.countPercentage(this.state.good)    
    })
  }


  klikNeutral = () => {
    this.setState({
      total: this.state.total + 1,
      neutral: this.state.neutral + 1,
      current: 'neutral',
      average: (this.state.good - this.state.bad) / (this.state.total +1),
      percentage: this.countPercentage(this.state.neutral)
    })
  }


  klikBad = () => {
    this.setState({
      total: this.state.total + 1,
      bad: this.state.bad + 1,
      current: 'bad',
      average: (this.state.good - (this.state.bad +1)) / (this.state.total +1),
      percentage: this.countPercentage(this.state.bad)
      
    })
  }

  /* Tätä ei käytetty:

    countAverage = () => {
    console.log('current on', this.state.current,'Keskiarvolasku',this.state.good ,'miinus', this.state.bad ,"jaettuna", this.state.total )
    return ((this.state.good) - (this.state.bad *-1)) / (this.state.total)
  }
        */

  countPercentage = (props) => {
    console.log('Prosentit:',props +1,'jaettuna', this.state.total +1, '*100')
    return (props +1) / (this.state.total +1) * 100
    }




render() {

  if (this.state.total === 0) {
    return (
      <div>
      <div>
        <h1>Give Feedback</h1>
        <button onClick={this.klikGood}>Good</button>
        <button onClick={this.klikNeutral}>Neutral</button>
        <button onClick={this.klikBad}>Bad</button>
        <p></p>
        <h1>Statistics</h1>      
      <p>No feedbacks yet!</p>
      </div>
      </div>
    )
  }

  else {


  return (
    <div>
      <div>
        <h1>Give Feedback</h1>
        <button onClick={this.klikGood}>Good</button>
        <button onClick={this.klikNeutral}>Neutral</button>
        <button onClick={this.klikBad}>Bad</button>
        <p></p>
        <h1>Statistics</h1>
        <table> 
        <tbody>
        <tr>
          <td>Good:</td>
          <td>{this.state.good}</td>
        </tr>
        <tr>
          <td>Neutral:</td>
          <td>{this.state.neutral}</td>
        </tr>
        <tr>
          <td>Bad:</td>
          <td>{this.state.bad}</td>
        </tr>
        <tr>
          <td>Average:</td>
          <td>{this.state.average}</td>
        </tr>
        <tr>
          <td>Percentage of {this.state.current}:</td>
          <td>{this.state.percentage} %</td>
        </tr>
        </tbody>
        </table>
       
      </div>
    </div>
  )}
}
}




  ReactDOM.render(
    <App />,
    document.getElementById('root')
  )