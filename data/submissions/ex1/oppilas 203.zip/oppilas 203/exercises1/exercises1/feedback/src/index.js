import React from 'react';
import ReactrOM from 'react-dom';


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0,
      total: 0
    }
    
  }
  countAverage() {
    const average = (this.state.good + this.state.bad * -1) / this.state.total;
    return(
      Number.parseFloat(average).toFixed(1)
    )
  }
  positiveRatio() {
    const ratio = this.state.good / this.state.total
    return(
      Number.parseFloat(ratio*100).toFixed(1)
    )
  }
 
  Button(counter, text){
    if(counter === 'good'){
      return(
        <button onClick={() => this.clickGood()}>{text}</button>
      )
    }
    if(counter === 'bad'){
      return(
        <button onClick={() => this.clickBad()}>{text}</button>
      )
    }
    if(counter === 'neutral'){
      return(
        <button onClick={() => this.clickNeutral()}>{text}</button>
      )
    } else {
      return(
        <p>counter doesn't exist</p>
      )
    }
  }
  clickBad(){
    this.setState({
      bad: this.state.bad + 1,
      total: this.state.total +1
    })
  }
  clickGood(){
    this.setState({
      good: this.state.good + 1,
      total: this.state.total +1
    })
  }
  clickNeutral(){
    this.setState({
      neutral: this.state.neutral + 1,
      total: this.state.total +1
    })
  }
 Statistics(){
    if(this.state.total > 0){
      return(
        <table>
          <tbody>
            <tr><td>{this.Statistic('hyvä', this.state.good)}</td></tr>
            <tr><td>{this.Statistic('neutraali', this.state.neutral)}</td></tr>
            <tr><td>{this.Statistic('huono', this.state.bad)}</td></tr>
            <tr><td>{this.Statistic('keskiarvo', this.countAverage())}</td></tr>
            <tr><td>{this.Statistic('positiivisia', this.positiveRatio())}</td></tr>
          </tbody>
        </table>
        
      )
    } else {
      return(
        <div>
          <p>ei yhtään palautetta annettu</p>
        </div>
      )
    }
 }
 Statistic(name, stat){
   return(
       <p>{name}  {stat}</p>
   )
 }
 Buttons(){
   return (
    <div>
      <h1>anna palautetta</h1>
      <p>{this.Button('good', 'hyvä')}
      {this.Button('neutral', 'neutraali')}
      {this.Button('bad', 'huono')}</p>
     </div>
   )
 }
 
  
  
  render() {
    return (
    <div>
      {this.Buttons()}
      <h1>statistiikka</h1>
      {this.Statistics()}
    </div>
  )
  }
}

ReactrOM.render(
  <App />,
  document.getElementById('root')
)



