import React from 'react'
import {useState} from "react"
import ReactDOM from 'react-dom'

const Statistics = (props) => {
	if (props.hyvä + props.neutraali + props.huono === 0) {
    return (
      <div>
        <h2>Palautetta ei ole annettu</h2>
      </div>
    )
  }
  
  return (
		<div>
			Hyvä: {props.hyvä} <br/>
			Neutraali: {props.neutraali} <br/>
			Huono: {props.huono} <br/>
		</div>
	)
}

const Statistic = (props) => {
  if (props.keskiarvo === 'NaN') {
    return (
      <div>
        <h2>Anna ensin palautetta</h2>
      </div>
    )
  }
  return (
    <div>
      Keskiarvo: {props.keskiarvo} <br/>
      Positiivisia: {props.positiiviset}
    </div>
  )
}

const App = () => {
  const [hyvä, hyväpalaute] = useState(0)
  const [neutraali, neutraalipalaute] = useState(0)
  const [huono, huonopalaute] = useState(0)
      
  return (
      
    <div>
      <h1>Annappa palautetta saakeli</h1>
      <br/>
      <button onClick = {() => hyväpalaute(hyvä+1)}>Hyvä</button>
      <button onClick = {() => neutraalipalaute(neutraali+1)}>Neutraali</button>
      <button onClick = {() => huonopalaute(huono+1)}>Huono</button>
      <br/>
      <h1>Tilastot:</h1> 
      <Statistics 
				hyvä = {hyvä}
				neutraali = {neutraali} 
				huono = {huono}
			/>
      <Statistic
        keskiarvo = {((hyvä - huono)/(hyvä + neutraali + huono)).toFixed(2)} 
        positiiviset = {((hyvä)/(hyvä + neutraali + huono)).toFixed(2)*100+"%"}
      />
      </div>
      )
  }

  ReactDOM.render(
    <App />,
    document.getElementById('root')
  )