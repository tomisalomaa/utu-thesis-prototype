import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
        
      {
        name: 'Using props',
        exercises: 10
      },

      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  const Header = (props) => {
    return (
      <div>
        <h1>{props.name}</h1>
      </div>
    )
  }
  
  const Contents = (props) => {
    return (
      <div>
        <p>
          <Part part = {props.parts[0].name} exercises = {props.parts[0].exercises}/>
          <Part part = {props.parts[1].name} exercises = {props.parts[1].exercises}/>
          <Part part = {props.parts[2].name} exercises = {props.parts[2].exercises}/>
        </p>
      </div>
    )
  }

  const Part = (props) => {
    return(
      <p>
        {props.part} {props.exercises}
      </p>
    )
  }
  
  const Total = (props) => {
    return (
      <div>
        <p>Number of exercises: {props.parts[0].exercises + props.parts[1].exercises + props.parts[2].exercises}</p>
      </div>
    )
  };

  return (
    
		<div>
      <Header name={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
    
	)
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)