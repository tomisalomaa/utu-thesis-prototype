import React from 'react'
import ReactDOM from 'react-dom'


const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>{text}</button>
)

const Statistic = ({text, value, symbol}) => {
  return (
  <>
  <td>{text}:</td>
  <td>{value}{symbol}</td>
  </>
  )
}

const Statistics = ({good, neutral, bad, average, positive}) => {
  if ((good + neutral + bad) === 0){
    return (
    <>
    <h2>Statistics:</h2>
    <p>No feedback given yet</p>
    </>
    )
  }

  return (
  <>
  <h2>Statistics:</h2>
  <table>
    <tbody>
      <tr><Statistic text={'Good'} value={good} symbol={''}/></tr>
      <tr><Statistic text={'Neutral'} value={neutral} symbol={''}/></tr>
      <tr><Statistic text={'Bad'} value={bad} symbol={''}/></tr>
      <tr><Statistic text={'Average'} value={average} symbol={''}/></tr>
      <tr><Statistic text={'Postive answers'} value={positive} symbol={'%'}/></tr>
    </tbody>
  </table>

  </>
  )
}


class App extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0,
      average: 0,
      positive: 0
    }
  }

  clickGood = () => {
    this.setState( {good: this.state.good + 1} )
  }

  clickNeutral = () => {
    this.setState( {neutral: this.state.neutral + 1} )
  }

  clickBad = () => {
    this.setState( {bad: this.state.bad + 1} )
  }

  calcAverage = () => {
      const num = (this.state.good-this.state.bad)/(this.state.good+this.state.neutral+this.state.bad)
      return (Math.round(num*100)/100).toFixed(2)
    }

  calcPositive = () => {
      const num =  ((this.state.good)/(this.state.good+this.state.neutral+this.state.bad)*100)
      return (Math.round(num*100)/100).toFixed(2)
    }

  render(){
  return (
    <div>
      <h1>Give feedback</h1>

      <Button handleClick={this.clickGood} text="Good" />
      <Button handleClick={this.clickNeutral} text="Neutral" />
      <Button handleClick={this.clickBad} text="Bad" />
      <Statistics good={this.state.good} neutral={this.state.neutral} bad={this.state.bad} average={this.calcAverage()} positive={this.calcPositive()}  />

    </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
