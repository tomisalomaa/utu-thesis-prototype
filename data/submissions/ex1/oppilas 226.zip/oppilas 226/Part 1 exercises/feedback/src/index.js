import React from 'react';
import ReactDOM from 'react-dom';

const FeedbackTypes = {
  good: 1,
  neutral: 0,
  poor: -1
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      poor: 0
    }
  }
  getTotalFeedback() {
    return this.state.good + this.state.neutral + this.state.poor
  } 
  incrementFeedback(feedbackType) {
    let addGood = 0
    let addNeutral = 0
    let addBad = 0
    switch (feedbackType) {
      case FeedbackTypes.good:
        addGood = 1
        break
      case FeedbackTypes.neutral:
        addNeutral = 1
        break
      case FeedbackTypes.poor:
        addBad = 1
        break
      default:
        console.log('Unsupported action. Please use FeedbackTypes object\'s values when incrementing feedback.')
    }
    this.setState(
      {
        good: this.state.good + addGood,
        neutral: this.state.neutral + addNeutral,
        poor: this.state.poor + addBad
      }
    )
  }
  render() {
    const feedbackHeaderText = 'anna palautetta'
    const statisticsHeaderText = 'statistiikka'
    const averageText = 'keskiarvo'
    const positivesText = 'positiivisia'
    const noFeedbackText = 'ei yhtään palautetta annettu'
    const buttons = [
      {
        text: 'hyvä',
        callBack: () => this.incrementFeedback(FeedbackTypes.good)
      },
      {
        text: 'neutraali',
        callBack: () => this.incrementFeedback(FeedbackTypes.neutral)
      },
      {
        text: 'huono',
        callBack: () => this.incrementFeedback(FeedbackTypes.poor)
      }
    ]
    const Button = props => <button onClick={props.button.callBack}>{props.button.text}</button>
    const renderStatistics = () => {
      if (this.getTotalFeedback() === 0) {
        return <p>{noFeedbackText}</p>
      } else {
        return <Statistics buttons={buttons}/>
      }
    }
    const Statistics = props => {
      return (
        <div>
          <h1>{statisticsHeaderText}</h1>
          <table>
            <tbody>
              <Statistic text={props.buttons[0].text} value={this.state.good} unit={''} />
              <Statistic text={props.buttons[1].text} value={this.state.neutral} unit={''} />
              <Statistic text={props.buttons[2].text} value={this.state.poor} unit={''} />
              <Statistic text={averageText} value={(
                (FeedbackTypes.good    * this.state.good
              + FeedbackTypes.neutral * this.state.neutral
              + FeedbackTypes.poor    * this.state.poor) / this.getTotalFeedback()).toFixed(1)} unit={''} />
              <Statistic text={positivesText} value={
                ((this.state.good / this.getTotalFeedback()) * 100).toFixed(1)
              } unit={'%'} />
            </tbody>
          </table>
        </div>
      )
    }
    const Statistic = props => <tr><td>{props.text}</td><td>{props.value} {props.unit}</td></tr>
    return (
      <div>
        <h1>{feedbackHeaderText}</h1>
        <Button button={buttons[0]} />
        <Button button={buttons[1]} />
        <Button button={buttons[2]} />
        <>{renderStatistics()}</>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);

