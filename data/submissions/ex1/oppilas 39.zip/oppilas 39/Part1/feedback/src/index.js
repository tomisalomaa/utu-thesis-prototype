import React from 'react'
import ReactDOM from 'react-dom'

var good = 0;
var neutral = 0;
var poor = 0;
var counter = 0;
var average = 0;
var positive = 0;
var display = 0;

const AddOneG = () => {
  good++;
  counter++;
  display = 1;
  Average()
  Positives()
  Renderoi()
}
const AddOneN = () => {
  neutral++;
  display = 1;
  Average()
  Positives()
  Renderoi()
}
const AddOneP = () => {
  poor++;
  counter--;
  display = 1;
  Average()
  Positives()
  Renderoi()
}

const Renderoi = () => {
  ReactDOM.render(
    <App />,
    document.getElementById('root')
  )
}

const Average = () => {
  var total = good+neutral+poor;
  average = counter / total;
  return (
    <p>Average {average}</p>
  )
}

const Positives = () => {
  var total = good+neutral+poor;
  positive = (good / total) * 100;
}

const ButtonGood = () => {
  return (
    <button onClick={AddOneG}>Good</button>
  )
}
const ButtonNeutral = () => {
  return (
    <button onClick={AddOneN}>Neutral</button>
  )
}
const ButtonPoor = () => {
  return (
    <button onClick={AddOneP}>Poor</button>
  )
}

const Statistics = () => {
  if (display == 0) {
    return (
      <p>Give feedback to show statistics </p>
    )
  } 
  if (display == 1) {
    return (
      <Table />
    )
  }
}


function Table() {
  return (
    <div>
      <table>
        <thead></thead>
        <tbody>
          <tr>
            <th>Good {good}</th>
          </tr>
          <tr>
            <th>Neutral {neutral}</th>
          </tr>
          <tr>
            <th>Poor {poor}</th>
          </tr>
          <tr>
            <th><Average /></th>
          </tr>
          <tr>
            <th>Positives {positive}%</th>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

const App = () => {

  return (
    <div>
      <h1>Give Feedback</h1>
      <ButtonGood />
      <ButtonNeutral />
      <ButtonPoor />
      <p> </p>
      <h1>Statistics</h1>
      <Statistics />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)