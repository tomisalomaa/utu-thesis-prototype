import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      bad: 0,
      neutral: 0
    }
  }

  render() {
    return(
    <div>
    <Header></Header>
    <button onClick={() => this.setState({good: this.state.good +1})}>hyvä</button>
    <button onClick={() => this.setState({neutral: this.state.neutral +1})}>neutraali</button>
    <button onClick={() => this.setState({bad: this.state.bad +1})}>huono</button>
    
    <h1>statistiikka</h1>
    <Statistics ratings={this.state}></Statistics>

  </div>
    )
  }
}


const Header = () => {
  return(
    <div>
        <h1>anna palautetta</h1>
  </div>
  )
  
}


const Statistics = (props) => {

  if (props.ratings.good == 0 && props.ratings.neutral == 0 && props.ratings.bad == 0){
    return (
      [
        <p>ei ääniä</p>
      ]
    )
  }

  return(

    <table>
      <tr>
        <td>hyvä</td>
        <td>{props.ratings.good}</td>
      </tr>
      <tr>
        <td>neutraali</td>
        <td>{props.ratings.neutral}</td>
      </tr>
      <tr>
        <td>huono</td>
        <td>{props.ratings.bad}</td>
      </tr>
      <tr>
        <td>keskiarvo</td>
        <td>{(1*props.ratings.good + (-1)*props.ratings.bad)/2}</td>
      </tr>
      <tr>
        <td>positiivisia (%)</td>
       <td>{props.ratings.good/(props.ratings.bad+props.ratings.good+props.ratings.neutral)*100}%</td> 
      </tr>
    </table> 

  )}




ReactDOM.render(
  <App />,
  document.getElementById('root')
)
