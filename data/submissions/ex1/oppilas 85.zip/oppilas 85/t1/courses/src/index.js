import React from 'react'
import ReactDOM from 'react-dom'

const Header = (c) => {
    return (<h1>{c.course.name}</h1>)
}

const Contents = (p) => {
    const l = []
    for (let i = 0; i < p.parts.length; i++) {
	l.push(<p key={i}> {p.parts[i].name} {p.parts[i].exercises}</p>);
    }
    return l
}

const Total = (p) => {
    var i = 0
    for (const v of p.parts) {
	i += v.exercises
    }
    return (<p>Total {i} exercises</p>)
}

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
	<Header course={course} />
	<Contents parts={course.parts} />
	<Total parts={course.parts} />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
