import React from 'react'
import ReactDOM from 'react-dom'

const Button = (p) => {
    return (<button onClick={p.func}>{p.text}</button>)
}

const Statistics = (s) => {
    var sum = s.state.neu + s.state.bad + s.state.goo
    var i = s.state.goo / sum * 100
    var j = (s.state.goo - s.state.bad) / sum

    if (isNaN(i)) {
	return (
	    <p>ei yhtään palautetta annettu</p>
	)
    } else {
	return (
	    <table>
		<tbody>
		    <Statistic label="hyvä" value={s.state.goo} />
		    <Statistic label="neutraali" value={s.state.neu} />
		    <Statistic label="huono" value={s.state.bad} />
		    <Statistic label="keskiarvo" value={j.toFixed(1)} />
		    <Statistic label="positiivisia" value={i.toFixed(1)+"%"} />
		</tbody>
	    </table>
	)
    }
}

const Statistic = (s) => {
    return (
	<tr>
	    <td>{s.label}</td>
	    <td>{s.value}</td>
	</tr>
    )
}

class App extends React.Component {
    constructor() {
	super()
	this.state = {
	    goo: 0,
	    neu: 0,
	    bad: 0
	}
    }

  render() {
    return (
      <div>
	<h1>anna palautetta</h1>
	<Button func={() => this.setState({ goo: ++this.state.goo })} text="hyvä"/>
	<Button func={() => this.setState({ neu: ++this.state.neu })} text="neutraali"/>
	<Button func={() => this.setState({ bad: ++this.state.bad })} text="huono"/>
	<h1>statistiikka</h1>
	<Statistics state={this.state}/>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
