import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyvä: 0,
      neutraali: 0,
      huono: 0,
      summa: 0,
      keskiarvo: 0,
      positiivisia: 0
    }
  }

  klikHyvä = () => {
    this.setState({
      hyvä: this.state.hyvä + 1,
      summa: this.state.summa + 1
    },
    this.arvot)
  }

  klikNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      summa: this.state.summa + 1
    },
    this.arvot)
  }

  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      summa: this.state.summa + 1
    },
    this.arvot)
  }

  arvot = () => {
    this.setState({
      keskiarvo: ((this.state.hyvä - this.state.huono)/this.state.summa).toFixed(1),
      positiivisia: (this.state.hyvä / this.state.summa * 100).toFixed(1)
    })
  }
  //good 1, neutral 0, poor -1

  render() {
    if (this.state.summa === 0) {
      return (
        <div>
          <h1>anna palautetta</h1>
          <div>
            <Button 
              handleClick={this.klikHyvä}
              text='Hyvä' 
              />
            <Button 
              handleClick={this.klikNeutraali} 
              text='Neutraali'
            />
            <Button 
              handleClick={this.klikHuono} 
              text='Huono'
            />
          </div>
          <h1>statistiikka</h1>
          <p>ei yhtään palautetta annettu</p>
        </div>
      )
    }

    else {
      return (
        <div>
          <h1>anna palautetta</h1>
          <div>
            <Button 
              handleClick={this.klikHyvä}
              text='Hyvä' 
              />
            <Button 
              handleClick={this.klikNeutraali} 
              text='Neutraali'
            />
            <Button 
              handleClick={this.klikHuono} 
              text='Huono'
            />
          </div>
          <Statistics statistic={this.state} />
        </div>
      )
    }
  }
}

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = (props) => (
  <div>
  <h1>statistiikka</h1>
  <table>
    <tbody>
      <tr>
        <td>hyvä</td>
        <td>{props.statistic.hyvä}</td>
      </tr>
      <tr>
        <td>neutraali</td>
        <td>{props.statistic.neutraali}</td>
      </tr>
      <tr>
        <td>huono</td>
        <td>{props.statistic.huono}</td>
      </tr>
      <tr>
        <td>keskiarvo</td>
        <td>{props.statistic.keskiarvo}</td>
      </tr>
      <tr>
        <td>positiivisia</td>
        <td>{props.statistic.positiivisia} %</td>
      </tr>
    </tbody>
  </table>
  </div>
)


ReactDOM.render(
  <App />,
  document.getElementById('root')
)
