import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';



const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = (props) => {
  if (props.yhteensä === 0)
    return (
      <div>
        <p>ei yhtään palautetta annettu</p>
      </div>
    )
  return (
    <table>
      <tbody>
        <Statistic text={"hyvä: "} counter={props.hyvä}/>
        <Statistic text={"neutraali: "} counter={props.neutraali}/>
        <Statistic text={"huono: "} counter={props.huono}/>
        <Statistic text={"keskiarvo: "} counter={(props.hyvä - props.huono)/props.yhteensä}/>
        <Statistic text={"positiivisia: "} counter={(props.hyvä/props.yhteensä)*100} merkki="%"/>
      </tbody>
    </table>
  )
}  

const Statistic = (props) => {
  return (
    <tr>
      <td>{props.text}</td>
      <td>{props.counter} {props.merkki}</td>
    </tr>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyvä: 0,
      neutraali: 0,
      huono: 0,
      yhteensä: 0
    }
  }

  klikHyvä = () => {
    this.setState({
      hyvä: this.state.hyvä + 1,
      yhteensä: this.state.yhteensä + 1
    })
  }

  klikNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      yhteensä: this.state.yhteensä + 1
    })
  }

  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      yhteensä: this.state.yhteensä + 1
    })
  }
  
  render() {
    return (
      <div>
        <h1>anna palautetta</h1>
          <div>
            <Button
              handleClick={this.klikHyvä}
              text="hyvä"
            />
            <Button
              handleClick={this.klikNeutraali}
              text="neutraali"
            />
            <Button
              handleClick={this.klikHuono}
              text="huono"
            />
          </div>
        <h1>statistiikka</h1>
        <Statistics hyvä={this.state.hyvä} neutraali={this.state.neutraali} huono={this.state.huono} yhteensä={this.state.yhteensä}/>
      </div>
    );
  }
}
  

ReactDOM.render(
    <App />,
  document.getElementById('root')
);
