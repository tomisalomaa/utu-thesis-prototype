import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <h1>Kurssin nimi on {props.course}</h1>
    </div>
  )
}

const Contents = (props) => {
  return (
    <div>
      <Part  part={props.parts[0]} />
      <Part  part={props.parts[1]} />
      <Part  part={props.parts[2]} />
    </div>
  )
}

function Total (props) {
  let summa = 0;
  for(const element of props.parts) summa += element.exercises;

  return (
    <div>
      <p>Kurssilla on yhteensä {summa} tehtävää.</p>
    </div>
  )
}

const Part = (props) => {
  return (
    <div>
      <p>Osassa {props.part.name} on {props.part.exercises} tehtävää.</p>
    </div>
  )
}


const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root'))