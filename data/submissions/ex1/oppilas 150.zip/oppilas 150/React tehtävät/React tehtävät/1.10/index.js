import React, { useState } from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  const increaseGood = () => setGood(good+1)
  const increaseNeutral = () => setNeutral(neutral+1)
  const increaseBad = () => setBad(bad+1)
  const text = {
    header: 'give feedback',
    subheader: 'statistics '
  }

  return (
    <div>
      <Header text={text.header}></Header>
      <Button increaseG={increaseGood} increaseN={increaseNeutral} increaseB={increaseBad}></Button>
      <Subheader text={text.subheader} />
      <Statistics good={good} neutral={neutral} bad={bad} />
      {/* <Content text={good, neutral, bad} /> */}
      {/* <Total exercises={text.buttons} /> */}
    </div>
  )
}

const Header = (props) => {
  return (
    <h1>
      {props.text}
    </h1>
  )
}

const Button = (props) => {
  return (
    <div>
    <button onClick={props.increaseG}>good</button>
    <button onClick={props.increaseN}>neutral</button>
    <button onClick={props.increaseB}>bad</button>
    </div>
  )
}

const Subheader = ({text}) => {
  return (
    <h1>
      {text}
    </h1>
  )
}

const Statistics = ({good, neutral, bad}) => {
  console.log({good, neutral, bad})
  if (good === 0 && neutral === 0 && bad === 0) {
    return (
      <p>
        No feedback given
      </p>
    )
  }

  return (
    <>
    <table>
      <StatisticLine text="good " value={good} />
      <StatisticLine text="neutral " value={neutral} />
      <StatisticLine text="bad " value={bad} />
      <StatisticLine text="all " value={good + neutral + bad} />
      <StatisticLine text="average " value={(good - bad)/2} />
      <StatisticLine text="positive " value={(good/(good+neutral+bad))*100} />
    </table>
    </>
  )
}

const StatisticLine = (props) => {
  console.log(props)
  if (props.text === "positive ") {
    return (
      <tbody>
      <tr>
        <td>{props.text}</td>
        <td>{props.value}</td>
        %
      </tr>
      </tbody>
    )
  }
  return (
    <tbody>
    <tr>
        <td>{props.text}</td>
        <td>{props.value}</td>
    </tr>
    </tbody>
  )
}

// const Content = (props) => {
//   console.log(props)
//   return (
//     <div>
//       <Part
//         name='good '
//         {...text.good}
//       ></Part>
//       <Part
//         name='neutral '
//         {...text.neutral}
//       ></Part>
//       <Part
//         name='bad '
//         {...text.bad}
//       ></Part>
//     </div>
//   )
// }

// const Part = (props) => {
//   return (
//     <div>
//       {props.name}
//     </div>
//   )
// }

// const Total = (props) => {
//   console.log(props)
//   return (
//     <div>
//       {props.exercises[0].exercises+props.exercises[1].exercises+props.exercises[2].exercises}
//     </div>
//   )
// }

ReactDOM.render(<App />, document.getElementById('root'))