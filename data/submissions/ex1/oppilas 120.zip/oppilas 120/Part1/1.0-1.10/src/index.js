import React, { useState } from 'react'
import ReactDOM from 'react-dom'


const App = () => {
  // tallenna napit omaan tilaansa: 
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  const [All, setAll] = useState(0)
  const percent = (good/All)*100
  
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  const handleGoodClick = () => {
    setGood(good + 1 )
    setAll(All + 1)
    
  }
  const handleNeutralClick = () => {
    setNeutral(neutral+1 )
    setAll(All +1)
  }
  
  const handleBadClick = () => {
    setBad(bad+1)
    setAll(All +1)
  }

  const Palaute = ({All}) => {
    if (All === 0) {
      return (
        <div>
          <p> Ei yhtään palautetta annettu</p>
        </div>
      )
    } 
    else {
      return(
        <Statistics good={good} neutral={neutral} bad={bad}  All={All.toFixed(1)} percent={percent.toFixed(1)}/>
      )
    }
  }

  return (
    <div>
      <Header course={course}/>
      <Contents course={course}/>
      <Total course={course}/>
      <h1> Anna palautetta</h1> 
      <Button handleClick={handleGoodClick} text="Hyvä" />
      <Button handleClick={handleNeutralClick} text="Neutraali" />
      <Button handleClick={handleBadClick} text="Huono" /> 
      <h1>Statistiikka</h1>
      <Palaute All={All} />
  </div>
  )
}

const Header = ({course}) => {
  return (
    <div> 
      <h2> Course name: {course.name}</h2> 
      <br></br>
      <h3> Parts and exercises</h3>
    </div>
  )
}

const Total =({course}) => {
  return (
    <div>
     <p> Total: {course.parts[0].exercises + course.parts[1].exercises + course.parts[2].exercises   } </p>
    </div>
  )
}

const Contents = ({ course }) => {
  return (
    <div>
      <p>{course.parts[0].name}: {course.parts[0].exercises}</p>
      <p>{course.parts[1].name}: {course.parts[1].exercises}</p>
      <p>{course.parts[2].name}: {course.parts[2].exercises}</p>
    </div>
  )
}

const Button = ({handleClick, text}) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistic =({text,value}) => {
  return(
  <div> {text} {value}  </div>
  )
}

const Statistics =({good,bad,neutral,percent,All}) => {
  let huono = -1
  let hyvä = 1
  return (
    <div>
      <table> 
      <tbody>
        <tr> 
          <td> <Statistic text="Hyvä"/> </td>
          <td> <Statistic value={good}/> </td>
        </tr>
        <tr> 
          <td> <Statistic text="Huono"/> </td>
          <td> <Statistic value={bad}/> </td>
        </tr>
        <tr> 
          <td> <Statistic text="Neutraali"/> </td>
          <td> <Statistic value={neutral}/> </td>
        </tr>
        <tr> 
          <td> <Statistic text="Keskiarvo"/> </td>
          <td> <Statistic value={(good*hyvä + bad*huono)/All}/> </td>
        </tr>
        <tr> 
          <td> <Statistic text="Positiivisia"/> </td>
          <td> <Statistic value={percent + " %"}/> </td>
        </tr>
      </tbody>
      </table>
    </div>
        
    )
  }

ReactDOM.render(
  <App />,
  document.getElementById('root')
)