import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0
    }
    this.onClickGood = this.onClickGood.bind(this);
    this.onClickNeutral = this.onClickNeutral.bind(this);
    this.onClickBad = this.onClickBad.bind(this);
  }

  onClickGood() {
    this.setState((lastState) => ({
      good: lastState.good + 1
    }));
  }

  onClickNeutral() {
    this.setState((lastState) => ({
      neutral: lastState.neutral + 1
    }));
  }

  onClickBad() {
    this.setState((lastState) => ({
      bad: lastState.bad + 1
    }));
  }

  render() {
    const sum = this.state.good + this.state.neutral + this.state.bad;
    const getPositiveRate = () => {
      if(sum !== 0)
        return Math.floor((this.state.good / sum) * 1000) / 10;
      else
        return 0;
    };
    const getAverage = () => {
      if(sum !== 0)
        return Math.floor((this.state.good - this.state.bad) / sum * 10) / 10;
      else
        return 0;
    };

    return (
      <div>
        <h1>Anna palautetta</h1>
        <Button text="Hyvä" handler={this.onClickGood} />
        <Button text="Neutraali" handler={this.onClickNeutral} />
        <Button text="Huono" handler={this.onClickBad} />
        <Statistics
          sum = {sum}
          state={this.state} 
          average={getAverage()} 
          positiveRate={getPositiveRate()}
        />
      </div>
    );
  }
}

function Button({text, handler}) {
  return (
    <button onClick={handler}>
      {text}
    </button>
  );
}

function Statistics({sum, state, average, positiveRate}) {
  if(sum === 0)
    return (
      <div>
        <h1>Statistiikka</h1>
        <p>Ei yhtään palautetta annettu</p>
      </div>
    );
  else
    return (
      <div>
        <h1>Statistiikka</h1>
        <table>
          <tbody>
            <Statistic text="Hyvä" value={state.good}/>
            <Statistic text="Neutraali" value={state.neutral}/>
            <Statistic text="Huono" value={state.bad}/>
            <Statistic text="Keskiarvo" value={average}/>
            <Statistic text="Positiviisia" value={positiveRate + " %"}/>
          </tbody>
        </table>
      </div>
    );
}

function Statistic({text, value}) {
  return (
    <tr>
      <td>{text}</td>
      <td>{value}</td>
    </tr>
  );
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);