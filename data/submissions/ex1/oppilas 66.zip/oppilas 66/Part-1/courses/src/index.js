import React from 'react';
import ReactDOM from 'react-dom';

const Part = props => {
    return (
        <p>{props.name} {props.exercises}</p>
    )
}

const Header = props => {
    return(
        <div>
            <h1>{props.course}</h1>
        </div>
    )
};

const Contents = props => {
    return (
        <div>
            {props.parts.map((part, index) => {
                return <Part key={index} name={part.name} exercises={part.exercises}/>
            })}
        </div>
    )
};

const Total = props => {
    return (
        <div>
            <p>{props.parts.reduce((accum, part) => accum + part.exercises, 0)}</p>
        </div>
    )
};

const App = () => {
    const data = {
        course: 'Superadvanced web and mobile programming',
        parts: [
            {
                name: 'Basics of React',
                exercises: 8
            },
            {
                name: "Using props",
                exercises: 10
            },
            {
                name: "Component states",
                exercises: 12
            }
        ]
    }

    return (
        <div>
            <Header course={data.course}/>
            <Contents parts={data.parts}/>
            <Total parts={data.parts}/>
        </div>
	);
};

ReactDOM.render(<App />, document.getElementById('root'));
