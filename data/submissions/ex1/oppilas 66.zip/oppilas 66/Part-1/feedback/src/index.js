import React from 'react';
import ReactDOM from 'react-dom';

class Button extends React.Component {
    render() {
        return (
            <button name={this.props.name} onClick={this.props.handler}>{this.props.name}</button>
        );
    }
};

class Statistic extends React.Component {
    render() {
        return (
            <tr>
                <td>{this.props.text}</td>
                <td>{this.props.value}</td>
            </tr>
        );
    }
}

class Statistics extends React.Component {
    render() {
        return (
            this.props.state.total === 0 ? <p>Ei palautetta annettu.</p> :
            <table>
                <tbody>
                    <Statistic 
                        value={this.props.state.positive}
                        handler={this.props.handler}
                        text="Hyvä: ">
                    </Statistic>
                    <Statistic 
                        value={this.props.state.neutral}
                        handler={this.props.handler}
                        text="Neutraali: ">
                    </Statistic>
                    <Statistic 
                        value={this.props.state.negative}
                        handler={this.props.handler}
                        text="Huono: ">
                    </Statistic>
                    <Statistic 
                        // value={`${+(Math.round(((this.props.state.positive+this.props.state.negative*(-1))/(this.props.state.total))+"e+2")+"e-2")}`}
                        value={`${+((this.props.state.positive - this.props.state.negative) / this.props.state.total).toFixed(2)}`}
                        handler={this.props.handler}
                        text="Keskiarvo: ">
                    </Statistic>
                    <Statistic 
                        // value={`${+(Math.round(((this.props.state.positive/this.props.state.total) * 100)+"e+2")+"e-2")}%`}
                        value={`${+((this.props.state.positive / this.props.state.total) * 100).toFixed(2)}%`}
                        handler={this.props.handler}
                        text="Positiivisia: ">
                    </Statistic>
                </tbody>
            </table>    
        );
    }
}

class ButtonSection extends React.Component {
    render() {
        return (
            <div>
                <h1>Anna palautetta</h1>
                <div>
                    <Button handler={this.props.handler} name="Hyvä"></Button>
                    <Button handler={this.props.handler} name="Neutraali"></Button>
                    <Button handler={this.props.handler} name="Huono"></Button>
                </div>
            </div>
        );
    }
}

class StatisticSection extends React.Component {
    render() {
        return (
            <div>
                <h2>Tilastot</h2>
                <Statistics state={this.props.state} handler={this.props.handler}></Statistics>
            </div>
        );
    }
}

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            positive: 0,
            neutral: 0,
            negative: 0,
            total: 0
        }
        this.handler = this.handler.bind(this);
    }
    handler = e => {
        switch(e.target.name) {
            case "Hyvä":
                this.setState({positive: this.state.positive + 1});
                break;
            case "Neutraali":
                this.setState({neutral: this.state.neutral + 1});
                break;
            case "Huono":
                this.setState({negative: this.state.negative + 1});
                break;
            default:
                break;
        }
        this.setState({total: this.state.total + 1});
    }
    render() {
        return (
            <div>
                <ButtonSection handler={this.handler}/>
                <StatisticSection state={this.state} hander={this.handler}/>
            </div>
        );
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));