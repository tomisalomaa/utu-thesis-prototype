import React, { useState } from 'react'
import ReactDOM from 'react-dom'


const App = () => {

  const [hyva, setHyva] = useState(0)
  const [neutraali, setNeutraali] = useState(0)
  const [huono, setHuono] = useState(0)

  const handleClick = (props) => {

    if (props==="hyvä") {
      return (
        handleHyva()
      )
    }
    else if (props==="neutraali") {
      return (
        handleNeutraali()
      )
    }
    else {
      return (
        handleHuono()
      )
    }
  }

const handleHyva = () => () => {setHyva(hyva+1)}
const handleNeutraali = () =>  () => {setNeutraali(neutraali+1)}
const handleHuono = () =>  () => {setHuono(huono+1)}

const Button = (props) => {
  return (
    <button onClick={handleClick(props.arvio)}> {props.arvio} </button>
  )
}

const Header = (props) => {
  return (
    <h1>
      {props.teksti}
    </h1>
  )
}

const Stats = () => {
  const kaikki = hyva + huono + neutraali
  const positiivisia = (hyva/kaikki*100).toFixed(2)
  const keskiarvo = ((hyva+(-1*huono))/kaikki).toFixed(2)

  if (kaikki!=0) {
    return (
      <table>
        <tbody>
          <tr>
            <td>hyvä: </td>
            <td>{hyva}</td>
          </tr>
          <tr>
            <td>neutraali: </td>
            <td>{neutraali}</td>
          </tr>
          <tr>
            <td>huono: </td>
            <td>{huono}</td>
          </tr>
          <tr>
            <td>positiivisia: </td>
            <td>{positiivisia}%</td>
          </tr>
          <tr>
            <td>keskiarvo: </td>
            <td>{keskiarvo}</td>
          </tr>
        </tbody>
      </table>
    )
  }
  else {
    return (
      <p>ei yhtään palautetta annettu</p>
    )
  }
}
  return (
    <div>
      <Header teksti="Anna palautetta"/>
      <Button arvio="hyvä"/>
      <Button arvio="neutraali"/>
      <Button arvio="huono"/>
      <Header teksti="Statistiikka"/>
      <Stats/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)

