import React from 'react';
import ReactDOM from 'react-dom';

const Button = (props) =>{
  return(
      <button onClick={props.klikkaus}>
        {props.teksti}
      </button>
  )
}

const Statistics  = (props) =>{
  return(
    <table>
      <tbody>
      <Statistic  name={props.name1} klikkaus={props.klikkaus1}/>
      <Statistic  name={props.name2} klikkaus={props.klikkaus2}/>
      <Statistic  name={props.name3} klikkaus={props.klikkaus3}/>
      <Statistic  name={props.name4} klikkaus={props.klikkaus4}/>
      <Statistic  name={props.name5} klikkaus={props.klikkaus5}/>
      </tbody>
    </table>
  )
}

const Statistic = (props) =>{
  return(
    <tr>
      <td>{props.name}</td>
      <td>{props.klikkaus}</td>
    </tr>
  )
}

class App extends React.Component{
  constructor(){
    super()
    this.state={
      Hyvä:0,
      Neutraali:0,
      Huono:0
    }
  }

  kasvataHyvät = () => {
    this.setState({Hyvä: this.state.Hyvä + 1})
  }

  kasvataNeutraalit = () => {
    this.setState({Neutraali: this.state.Neutraali + 1})
  }

  kasvataHuonot = () => {
    this.setState({Huono: this.state.Huono + 1})
  }

  render(){
    const Näytä = () => {
      if(this.state.Hyvä === 0 && this.state.Neutraali === 0 && this.state.Huono === 0){
        return(
        <div>
          <em>Yhtään palautetta ei ole annettu</em>
        </div>
        )
      }
      return(
        <div>
          <Statistics name1= "Hyvä" klikkaus1={this.state.Hyvä}
          name2= "Neutraali" klikkaus2={this.state.Neutraali}
          name3= "Huono" klikkaus3={this.state.Huono}
          name4= "Keskiarvo" klikkaus4={((this.state.Hyvä-this.state.Huono) / (this.state.Hyvä + this.state.Neutraali + this.state.Huono)).toFixed(2)}
          name5= "Positiiviset" klikkaus5={((this.state.Hyvä / (this.state.Hyvä + this.state.Neutraali + this.state.Huono))*100).toFixed(1)}/>
        </div>
        )
    }
  return(
    <div>
      <h1>Palaute</h1> 
      <Button klikkaus={this.kasvataHyvät} teksti="Hyvä"/> 
      <Button klikkaus={this.kasvataNeutraalit} teksti="Neutraali"/>
      <Button klikkaus={this.kasvataHuonot} teksti="Huono"/>
      <h2>Tilastot</h2>
      <Näytä />
    </div>
   )
  }
}

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);