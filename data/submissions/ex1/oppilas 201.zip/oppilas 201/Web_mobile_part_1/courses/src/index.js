import React from 'react';
import ReactDOM from 'react-dom';

const Part = (parts) => {
  return(
    <div>
      <p>{parts.name} {parts.exercise}</p>
    </div>
  )
}

const Header = (course) => {
  return(
    <div>
      <h1>{course.name}</h1>
    </div>
  )
}

 const Contents = (parts) => {
    return(
    <div>
      <Part name={parts.nimi1} exercise={parts.harjoitus1} />
      <Part name={parts.nimi2} exercise={parts.harjoitus2}  />
      <Part name={parts.nimi3} exercise={parts.harjoitus3} />
      </div>
      )
    }

const Total = (exercise) => {
  return(
  <div>
    <p>Total {exercise.parts0 + exercise.parts1 + exercise.parts2} exercises</p>
  </div>
  )
}

const App = () => {
  const course = {
    name: "Superadvanced web and mobile programming",
    parts: [
    {
      name: "Basics of React",
      exercises: 8
    },
    {
      name: "Using props",
      exercises: 10
    },
    {
      name: "Component states",
      exercises: 12
    }
  ]
}
  
  return (
      <div>
        <Header name={course.name} />
        <Contents nimi1={course.parts[0].name} harjoitus1={course.parts[0].exercises} nimi2={course.parts[1].name} harjoitus2={course.parts[1].exercises} nimi3={course.parts[2].name} harjoitus3={course.parts[2].exercises}/>
        <Total parts0={course.parts[0].exercises} parts1={course.parts[1].exercises} parts2={course.parts[2].exercises} />
       </div>
  )
}
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);