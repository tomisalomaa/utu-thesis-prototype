import React, { useState } from 'react'
import ReactDOM from 'react-dom'

const Button = ({ onClick, texsti }) => <button onClick={onClick}>{texsti}</button>

const Statistic = ({texsti, arvo}) => {
  return(
      <tr>
        <td>{texsti}</td>
        <td>{arvo}</td>
      </tr>
  )
}

const Statistics = ({total, hyva, neutraali, huono}) => {
  if (total === 0) {
    return (
      <div>
        Ei Vastausta
      </div>
    )
  }

  return(
    
      <table>
        <tbody>
          <Statistic texsti="hyva" arvo ={hyva} />
          <Statistic texsti="neutraali" arvo ={neutraali} />
          <Statistic texsti="huono" arvo ={huono} />
          <Statistic texsti="kaikki" arvo ={total} />
          <Statistic texsti="keskiarvo" arvo ={(hyva - huono) / total} />
          <Statistic texsti="positiivinen" arvo ={(hyva /total * 100) + ' %'}  />
        </tbody>
      </table>
    
  )
}

const App = () => {
  
  const [hyva, sethyva] = useState(0)
  const [neutraali, setneutraali] = useState(0)
  const [huono, setBad] = useState(0)
  const [total, setTotal] = useState(0)
  const [keskiarvo, setAverage] = useState(0)
  const [positiivinen, setpositiivinen] = useState(0)

  const handlehyvaClick = () => {setTotal(total + 1); sethyva(hyva +1);}
  const handleneutraaliClick = () => {setTotal(total + 1); setneutraali(neutraali +1);}
  const handleBadClick = () => {setTotal(total + 1); setBad(huono +1);}

  return (
    <div>
      <h1>Anna Palaute</h1>
      <Button onClick={handlehyvaClick} texsti='hyva' />
      <Button onClick={handleneutraaliClick} texsti='neutraali' />
      <Button onClick={handleBadClick} texsti='huono' />
      <h1>statistics</h1>
      <Statistics total={total} hyva={hyva} neutraali={neutraali} huono={huono} />
    </div>
  )
}

ReactDOM.render(<App />, 
  document.getElementById('root')
)