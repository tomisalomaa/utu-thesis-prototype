import React from 'react'
import ReactDOM from 'react-dom'


const Total = (props) => {
  // Lasketaan yhteen osien harjoitusmäärät
  const result = props.parts.reduce((total, currentValue) => total = total + currentValue.exercises,0);
  return (
    <div>
      <p>Total {result} exercises</p>      
    </div>
  )
}

const Header = (props) => {
  return (
    <div>
      <h1>{props.course}</h1>
    </div>
  )
}

const Contents = (props) => {
  return (
    <div>
    {props.parts.map((part, i) => (
      <React.Fragment key={i}>
        <Part part = {part} />
      </React.Fragment>))}
    </div>
  )
}

const Part = (props) => {
  return (
    <div>
      <p>{props.part.name} {props.part.exercises}</p>
    </div>
  )
}

const App = () => {  
  const course = {
  name: 'Superadvanced web and mobile programming',
  parts: [
    {
      name: 'Basics of React',
      exercises: 8
    },
    {
      name: 'Using props',
      exercises: 10
    },
    {
      name: 'Component states',
      exercises: 12
    }
  ]
}

  return (
    <div>
      <Header course={course.name} />
      <Contents parts = {course.parts} />
      <Total parts = {course.parts} />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)