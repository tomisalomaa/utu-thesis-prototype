import React from 'react'
import ReactDOM from 'react-dom'

const H1Text = ({ text }) => (
  <div>
    <h1>{text}</h1>
  </div>
)

const Button = ({ clickAction, text }) => (
  <button onClick={clickAction}>
    {text}
  </button>
)
  
const Statistics = ({ props }) => (
  <table>
    <tbody>
    <Statistic text = {"hyvä"} value = {props.hyva} />
    <Statistic text = {"neutraali"} value = {props.neutraali} />
    <Statistic text = {"huono"} value = {props.huono} />
    <Statistic text = {"keskiarvo"} value = {keskiarvo(props)} />
    <Statistic text = {"positiivisia"} value = {positiivisia(props) + " %"} />
    </tbody>
  </table>
)

const keskiarvo = (props) =>  (Math.round((props.hyva*1+props.huono*-1) /  (props.hyva+props.huono+props.neutraali) * 100) / 100) || 0

const positiivisia = (props) =>  (Math.round(props.hyva / (props.hyva+props.huono+props.neutraali) * 100)) || 0

const Statistic = ({ text, value }) => (
  <tr>
    <td>{text}</td>
    <td>{value}</td>
  </tr>
)

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }
  }

  asetaArvoon = (arvo) => () => this.setState({ [arvo]: this.state[arvo] + 1 })
  
  showStatistics = () => {
    if(this.state.hyva+this.state.huono+this.state.neutraali > 0)
    return <Statistics props = {this.state} />
    return "ei yhtään palautetta annettu"
  }

  render() {
    return (
      <div>
        <H1Text text = "anna palautetta" />
        <div>
          <Button clickAction = {this.asetaArvoon("hyva")} text = {"hyvä"} />
          <Button clickAction = {this.asetaArvoon("neutraali")} text = {"neutraali"} />
          <Button clickAction = {this.asetaArvoon("huono")} text = {"huono"} />
        </div>
        <H1Text text = "statistiikka" />
        {/*{this.showStatistics()}*/}
        {this.state.hyva+this.state.huono+this.state.neutraali > 0 ? <Statistics props = {this.state} /> : "ei yhtään palautetta annettu"}
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)