import React from 'react';
import ReactDOM from 'react-dom';

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)
const Statistics = ({text, value, mark}) => (
  <div>
    <p>{text}     {value}  {mark}</p>
  </div>
)


class App extends React.Component {
  constructor() {
    super()
    this.state = {
      neutraali: 0,
      hyva: 0,
      huono: 0
    }
  }

  lisaaHyva = (arvo) => {
    return () => {
      this.setState({ hyva : arvo })
    }
  }
  lisaaHuono = (arvo) => {
    return () => {
      this.setState({ huono : arvo })
    }
  }
  lisaanNeutraali = (arvo) => {
    return () => {
      this.setState({ neutraali : arvo })
    }
  }
  laskeKeskiarvo = () => {
    if (this.state.hyva + this.state.huono + this.state.neutraali === 0) {
      return (0)
    }
    if (this.state.huono + this.state.neutraali === 0) {
      return (this.state.hyva)
    }
    return (
      (this.state.hyva - this.state.huono ) / (this.state.huono + this.state.hyva + this.state.neutraali)
    )
  }
  laskePositiiviset = () => {
    if (this.state.hyva + this.state.huono + this.state.neutraali === 0) {
      return (0)
    }
    return (
      (this.state.hyva * 100) / (this.state.huono + this.state.hyva + this.state.neutraali)
    )
  }

  render() {
    const onkoarvosteluja = () => {
      if ( this.state.hyva + this.state.huono + this.state.neutraali === 0) {
        return (
          <div>
            <em>No feedback given yet</em>
          </div>
        )
      }
      return (
        <div>
          <Statistics
          text="Good"
          value={this.state.hyva}
          />
          <Statistics
          text="Neutral"
          value={this.state.neutraali}
          />
          <Statistics
          text="Bad"
          value={this.state.huono}
          />
          <Statistics
          text="Average"
          value={this.laskeKeskiarvo()}
          />
          <Statistics
          text="Positive"
          value={this.laskePositiiviset()}
          mark= "%"
          />
        </div>
        )
      }
      return (
        <div>
          <h1>Welcome!</h1>
          <h3>Give us feedback: </h3>
          <Button
          handleClick={this.lisaaHyva(this.state.hyva + 1)}
          text="Good"
          />
          <Button
          handleClick={this.lisaanNeutraali(this.state.neutraali + 1)}
          text="Neutral"
          />
          <Button
          handleClick={this.lisaaHuono(this.state.huono + 1)}
          text="Bad"
          />
          <div>
            <h3>Statistics</h3>
            {onkoarvosteluja()}
          </div>
        </div>

      )
    }
  }

ReactDOM.render(<App />, document.getElementById('root'))


