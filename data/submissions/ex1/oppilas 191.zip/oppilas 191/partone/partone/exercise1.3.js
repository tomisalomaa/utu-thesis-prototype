import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <h1>{props.nimi}</h1>
    </div>
  )
}
const Part = (props) => {
  return (
    <div>
      <p>{props.osa} {props.harjoitus}</p>
    </div>
  )
}

const Contents = (props) => {
  return (
    <div>
      <Part osa={props.osa} harjoitus={props.harjoitus}/>
      <Part osa={props.osa2} harjoitus={props.harjoitus2}/>
      <Part osa={props.osa3} harjoitus={props.harjoitus3}/>
    </div>
  )
}

const Total = (props) => {
  return (
    <div>
      <p>Total {props.harjoitus + props.harjoitus2 + props.harjoitus3} exercises</p>
    </div>
  )
}

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = {
    name: 'Basics of React',
    exercises: 8
  }
  const part2 = {
    name: 'Using props',
    exercises: 10
  }
  const part3 = {
    name: 'Component states',
    exercises: 12
  }

  return (
    <div>
      <Header nimi={course}/>
      <Contents osa={part1.name} harjoitus={part1.exercises} osa2={part2.name} harjoitus2={part2.exercises} osa3={part3.name} harjoitus3={part3.exercises}/>
      <Total harjoitus={part1.exercises} harjoitus2={part2.exercises} harjoitus3={part3.exercises}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)