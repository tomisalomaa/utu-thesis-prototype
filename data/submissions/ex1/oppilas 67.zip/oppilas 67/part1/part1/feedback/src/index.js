import React, { useState } from "react"
import ReactDOM from "react-dom"

const Button = ({ handleClick, text }) => {
  return <button onClick={handleClick}>{text}</button>
}

const Feedback = ({ handleGood, handleNeutral, handlePoor }) => {
  return (
    <div>
      <h1>anna palautetta</h1>
      <Button handleClick={handleGood} text="hyvä" />
      <Button handleClick={handleNeutral} text="neutraali" />
      <Button handleClick={handlePoor} text="huono" />
    </div>
  )
}

const Statistic = ({ name, value }) => {
  return (
    <tr>
      <td>{name}</td>
      <td>{value}</td>
    </tr>
  )
}

const Statistics = ({ good, neutral, poor }) => {
  if (good + neutral + poor === 0) {
    return (
      <div>
        <h1>statistiikka</h1>
        <p>ei yhtään palautetta annettu</p>
      </div>
    )
  }
  const average = (good - poor) / (good + neutral + poor)
  const percentagePositives = (good / (good + neutral + poor)) * 100
  return (
    <div>
      <h1>statistiikka</h1>
      <table>
        <tbody>
          <Statistic name="hyvä" value={good} />
          <Statistic name="neutraali" value={neutral} />
          <Statistic name="huono" value={poor} />
          <Statistic name="keskiarvo" value={average.toFixed(2)} />
          <Statistic
            name="positiivisia"
            value={percentagePositives.toFixed(1).concat(" %")}
          />
        </tbody>
      </table>
    </div>
  )
}

const App = () => {
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [poor, setPoor] = useState(0)

  const handleGood = () => {
    setGood(good + 1)
  }

  const handleNeutral = () => {
    setNeutral(neutral + 1)
  }

  const handlePoor = () => {
    setPoor(poor + 1)
  }

  return (
    <div>
      <Feedback
        handleGood={handleGood}
        handleNeutral={handleNeutral}
        handlePoor={handlePoor}
      />
      <Statistics good={good} neutral={neutral} poor={poor} />
    </div>
  )
}

ReactDOM.render(<App />, document.getElementById("root"))
