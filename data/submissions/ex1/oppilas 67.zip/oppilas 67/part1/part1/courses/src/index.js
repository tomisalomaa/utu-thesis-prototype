import React from "react"
import ReactDOM from "react-dom"

const Header = ({ name }) => {
  return (
    <div>
      <h1>{name}</h1>
    </div>
  )
}

const Part = ({ part, exercises }) => {
  return (
    <div>
      <p>
        {part} {exercises}
      </p>
    </div>
  )
}

const Contents = ({ parts }) => {
  return (
    <div>
      <Part part={parts[0].name} exercises={parts[0].exercises} />
      <Part part={parts[1].name} exercises={parts[1].exercises} />
      <Part part={parts[2].name} exercises={parts[2].exercises} />
    </div>
  )
}

const Total = ({ parts }) => {
  return (
    <div>
      <p>
        Total {parts[0].exercises + parts[1].exercises + parts[2].exercises}{" "}
        exercises
      </p>
    </div>
  )
}

const App = () => {
  const course = {
    name: "Superadvanced web and mobile programming",
    parts: [
      {
        name: "Basics of React",
        exercises: 8,
      },
      {
        name: "Using props",
        exercises: 10,
      },
      {
        name: "Component states",
        exercises: 12,
      },
    ],
  }

  return (
    <div>
      <Header name={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
  )
}

ReactDOM.render(<App />, document.getElementById("root"))
