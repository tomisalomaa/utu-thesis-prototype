import React from 'react'
import ReactDOM from 'react-dom'

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = ({ hyva, huono, neutraali, onPalautetta })  => (
  <div>
      <h1>Statsitiikka</h1>
      {!onPalautetta &&
        <p>ei yhtään palautetta annettu</p>
      }
          {onPalautetta &&
          <Statistic 
          hyva={hyva}
          neutraali={neutraali}
          huono={huono}
          />}
        </div>
)

const Statistic = (props) => (
    <div>
      <table>
        <tbody>
      <tr>
        <td>hyvä</td>
        <td>{props.hyva}</td>
      </tr>
      <tr>
        <td>neutraali</td>
        <td>{props.neutraali}</td>
      </tr>
      <tr>
        <td>huono</td>
        <td>{props.huono}</td>
      </tr>
      <tr>
        <td>keskiarvo</td>
        <td>{((props.hyva-props.huono)/(props.hyva+props.neutraali+props.huono)).toFixed(1)}</td>
      </tr>
      <tr>
        <td>positiivisia</td>
        <td>{(100.0*props.hyva/(props.neutraali+props.huono+props.hyva)).toFixed(1)} %</td>
      </tr>
      </tbody>
      </table>
    </div>
)

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      huono: 0,
      neutraali: 0,
      onPalautetta: false
    }
  }

  klikHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1,
      onPalautetta: true
    })
  }

  klikNeut = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      onPalautetta: true
    })
  }

  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      onPalautetta: true
    })
  }

  render() {
    return (
      <div>
        <div>
          <h1>anna palautetta</h1>
        </div>
        <Button handleClick={this.klikHyva}
          text="hyvä"
        />
        <Button handleClick={this.klikNeut}
          text="neutraali"
        />
        <Button handleClick={this.klikHuono}
          text="huono"
        />

        <Statistics 
          hyva={this.state.hyva}
          neutraali={this.state.neutraali}
          huono={this.state.huono}
          onPalautetta={this.state.onPalautetta}
        />
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)