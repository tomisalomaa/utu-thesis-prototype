import React from 'react'
import {useState} from "react";
import ReactDOM from 'react-dom'

const App = () => {
        const [hyvä, hyvääpalautetta] = useState(0)
      const [neutraali, neutraaliapalautetta] = useState(0)
      const [huono, huonoapalautetta] = useState(0)
      
      return (
      
          <div>
        <Header name={course.name} />
        <Contents parts={course.parts} />
        <Total parts={course.parts} />
      
              <h1>Anna palautetta!</h1>
              <br />
              <button onClick = {() => hyvääpalautetta(hyvä+1)}>Hyvä</button>
              <button onClick = {() => neutraaliapalautetta(neutraali+1)}>Neutraali</button>
              <button onClick = {() => huonoapalautetta(huono+1)}>Huono</button>
              <br />
              <br />
              <h1>statistiikka</h1>
              <br />
              Hyvä: {hyvä}
        <br />
              Neutraali: {neutraali}
        <br />
              Huono: {huono}
        
          </div>
      
      )
  }