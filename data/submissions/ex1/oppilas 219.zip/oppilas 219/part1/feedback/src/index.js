import React from 'react';
import ReactDOM from 'react-dom';

const Header = ({ text }) => (
  <div>
    <h1>{text}</h1>
  </div>
)

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistic = ({ label, value }) => (
  <tr>
    <td>{label}</td>
    <td>{value}</td>
  </tr>
)

const Statistics = ({ values, total }) => {
  if (total === 0) {
    return (
      <p>ei yhtään palautetta annettu</p>
    )
  }
  const [g, n, b, avg, pos] = values
  return (
    <table>
      <tbody>
        <Statistic label='hyvä' value={g} />
        <Statistic label='neutraali' value={n} />
        <Statistic label='huono' value={b} />
        <Statistic label='keskiarvo' value={avg.toFixed(1)} />
        <Statistic label='positiivisia' value={pos.toFixed(1) + ' %'} />
      </tbody>
    </table>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      g: 0,
      n: 0,
      b: 0
    }
  }

  feedback = (value) => () => {
    this.setState({ [value]: this.state[value] + 1 })
  }

  render() {
    const {g, n, b} = this.state
    const total = g + n + b
    const avg = total === 0 ? 0 : ((g - b) / total)
    const pos = total === 0 ? 0 : (g / total * 100)

    return (
      <div>
        <div>
          <Header text='anna palautetta' />
          <Button handleClick={this.feedback('g')} text='hyvä' />
          <Button handleClick={this.feedback('n')} text='neutraali' />
          <Button handleClick={this.feedback('b')} text='huono' />
        </div>
        <div>
          <Header text='statistiikka' />
          <Statistics values={[g, n, b, avg, pos]} total={total} />
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />, document.getElementById('root')
)
