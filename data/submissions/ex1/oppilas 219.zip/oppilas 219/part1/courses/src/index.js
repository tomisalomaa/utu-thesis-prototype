import React from 'react';
import ReactDOM from 'react-dom';

const Header = (props) => {
  return (
    <div>
      <h1>{props.course}</h1>
    </div>
  )
}

const Part = (props) => {
  const p = props.part
  return (
    <div>
      <p>{p.name} {p.exercises}</p>
    </div>
  )
}

const Contents = (props) => {
  const p = props.parts
  return (
    <div>
      <Part part={p[0]} />
      <Part part={p[1]} />
      <Part part={p[2]} />
    </div>
  )
}

const Total = (props) => {
  const p = props.parts
  const e = 'exercises'
  return (
    <div>
      <p>Total {p[0][e] + p[1][e] + p[2][e]} exercises</p>
    </div>
  )
}

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
  )
}

ReactDOM.render(
  <App />, document.getElementById('root')
)
