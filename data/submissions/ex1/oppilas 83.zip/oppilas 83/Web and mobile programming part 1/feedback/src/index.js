import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neut: 0,
      huono: 0,
      sum: 0,
      pos: 0,
      ka: []
    }
  }

  klikHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1,
      ka: this.state.ka.concat(1),
      sum: this.state.sum + 1,
      pos: this.state.pos + 1
    })
  }

  klikNeut = () => {
    this.setState({
      neut: this.state.neut + 1,
      ka: this.state.ka.concat(0)
    })
  }

  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      ka: this.state.ka.concat(-1),
      sum: this.state.sum - 1
    })
  }

  render() {
    if(this.state.ka.length==0){
      return (
        <div>
          <h1>anna palautetta</h1>
          <button onClick={this.klikHyva}>hyvä</button>
          <button onClick={this.klikNeut}>neutraali</button>
          <button onClick={this.klikHuono}>huono</button>
          <h1>statistiikka</h1>
          <p>ei yhtään palautetta annettu</p>
        </div>
      )
    }
    else {
      return (
        <div>
          <h1>anna palautetta</h1>
          <button onClick={this.klikHyva}>hyvä</button>
          <button onClick={this.klikNeut}>neutraali</button>
          <button onClick={this.klikHuono}>huono</button>
          <h1>statistiikka</h1>
          <Statistics hyva={this.state.hyva} neut={this.state.neut} huono={this.state.huono} sum={this.state.sum} ka={this.state.ka} pos={this.state.pos}/>
        </div>
      )
    }

  }
}

const Statistics  = (props) => {
  return (
    <table>
      <tbody>
        <tr>
          <td>hyvä</td>
          <td> {props.hyva}</td>
        </tr>
        <tr>
          <td>neutraali</td>
          <td> {props.neut}</td>
        </tr>
        <tr>
          <td>huono</td>
          <td> {props.huono}</td>
        </tr>
        <tr>
          <td>keskiarvo</td>
          <td> <Statistic sum={props.sum} ka={props.ka}/></td>
        </tr>
        <tr>
          <td>positiivisia</td>
          <td>{(props.pos / props.ka.length*100).toFixed(1)} %</td>
        </tr>
      </tbody>
    </table>

    

  )
}

const Statistic  = (props) => {
  return (
    <table>
      <tbody>
        <tr>
          <td>{(props.sum / props.ka.length).toFixed(1)}</td>
        </tr>
      </tbody>
    </table>

  )
}

ReactDOM.render(<App />, document.getElementById('root'))