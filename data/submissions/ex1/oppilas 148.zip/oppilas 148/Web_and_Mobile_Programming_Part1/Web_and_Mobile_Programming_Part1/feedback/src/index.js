import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyvä: 0,
      neutraali: 0,
      huono: 0,
      keskiarvo: 0,
      positiivisia: 0,
      yht: 0
    }
  }

  klikHyvä = () => this.setState({
    yht: this.state.yht + 1,
    hyvä: this.state.hyvä + 1
  },
    this.arvot)

  klikNeutraali = () => this.setState({
    yht: this.state.yht + 1,
    neutraali: this.state.neutraali + 1
  },
    this.arvot)

  klikHuono = () => this.setState({
    yht: this.state.yht + 1,
    huono: this.state.huono + 1
  },
    this.arvot)

  arvot = () => this.setState({
    keskiarvo: ((this.state.hyvä - this.state.huono) / this.state.yht).toFixed(1),
    positiivisia: (this.state.hyvä / this.state.yht * 100).toFixed(1)
  })

  render() {
    if (this.state.yht === 0) {
      return (
        <div>
          <h1>anna palautetta</h1>
          <div>
            <Button
              handleClick={this.klikHyvä}
              text="hyvä"
            />
            <Button
              handleClick={this.klikNeutraali}
              text="neutraali"
            />
            <Button
              handleClick={this.klikHuono}
              text="huono"
            />
          </div>
          <h1>statistiikka</h1>
          <p>ei yhtään palautetta annettu</p>
        </div>
      )
    }
    else {
      return (
        <div>
          <h1>anna palautetta</h1>
          <div>
            <Button
              handleClick={this.klikHyvä}
              text="hyvä"
            />
            <Button
              handleClick={this.klikNeutraali}
              text="neutraali"
            />
            <Button
              handleClick={this.klikHuono}
              text="huono"
            />
          </div>
          <Statistics statistics={this.state} />
        </div>
      )
    }
  }
}
const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = (props) => (
  <div>
    <h1>statistiikka</h1>
    <table>
      <tbody>
        <tr>
          <td>hyvä</td>
          <td>{props.statistics.hyvä}</td>
        </tr>
        <tr>
          <td>neutraali</td>
          <td>{props.statistics.neutraali}</td>
        </tr>
        <tr>
          <td>huono</td>
          <td>{props.statistics.huono}</td>
        </tr>
        <tr>
          <td>keskiarvo</td>
          <td>{props.statistics.keskiarvo}</td>
        </tr>
        <tr>
          <td>positiivisia</td>
          <td>{props.statistics.positiivisia} %</td>
        </tr>
      </tbody>
    </table>
  </div>
)

ReactDOM.render(<App />, document.getElementById('root'))
