import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <h1>Thy course name is {props.course}</h1>
    </div>
  )
}

const Content = (props) => {
  return (
    <div>
      <PART part={props.parts[0].name} exercises={props.parts[0].exercises}/>
      <PART part={props.parts[1].name} exercises={props.parts[1].exercises}/>
      <PART part={props.parts[2].name} exercises={props.parts[2].exercises}/>
    </div>
  )
}

const PART = (props) => {
  return (
    <div>
      <p>{props.part} has number of {props.exercises} exercises</p>
    </div>
  )
}

const Total = (props) => {
  return (
    <div>
      <p>Total of {props.parts[0].exercises + props.parts[1].exercises + props.parts[2].exercises} exercises</p>
    </div>
  )
}


const App = () => {
  const course = {
    course: 'Superadvanced web and mobile programming',
    parts:[
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course.course}/>
      <Content parts={course.parts}/>
      <Total parts={course.parts}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)