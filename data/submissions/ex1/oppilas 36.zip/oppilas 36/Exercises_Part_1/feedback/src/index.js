import React, { useState } from "react";
import ReactDOM from "react-dom";
import "./index.css";

const Header = () => {
  return(
  <div>
    <h1>Fancy some feedback?</h1>
    <p>Please press some buttons</p>
  </div>
)
}
const Button = ({text, handleClick}) =>(
  <button onClick={handleClick}>{text}</button>
)

const Numbrs = ({text, value}) =>(
  <div>
    {text} {value}
  </div>
)

const Statistic = ({Good, Neutral, Bad}) => {
  var count = Good + Neutral + Bad 
  var average = ((Good)+(Bad*-1))/count
  var tpositive = (Good/count)*100
  return(
    <div>
      <p>Average {average}</p>
      <p>Positive {tpositive}%</p>
    </div>
  )
}

const Statistics = ({Good, Neutral, Bad}) =>{
  
  if(Good== 0 && Neutral == 0 && Bad == 0){
    return(
      <p>No Feedback x)</p>
    )
  }
    return (
      <div>
        <table>
          <tbody>
            <tr><td><Numbrs text="Good" value={Good}/></td></tr>
            <tr><td><Numbrs text="Neutral" value={Neutral}/></td></tr>
            <tr><td><Numbrs text="Bad" value={Bad}/></td></tr>
            <tr><td><Statistic Good={Good} Neutral={Neutral} Bad={Bad}/></td></tr>
         </tbody>
        </table>
      </div>      
    ) 
}

const App = () => {
  
  const[Good, setGood] = useState(0);
  const[Neutral, setNeutral] = useState(0);
  const[Bad, setBad] = useState(0);


  return(
    <div>
      <Header/>
      <Button text="Good" handleClick={() => setGood(Good + 1)}/>
      <Button text="Neutral" handleClick={() => setNeutral(Neutral + 1)}/>
      <Button text="Bad" handleClick={() => setBad(Bad + 1)}/>
      <Statistics Good={Good} Neutral={Neutral} Bad={Bad}/>    
    </div>
  )
}

ReactDOM.render(<App />, document.getElementById("root"));