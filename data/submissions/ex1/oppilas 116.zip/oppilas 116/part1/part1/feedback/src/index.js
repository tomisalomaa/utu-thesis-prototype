import React from 'react'
import ReactDOM from 'react-dom'

const Button = ({handler, text}) => (
	<button onClick={handler}>
		{text}	
	</button>
)

const Statistic = ({text, data, sign}) => (
	<tr>
		<td>{text}</td>	
		<td>{data} {sign}</td>
	</tr>
)

const Statistics = ({hyvä, neut, huono, keskiarvo, pos}) => {
	if(hyvä===0 && neut===0 && huono===0) {
		return (
			<div>
				<p>ei yhtään palautetta annettu</p>
			</div>
		)
	}
	return (
		<div>
			<table>
				<tbody>
					<Statistic text="hyvä" data={hyvä} />
					<Statistic text="neutraali" data={neut} />
					<Statistic text="huono" data={huono} />
					<Statistic text="keskiarvo" data={keskiarvo} />
					<Statistic text="positiiviset" data={pos} sign="%"/>
				</tbody>
			</table>
		</div>
	)
}

class App extends React.Component {
	constructor() {
		super()
		
		this.state = {
			hyvä: 0,
			neutraali: 0,
			huono: 0
		}
	}

	laskePositiiviset() {
		const x = this.state.hyvä/(this.state.hyvä+this.state.neutraali+this.state.huono)
		return Math.round(x*1000)/10
	}

	laskeKeskiarvo() {
		const x = this.state.hyvä - this.state.huono
		const y = this.state.hyvä + this.state.neutraali + this.state.huono
		return Math.round((x/y)*10)/10
	}

	klikkaaHyvää = () => {
		this.setState({hyvä: this.state.hyvä + 1})
	}
	
	klikkaaNeutraalia = () => {
		this.setState({neutraali: this.state.neutraali + 1})
	}

	klikkaaHuonoa = () => {
		this.setState({huono: this.state.huono + 1})
	}

	print = () => { console.log('nappia painettu') } 

	render() {
		console.log('render')
  	return (
  	  <div>
  	    <h1>anna palautetta</h1>

				<Button handler={this.klikkaaHyvää} text="hyvä" />
				<Button handler={this.klikkaaNeutraalia} text="neutraali" />
				<Button handler={this.klikkaaHuonoa} text="huono" />

				<h1>statistiikka</h1>
				<Statistics
					hyvä={this.state.hyvä} neut={this.state.neutraali} huono={this.state.huono}
					keskiarvo={this.laskeKeskiarvo()} pos={this.laskePositiiviset()}
				/>
  	  </div>
  	)
	}
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
