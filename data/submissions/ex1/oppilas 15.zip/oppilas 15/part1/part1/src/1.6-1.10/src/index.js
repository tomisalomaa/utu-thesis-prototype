import React from 'react';
import ReactDOM from 'react-dom';

const Buttons = (props) => {
  return (
   <button onClick= {props.funktio}>
    {props.teksti}
  </button>    
  )}

const Statistic = (props) => {
  return(
    <tr>
      <td>{props.teksti} </td>
      <td>{props.arvo} </td>
      <td> {props.prosentti}</td>
    </tr>
  )
}

const Statistics = (props) => {
  return(
    <div>
      <h1> {props.otsikko}</h1>
      <table>
        <tbody>
          <Statistic teksti={props.teksti1} arvo={props.arvo1} prosentti={props.prosentti1} />
          <Statistic teksti={props.teksti2} arvo={props.arvo2} prosentti={props.prosentti2}/>
          <Statistic teksti={props.teksti3} arvo={props.arvo3} prosentti={props.prosentti3}/>
          <Statistic teksti={props.teksti4} arvo={props.arvo4} prosentti={props.prosentti4}/>
          <Statistic teksti={props.teksti5} arvo={props.arvo5} prosentti={props.prosentti5}/>
        </tbody>
      </table>
    </div>
  )
}

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyvä: 0,
      neutraali: 0,
      huono: 0,
      määrä: 0,
      keskiarvo: 0.0,
      prosentti: 0
    }
  }

  asetaHyvä = () => {
    this.setState({ hyvä: this.state.hyvä + 1, määrä: this.state.määrä +1},
      () => this.laskeKeskiarvo())
  }

  asetaNeutraali = () => {
    this.setState({ neutraali: this.state.neutraali + 1, määrä: this.state.määrä +1}, 
      () => this.laskeKeskiarvo())

  }

  asetaHuono = () => {
    this.setState({ huono: this.state.huono + 1, määrä: this.state.määrä +1}, 
      () => this.laskeKeskiarvo())
  }

  laskeKeskiarvo = () => {
    this.setState({ keskiarvo: (1 * this.state.hyvä +this.state.neutraali *0
   + this.state.huono* -1) / this.state.määrä,
    prosentti: this.state.hyvä / this.state.määrä * 100 })
    }


  render() {
    const konditionaalisuus = () => {
      if (this.state.määrä === 0){
        return(
          <div>
            <h1>statistiikka</h1>
            <p>ei yhtään palautetta annettu</p>
          </div>
        )
      }
      return(
        <Statistics otsikko="statistiikka"
        teksti1="hyvä" arvo1={this.state.hyvä} prosentti1=""
        teksti2="neutraali" arvo2={this.state.neutraali} prosentti2=""
        teksti3="huono" arvo3={this.state.huono} prosentti3=""
        teksti4="keskiarvo" arvo4={this.state.keskiarvo} prosentti4=""
        teksti5="positiivisia" arvo5={this.state.prosentti} prosentti5="%"
        />
        )
      }
    return (
      <div>
        <h1>anna palautetta</h1>
        <Buttons teksti="hyvä" funktio={this.asetaHyvä}/>
        <Buttons teksti="neutraali" funktio={this.asetaNeutraali}/>
        <Buttons teksti="huono" funktio={this.asetaHuono}/>
        {konditionaalisuus()}
      </div>
    )
  }
}


ReactDOM.render(
    <App />,
  document.getElementById('root')
);
