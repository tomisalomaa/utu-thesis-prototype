import React from 'react';
import ReactDOM from 'react-dom';

const Button = ({ handleClick, text }) => <button onClick={handleClick}>{text}</button>

const Statistic = ({ text, value }) => <tr><td>{text}</td><td>{value}</td></tr>

const Statistics = ({ statistics }) => {
  return(
    <table>
      <tbody>
        <Statistic text={statistics.texts[0]} value={statistics.values[0]} />
        <Statistic text={statistics.texts[1]} value={statistics.values[1]} />
        <Statistic text={statistics.texts[2]} value={statistics.values[2]} />
        <Statistic text={statistics.texts[3]} value={statistics.values[3]} />
        <Statistic text={statistics.texts[4]} value={statistics.values[4]} />
      </tbody>
    </table>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }
  }

  render() {
    const keskiarvo = () => (this.state.hyva + this.state.huono * -1) / (this.state.hyva + this.state.neutraali + this.state.huono)
    const positiiviset = () => Number(this.state.hyva / (this.state.hyva + this.state.huono + this.state.neutraali)).toLocaleString(undefined, {style: 'percent'})

    const statistics = {
      texts: ["hyvä", "neutraali", "huono", "keskiarvo", "positiivisia"],
      values: [this.state.hyva, this.state.neutraali, this.state.huono, keskiarvo(), positiiviset()]
    }

    const statisticsElement = () => {
      if (this.state.hyva === 0 && this.state.huono === 0 && this.state.neutraali === 0) {
        return <p>ei yhtään palautetta annettu</p>
      }
      return (
        <Statistics statistics={statistics} />
      )
    }

    return (
      <div>
        <h1>anna palautetta</h1>
        <Button
          handleClick={() => this.setState({ hyva: this.state.hyva + 1 })} 
          text="hyvä"
        />
        <Button 
          handleClick={() => this.setState({ neutraali: this.state.neutraali + 1 })} 
          text="neutraali" 
        />
        <Button 
          handleClick={() => this.setState({ huono: this.state.huono + 1 })} 
          text="huono"
        />
        <h1>statistiikka</h1>
        <div>{statisticsElement()}</div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);