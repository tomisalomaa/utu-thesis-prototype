import React from 'react'
import ReactDOM from 'react-dom'

const Statistics = (props) => {
  return (
    <div>
      <table>
      <tbody>
      <tr><td>hyvä</td><td>{props.good}</td></tr>
      <tr><td>neutraali</td><td>{props.neutral}</td></tr>
      <tr><td>huono</td><td>{props.bad}</td></tr>
      <tr><td>keskiarvo</td><td>{props.average}</td></tr>
      <tr><td>positiivisia</td><td>{props.positive}%</td></tr>
      </tbody>
      </table> 
    </div>
  )
}
const Tyhja = 'ei yhtään palautetta annettu'
class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      counter1: 0,
      counter2: 0,
      counter3: 0
    }
  }
  klikHyva = () => {
    this.setState({
      counter1:this.state.counter1 + 1
    })
  }
  klikNeutraali = () => {
    this.setState({
      counter2:this.state.counter2 + 1
    })
  }
  klikHuono = () => {
    this.setState({
      counter3:this.state.counter3 + 1
    })
  }
  
  render() {
    const historia = () => {
      if (this.state.counter1===0) {
        if (this.state.counter2===0){
          if(this.state.counter3===0){
            return (
              <div>
                <p>ei yhtään palautetta annettu</p>
              </div>
            )
          }
        }
      }
      return (
        <div>
          <Statistics good={this.state.counter1} neutral={this.state.counter2} bad={this.state.counter3} average={keskiarvo} positive={positiivisia}/>
        </div>
      )
    }
    
    let pisteet= this.state.counter1 - this.state.counter3
    let kaikki= this.state.counter1 + this.state.counter2 + this.state.counter3
    let keskiarvo= Math.round(pisteet/kaikki*10)/10
    let positiivisia= Math.round(this.state.counter1/kaikki*1000)/10
    return (
      <div>
        <h2>anna palautetta</h2>
        <button onClick={this.klikHyva}>hyvä</button>
        <button onClick={this.klikNeutraali}>neutraali</button>
        <button onClick={this.klikHuono}>huono</button>
        <h2>statistiikka</h2>
        {historia()}
      </div>
    )
  }
}
ReactDOM.render(<App />, document.getElementById('root'))