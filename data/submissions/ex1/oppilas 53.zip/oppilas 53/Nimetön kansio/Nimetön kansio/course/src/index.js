import React from 'react'
import ReactDOM from 'react-dom'
const Header = (props) => {
  return (
    <div>
      <h1>{props.otsikko}!</h1>
    </div>
  )
}
const Total = (props) => {
  return (
    <div>
      <p>Total {props.koko} exercises</p>
    </div>
  )
}
const Contents = (props) => {
  return (
    <div>
      <Part sisalto11={props.sisalto1} arvo11={props.arvo1} />
      <Part sisalto11={props.sisalto2} arvo11={props.arvo2} />
      <Part sisalto11={props.sisalto3} arvo11={props.arvo3} />
    </div>
  )
}
const Part = (props) => {
  return (
    <div>
      <p>{props.sisalto11} : {props.arvo11}</p>
    </div>
  )
}
const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
    {
      name: 'Basics of React',
      exercises:  8 },
    {
      name: 'Using props',
      exercises: 10 },
    {
      name: 'Component states',
      exercises: 12 } ] }
  return (
    <div>
      <Header otsikko={course.name} />
      <Contents sisalto1={course.parts[0].name} arvo1={course.parts[0].exercises} sisalto2={course.parts[1].name} arvo2={course.parts[1].exercises} sisalto3={course.parts[2].name} arvo3={course.parts[2].exercises} />
      <Total koko={course.parts[0].exercises + course.parts[1].exercises + course.parts[2].exercises}/>
    </div>
  )
}
ReactDOM.render(<App />, document.getElementById('root'))