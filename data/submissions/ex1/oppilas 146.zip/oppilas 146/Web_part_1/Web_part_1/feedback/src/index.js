import { render } from '@testing-library/react'
import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <h1>{props.otsikko}</h1>
    </div>
  )
}

const Button = (props) => {
  return (
    <div>
      <button onClick={() => this.lisaaVaste}>{props.napinTeksti}</button>
    </div>
  )
}

const Statistic = (props) => {
  return (
    <tr>
      <td>{props.eka}&nbsp;</td>
      <td>{props.toka}</td>
    </tr>
  )
}

const Statistics = (props) => {
  return (
    <table>
      <tbody>
        <Statistic eka ={"Hyvä"} toka ={props.tilasto.length} />
        <Statistic eka ={"Neutraali"} toka ={props.tilasto.length} />
        <Statistic eka ={"Huono"} toka ={props.tilasto.length} />
        <Statistic eka ={"Keskiarvo"} toka ={props.tilasto.length} />
        <Statistic eka ={"Positiivisia"} toka ={props.tilasto.length + " %"} />
      </tbody>
    </table>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      lista: [],
      vaste: props.vaste
    }
    this.lisaaVaste = this.lisaaVaste.bind(this)
  }

  lisaaVaste = () => {
    this.setState({ lista: this.state.lista.contact(this.state.vaste) })
  }

  render() {
    return (
      <div>
        <Header otsikko = {"Anna palautetta"} />
        <Button napinTeksti = {"Hyvä"} vaste = {1} />
        <Button napinTeksti = {"Neutraali"} vaste = {0} />
        <Button napinTeksti = {"Huono"} vaste = {-1} />
        <Header otsikko = {"Statistiikka"} />
        <Statistics tilasto = {this.state.lista}/>
      </div>
    )
  }
}  

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
