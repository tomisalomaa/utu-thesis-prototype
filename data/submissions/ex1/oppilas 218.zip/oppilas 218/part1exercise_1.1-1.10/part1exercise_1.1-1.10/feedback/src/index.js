import React from 'react'
import ReactDOM from 'react-dom'

// Tasks 6, 7, 8, 9 & 10
const Header = (props) => {
  return (
    <div>
      <h1> {props.title} </h1>
    </div>
  )
}

class Parent extends React.Component{
  constructor(props){
      super(props)
      this.state ={
          countGood : 0,
          countNeutral : 0,
          countBad : 0,
          calc : 0,
          total : 0
      }
  }

  incrementGood = () => {
    this.setState({countGood : this.state.countGood + 1})
    this.setState({calc : this.state.calc + 1})
    this.setState({total : this.state.total + 1})
  }

  incrementNeutral = () => {
    this.setState({countNeutral : this.state.countNeutral + 1})
    this.setState({total : this.state.total + 1})
  }   

  incrementBad = () => {
    this.setState({countBad : this.state.countBad + 1})
    this.setState({calc : this.state.calc - 1})
    this.setState({total : this.state.total + 1})
  }

    render () {
      return (
       <div>
          <Button 
          clickGood={this.incrementGood} nameGood={this.props.nameGood}
          clickNeutral={this.incrementNeutral} nameNeutral={this.props.nameNeutral}
          clickBad={this.incrementBad} nameBad={this.props.nameBad}
          />
          <StatisticTitle statisticTitle={'Statistiikka'}/>
          <Statistics 
          nameGood={'Hyvä'} countGood={this.state.countGood}
          nameNeutral={'Neutraali'} countNeutral={this.state.countNeutral}
          nameBad={'Huono'} countBad={this.state.countBad}
          nameAvarage={'Keskiarvo'} avarage={(this.state.calc/this.state.total).toFixed(1)}
          namePositives={'Positiivisia'} positives={((this.state.countGood/this.state.total)*100).toFixed(1)+'%'}
          />
        </div>
      )
    }
  }

const Button = (props) => {
  return (
    <div>
      <button onClick={props.clickGood}>{props.nameGood}</button>
      <button onClick={props.clickNeutral}>{props.nameNeutral}</button>
      <button onClick={props.clickBad}>{props.nameBad}</button>
    </div>
  )
}

const StatisticTitle = (props) => {
  return (
    <div>
      <h2>{props.statisticTitle}</h2>
    </div>
  )
}

const Statistics = (props) => {
  if ((props.countGood || props.countNeutral || props.countBad) !== 0) {
    const values =
    [
      <Statistic name={props.nameGood} statistics={props.countGood}/>,
      <Statistic name={props.nameNeutral} statistics={props.countNeutral}/>,
      <Statistic name={props.nameBad} statistics={props.countBad}/>,
      <Statistic name={props.nameAvarage} statistics={props.avarage}/>,
      <Statistic name={props.namePositives} statistics={props.positives}/>
    ]
  return (
    <table style={{lineHeight:0}}>
      <tbody>
        <tr>
          <td>{values[0]}</td>
        </tr>
        <tr>
          <td>{values[1]}</td>
        </tr>
        <tr>
          <td>{values[2]}</td>
        </tr>
        <tr>
          <td>{values[3]}</td>
        </tr>
        <tr>
          <td>{values[4]}</td>
        </tr>
      </tbody>
    </table>
  )
  } else
  return (
    <div>
      <h4>Ei yhtään palautetta annettu!</h4>
    </div>
  )
}


// Before task 10
/*
const Statistics = (props) => {
  if ((props.countGood || props.countNeutral || props.countBad) !== 0) {
  return (
    <div>
      <Statistic name={props.nameGood} statistics={props.countGood}/>
      <Statistic name={props.nameNeutral} statistics={props.countNeutral}/>
      <Statistic name={props.nameBad} statistics={props.countBad}/>
      <Statistic name={props.nameAvarage} statistics={props.avarage}/>
      <Statistic name={props.namePositives} statistics={props.positives}/>
    </div>
  )
  } else
  return (
    <div>
      <h4>Ei yhtään palautetta annettu!</h4>
    </div>
  )
}
*/

const Statistic = (props) => {
  return (
    <div>
      <h4>{props.name}: {props.statistics}</h4>
    </div>
  )
}

const App = () => {
  const title = 'Anna palautetta'
  return (
    <div>
      <Header title={title} />
      <Parent
       nameGood={'Hyvä'} nameNeutral={'Neutraali'} nameBad={'Huono'}
      />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)