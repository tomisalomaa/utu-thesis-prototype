import React from 'react'
import ReactDOM from 'react-dom'

// Tasks 1, 2, 3, 4 & 5

const Header = (props) => {
  return (
    <div>
      <h1> {props.course} </h1>
    </div>
  )
}

// Task 2 will modify task 1 here
/*
const Contents = (props) => {
  return (
    <div>
      <p> The part is named "{props.part1}" and it contains {props.exercises1} exercises! </p>
      <p> The part is named "{props.part2}" and it contains {props.exercises2} exercises! </p>
      <p> The part is named "{props.part3}" and it contains {props.exercises3} exercises! </p>
    </div>
  )
}
*/

const Contents = (props) => {
  return (
    <div>
      <Part name={props.parts[0].name} exercises={props.parts[0].exercises} />
      <Part name={props.parts[1].name} exercises={props.parts[1].exercises} />
      <Part name={props.parts[2].name} exercises={props.parts[2].exercises} />
    </div>
  )
}

const Part = (props) => {
  return (
    <div>
      <p> The part is named "{props.name}" and it contains {props.exercises} exercises! </p>
    </div>
  )
}

// I wanted to learn so I did this with loop
const Total = (props) => {
  let total = 0
  for (let i=0; i<props.parts.length; i++) {
      total += props.parts[i].exercises
  }
  return (
    <div>
      <p> The total amount of exercises is {total}! </p>
    </div>
  )
}

// Task 3 will modify tasks 1 & 2 here
/*
function App() {
  const course = 'Superadvanced web and mobile programming'
  const part1 = 'Basics of React'
  const exercises1 = 8
  const part2 = 'Using props'
  const exercises2 = 10
  const part3 = 'Component states'
  const exercises3 = 12

  // Task 2 will modify task 1 here
  return (
    <div>
      <Header course={course} />
     <Contents 
        part1={part1} exercises1={exercises1}
        part2={part2} exercises2={exercises2} 
        part3={part3} exercises3={exercises3} 
      />

      <Total total={exercises1 + exercises2 + exercises3} />
    </div>
  )
}
*/

// Task 4 will modify task 3 here (changing to array) - Task 5 will modify task 4 here
const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  // Task 4 will modify task 3 here (deleting seperate props and changing to array) - Task 5 will modify task 4 here
  return (
    <div>
      <Header course={course.name} />
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)