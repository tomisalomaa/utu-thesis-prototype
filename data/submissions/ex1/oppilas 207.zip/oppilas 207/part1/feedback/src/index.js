import React from 'react'
import ReactDOM from 'react-dom'

const Button = ({handleClick, text}) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistic = ({text, value}) => (
    <tr>
      <td>{text}</td>
      <td>{value}</td>
    </tr>
)

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0,
      average: 0,
      positive: 0,
      total: 0
    }
  }

  clickGood = () => {
    this.setState({
      good: this.state.good + 1,
      average: (this.state.good - this.state.bad)/(this.state.good+this.state.neutral+this.state.bad),
      positive: (this.state.good/(this.state.good+this.state.neutral+this.state.bad))*100,
      total: this.state.total +1
    })
  }

  clickNeutral = () => {
    this.setState({
      neutral: this.state.neutral + 1,
      average: (this.state.good - this.state.bad)/(this.state.good+this.state.neutral+this.state.bad),
      positive: (this.state.good/(this.state.good+this.state.neutral+this.state.bad))*100,
      total: this.state.total +1
    })
  }

  clickBad = () => {
    this.setState({
      bad: this.state.bad + 1,
      average: (this.state.good - this.state.bad)/(this.state.good+this.state.neutral+this.state.bad),
      positive: (this.state.good/(this.state.good+this.state.neutral+this.state.bad))*100,
      total: this.state.total +1
    })
  }

  render() {
    const Statistics = () => {
      if (this.state.total === 0){
        return(
          <div>
            <p>no feedback has been given</p>
          </div>
        )
      }
      return(
        <div>
          <table>
            <Statistic text="bad:" value={this.state.bad} />
            <Statistic text="neutral:" value={this.state.neutral} />
            <Statistic text="good:" value={this.state.good} />
            <Statistic text="average:" value={this.state.average} />
            <Statistic text="positive:" value={this.state.positive} />
            <Statistic text="total:" value={this.state.total} />
          </table>
        </div>
      )
    }
    return (
      <div>
        <h1>give your feedback</h1>
         <Button handleClick={this.clickBad} text="bad"/>
         <Button handleClick={this.clickNeutral} text="neutral" />
         <Button handleClick={this.clickGood} text="good" />
        <h1>statistics</h1>
        {Statistics()}


      </div>
    )
  }
}



ReactDOM.render(
  <App />,
  document.getElementById('root')
)
