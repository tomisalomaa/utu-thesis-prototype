import React from 'react';
import ReactDOM from 'react-dom';

const feedback = {
  good: "hyvä",
  neutral: "neutraali",
  bad: "huono",
  avg: "keskiarvo",
  pos: "positiivisia"
} 

const Button = ({handleClick, text}) => {
  return (
    <button onClick={handleClick}>{text}</button>
  )
}

const Statistics = (props) => {
  return (
    <table>
      <thead>
      </thead>
      <tbody>
          <Statistic count={props.state.good} text={props.feedback.good} />
          <Statistic count={props.state.neutral} text={props.feedback.neutral}/>
          <Statistic count={props.state.bad} text={props.feedback.bad}/>
          <Statistic count={props.avg} text={props.feedback.avg}/>
          <Statistic count={props.pos} text={props.feedback.pos}/>
      </tbody>
    </table>
  )
}

const Statistic = (props) => {
  return (
    <tr>
      <td>{props.text}</td>
      <td>{props.count}</td>
    </tr>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      good: 0,
      neutral: 0,
      bad: 0
    }
  }

  klikGood = () => this.setState({
    good: this.state.good + 1
  })
  klikNeutral = () => this.setState({
    neutral: this.state.neutral + 1
  })
  klikBad = () => this.setState({
    bad: this.state.bad + 1
  })

  render(){
    const average = () => {
      let num = (1*this.state.good + 0*this.state.neutral - 1*this.state.bad)/(this.state.good + this.state.neutral + this.state.bad)
      return num.toFixed(1)
    }
    const positives = () => {
      let num = 100 * (this.state.good/(this.state.good + this.state.neutral + this.state.bad))
      return num.toFixed(1) + ' %'
    }

    if (this.state.good === 0 && this.state.neutral === 0 && this.state.bad === 0) {
      return (
        <div>
          <h1>anna palautetta</h1>
          <Button handleClick={this.klikGood} text={feedback.good} />
          <Button handleClick={this.klikNeutral} text={feedback.neutral} />
          <Button handleClick={this.klikBad} text={feedback.bad} />
          <h1>statistiikka</h1>
          <div>ei yhtään palautetta annettu</div>
        </div>
        
      )
    }
    return (
      <div>
        <h1>anna palautetta</h1>
        <Button handleClick={this.klikGood} text={feedback.good} />
        <Button handleClick={this.klikNeutral} text={feedback.neutral} />
        <Button handleClick={this.klikBad} text={feedback.bad} />
        <h1>statistiikka</h1>
        <Statistics state={this.state} feedback={feedback} avg={average()} pos={positives()} />
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
