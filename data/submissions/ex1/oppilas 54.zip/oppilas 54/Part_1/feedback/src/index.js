import React from 'react';
import ReactDOM from 'react-dom';

//Tässä osat 1.6-1.8.

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyvä: 0,
      neutraali: 0,
      huono: 0,
      kaikki: 0
    }
  }

  klikHyvä = () => {
    this.setState({
      hyvä: this.state.hyvä + 1,
      kaikki:this.state.kaikki + 1
    })
  }

  klikNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      kaikki:this.state.kaikki + 1
    })
  }
  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      kaikki:this.state.kaikki + 1
    })
  }
  Buttons = () => {
    return (
    <div>
      <button onClick={this.klikHyvä}>hyvä</button>
      <button onClick={this.klikNeutraali}>neutraali</button>
      <button onClick={this.klikHuono}>huono</button>
    </div>
    )
  }
  HtmlTable = () => {
    return(
      <table>
        <tbody>
          <tr>
            <td>hyvä</td>
            <td>{this.state.hyvä}</td>
          </tr>
          <tr>
            <td>neutraali</td>
            <td>{this.state.neutraali}</td>
          </tr>
          <tr>
            <td>huono</td>
            <td>{this.state.huono}</td>
          </tr>
          <tr>
            <td>keskiarvo</td>
            <td><this.Statistic /></td>
          </tr>
          <tr>
            <td>positiivisia</td>
            <td>{(this.state.hyvä/this.state.kaikki * 100).toFixed(1)} %</td>
          </tr>
        </tbody>
      </table>
    )
  }

  Statistics = () => {
    return (
      <div>
        <this.HtmlTable />
      </div>
    )
  }
  Statistic = () => {
    return (
      <div>
        <p>{((this.state.hyvä-this.state.huono)/this.state.kaikki).toFixed(1)}</p>
      </div>
    )
  }

  render() {
    
    if(this.state.hyvä === 0 && this.state.neutraali === 0 && this.state.huono === 0){
      return(
        <div>
          <h1>anna palautetta</h1>
          <this.Buttons />
          <p>ei yhtään palautetta annettu</p>
        </div>
        )
    } else{
    return (
      <div>
        <h1>anna palautetta</h1>
        <this.Buttons />
        <this.Statistics/>
      </div>
    )
    }
  }
}


ReactDOM.render(
  <App />,
  document.getElementById('root')
)