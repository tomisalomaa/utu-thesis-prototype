import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }
  }

  lisaaHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1,
    })
  }

  lisaaNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
    })
  }

  lisaaHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
    })
  }

  render() {
    return (
      <div>
        <div>
          <h1>Anna palautetta</h1>
          <button onClick={this.lisaaHyva}>hyvä</button>
          <button onClick={this.lisaaNeutraali}>neutraali</button>
          <button onClick={this.lisaaHuono}>huono</button>
          <h1>Statistiikka</h1>
          <p>hyvä {this.state.hyva}</p>
          <p>neutraali {this.state.neutraali}</p>
          <p>huono {this.state.huono}</p>
        </div>
      </div>
    )
  }
}


ReactDOM.render(<App />, document.getElementById('root'))
