import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0,
      maara: 0,
      keskiarvo: 0,
    }
  }

  lisaaHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1,
      maara: this.state.maara + 1,
      keskiarvo: this.state.keskiarvo + 1
    })
  }

  lisaaNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      maara: this.state.maara + 1
    })
  }

  lisaaHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      maara: this.state.maara + 1,
      keskiarvo: this.state.keskiarvo - 1
    })
  }

  
  
  render() {
    return (
      <div>
        <div>
          <h1>Anna palautetta</h1>
          <Button handleClick={this.lisaaHyva} text = "hyvä"/>
          <Button handleClick={this.lisaaNeutraali} text = "neutraali"/>
          <Button handleClick={this.lisaaHuono} text = "huono"/>
          <Statistics props={this.state} />
        </div>
      </div>
    )
  }
}

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

const Statistics = ({props}) => {
  if (props.maara === 0){
        return (
          <p>Ei yhtään palautetta annettu</p>
        )
      }
      else
  return (
    <div>
    <h1>Statistiikka</h1>
    <Statistic tyyppi="hyvä" arvo={props.hyva} />
    <Statistic tyyppi="neutraali" arvo={props.neutraali} />
    <Statistic tyyppi="huono" arvo={props.huono} />
    <Statistic tyyppi="keskiarvo" arvo={((props.keskiarvo)/(props.maara)).toFixed(1)} />
    <Statistic tyyppi="positiivisia" arvo={((props.hyva) / (props.maara)* 100).toFixed(1)} /> 
    </div>
  )
}

const Statistic = ({ tyyppi, arvo }) => {
  if (tyyppi==="positiivisia"){
    return (
      <div>{tyyppi} {arvo} %</div>
    )
  }
  else
  return (
    <div>{tyyppi} {arvo}</div>
  )
}


ReactDOM.render(<App />, document.getElementById('root'))
