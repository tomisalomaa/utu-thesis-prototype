import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0,
      maara: 0,
      keskiarvo: 0,
    }
  }

  lisaaHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1,
      maara: this.state.maara + 1,
      keskiarvo: this.state.keskiarvo + 1
    })
  }

  lisaaNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1,
      maara: this.state.maara + 1
    })
  }

  lisaaHuono = () => {
    this.setState({
      huono: this.state.huono + 1,
      maara: this.state.maara + 1,
      keskiarvo: this.state.keskiarvo - 1
    })
  }


  render() {
    return (
      <div>
        <div>
          <h1>Anna palautetta</h1>
          <button onClick={this.lisaaHyva}>hyvä</button>
          <button onClick={this.lisaaNeutraali}>neutraali</button>
          <button onClick={this.lisaaHuono}>huono</button>
          <h1>Statistiikka</h1>
          <p>hyvä {this.state.hyva}</p>
          <p>neutraali {this.state.neutraali}</p>
          <p>huono {this.state.huono}</p>
          <p>keskiarvo {((this.state.keskiarvo)/(this.state.maara)).toFixed(1)}</p>
          <p>positiivisia {((this.state.hyva) / (this.state.maara)* 100).toFixed(1)} %</p>
        </div>
      </div>
    )
  }
}


ReactDOM.render(<App />, document.getElementById('root'))
