import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }
  }

  addHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1
    })
  }

  addNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1
    })
  }

  addHuono = () => {
    this.setState({
      huono: this.state.huono + 1
    })
  }

  render() {
    const total = this.state.hyva + this.state.neutraali + this.state.huono
    
    return (
      <div>
        <h2>Anna palautetta!</h2>
        <Button handleClick={this.addHyva} text='Hyvä'/>
        <Button handleClick={this.addNeutraali} text='Neutraali' />
        <Button handleClick={this.addHuono} text='Huono' />
        <h3>Statistiikkaa:</h3>
        <Statistics hyva={this.state.hyva} 
                    neutraali={this.state.neutraali} 
                    huono={this.state.huono}
                    total={total}
        />
      </div>
    )
  }
}

const Button = ({handleClick, text}) => {
  return <button onClick={handleClick}>{text}</button>
}

const Statistics = ({hyva, neutraali, huono, total}) => {
  if (total === 0) {
    return <div>Ei yhtään palautetta annettu...</div>
  }

  return (
    <table>
      <tbody>
        <Statistic content={['Hyvä: ', hyva]} />
        <Statistic content={['Neutraali: ', neutraali]} />
        <Statistic content={['Huono: ', huono]} />
        <Statistic content={['Keskiarvo: ', ((hyva - huono) / total).toFixed(1)]} />
        <Statistic content={['Positiivisia: ', (((hyva) / total) * 100).toFixed(1) + '%']} />
      </tbody>
    </table>
  )
}

const Statistic = ({content}) => {
  return (
    <tr>
      {content.map(value => <td key={value}>{value}</td>)}
    </tr>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)