import React from 'react';
import ReactDOM from 'react-dom'

const Button = (props) => {
  console.log(props)
  const { handleClick, text } = props
  return (
    <button onClick={handleClick}>
      {text}
    </button>
  )
}

const Statistics = (props) => {
  return (
    <table>
      <tbody>
      <Statistic name="hyvä " stat={props.hyva} />
      <Statistic name="neutraali " stat={props.neutraali} />
      <Statistic name="huono " stat={props.huono} />
      <Statistic name="keskiarvo " stat={props.keskiarvo} />
      <Statistic name="positiivisia " stat={props.positiivisia} />
      </tbody>
    </table>
  )
}

const Statistic = (props) => {
  return (
    <tr>
      <td>{props.name}</td>
      <td>{props.stat}</td>
    </tr>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0,
      kaikki: 0,
      vertailu: 0
    }
  }

  klikHyva = () => {
    return () => {
      this.setState({
        hyva: this.state.hyva + 1,
        kaikki: this.state.kaikki + 1,
        vertailu: this.state.vertailu + 1
      })
    }
  }

  klikNeutraali = () => {
    return () => {
      this.setState({
        neutraali: this.state.neutraali + 1,
        kaikki: this.state.kaikki + 1
      })
    }
  }

  keskiarvo() {
    return this.state.vertailu / this.state.kaikki
  }

  prosentti() {
    return this.state.hyva / this.state.kaikki * 100
  }

  klikHuono = () => {
    return () => {
      this.setState({
        huono: this.state.huono + 1,
        kaikki: this.state.kaikki + 1,
        vertailu: this.state.vertailu - 1
      })
    }
  }

  render() {
    let StatComp;

    if (this.state.kaikki > 0){
      StatComp=
      <Statistics
        kaikki={this.props.kaikki}
        hyva={this.state.hyva}
        neutraali={this.state.neutraali}
        huono={this.state.huono}
        keskiarvo={this.keskiarvo()}
        positiivisia={`${this.prosentti()} %`} />
    } else {
      StatComp=
      <p>ei yhtään palautetta annettu</p>
    }


    return (
      <div>
        <div>
          <h1>anna palautetta</h1>
          <Button handleClick={this.klikHyva()} text="hyvä" />
          <Button handleClick={this.klikNeutraali()} text="neutraali" />
          <Button handleClick={this.klikHuono()} text="huono" />
          <h1>statistiikka</h1>
          {StatComp}
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root'))