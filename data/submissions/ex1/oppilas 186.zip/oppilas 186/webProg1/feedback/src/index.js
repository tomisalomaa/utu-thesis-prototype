import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      neut: 0,
      huon: 0
    }
  }
   render() {
     return (
       <div>
         <Title text={"anna palautetta"}/>
         <Button text={"hyvä"} handleClick={() => this.setState((prev) => ({hyva: prev.hyva+1}))}/>
         <Button text={"neutraali"} handleClick={() => this.setState((prev) => ({neut: prev.neut+1}))}/>
         <Button text={"huono"} handleClick={() => this.setState((prev) => ({huon: prev.huon+1}))}/>
         <Title text={"statistiikka"}/>
         <Statistics stat={this.state}/>
       </div>
     )
   }
}
const Title = (props) => <div><h1>{props.text}</h1></div>
const Button = (props) => {
  return (
    <button onClick={props.handleClick}>{props.text}</button>
  )
}
const Statistic = ({text, value}) => {
  return (
  <tr>
    <td>{text}</td>
    <td>{value}</td>
  </tr>
  )
}

const Statistics = ({stat}) => {
  const {hyva, huon, neut} = stat
  const sum = stat.hyva + stat.neut + stat.huon
  const ka = (hyva - huon)/sum
  const pos = hyva/sum *100

  if (sum === 0) {
      return <div>ei yhtään palautetta annettu</div>
  }

  return (
    <div>
      <table>
      <tbody>
          <Statistic text={"hyvä"} value={hyva}/>
          <Statistic text={"neutraali"} value={neut}/>
          <Statistic text={"huono"} value={huon}/>
          <tr>
            <td>keskiarvo</td> 
            <td>{ka}</td>
          </tr>
          <tr>
            <td>positiivisia</td> 
            <td>{pos} % </td>
          </tr>
        </tbody>  
      </table>
    </div>
  )
  
}
ReactDOM.render(
  <App/>,
  document.getElementById('root')
);

