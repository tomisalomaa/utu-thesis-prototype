import React from 'react'
import ReactDOM from 'react-dom'

const Part1 = (props) => {
  return (
    <div>
      <p>Basics of React {props.exercises1}</p>
    </div>
  )
}

const Part2 = (props) => {
  return (
    <div>
      <p>Using props {props.exercises2}</p>
    </div>
  )
}
const Part3 = (props) => {
  return (
    <div>
      <p>Component states {props.exercises3}</p>
    </div>
  )
}

const Contents = () => {
  return (
    <div>
      <Part1 exercises1="8"/>
      <Part2 exercises2="10"/>
      <Part3 exercises3="12"/>
    </div>
  )
}

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = 'Basics of React'
  const exercises1 = 8
  const part2 = 'Using props'
  const exercises2 = 10
  const part3 = 'Component states'
  const exercises3 = 12

  return (
    <div>
      <h1>{course}</h1>
      <Contents />
      <p>Total {exercises1 + exercises2 + exercises3} exercises</p>
    </div>
  )
}




ReactDOM.render(
  <App />,
  document.getElementById('root')
)