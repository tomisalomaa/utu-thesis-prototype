import React from 'react'
import ReactDOM from 'react-dom'


const Header =() => {
  return (
    <div>
      <p>Superadvanced web and mobile programming</p>
    </div>
  )
}

const Contents =(props) => {
  return (
    <div>
      <p>Basics of React {props.exercises1}</p>
      <p>Using props {props.exercises2}</p>
      <p>Component states{props.exercises3}</p>
    </div>
  )
}

const Total =(props) => {
  const part1 = 'Basics of React'
  const exercises1 = 8
  const part2 = 'Using props'
  const exercises2 = 10
  const part3 = 'Component states'
  const exercises3 = 12
  return (
    <div>
      <p>{exercises1 + exercises2 +exercises3}</p>
    </div>
  )
}

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  


  return (
    <div>
      <Header course ={course} />
      <Contents/>
      <Total/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
