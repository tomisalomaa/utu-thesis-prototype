import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyvä: 0,
      neutraali: 0,
      huono: 0,
      good: [],
      neutral : [],
      poor: []
    }
  }

  klikVasen = () => {
    this.setState(
      {
      hyvä: this.state.hyvä + 1,
      good: this.state.good.concat('g')
    }
    )
  }

  klikOikea = () => {
    this.setState(
      {
      neutraali: this.state.neutraali + 1,
      neutral : this.state.neutral .concat('n')
    }
    )
  }

  klikOikeas = () => {
    this.setState(
      {
      huono: this.state.huono + 1,
      poor : this.state.poor .concat('p')
    }
    )
  }

  

  render() {
    const Statistics = (props) => {
      return (
        <div>
          <p>{props.historia}</p>
        </div>
        
      )
    }

    const Statistic = (props) => {
      return (
        <div>
          <table>
            <tr>
              <td>keskiarvo:</td>
              <td>{props.average}</td>
            </tr>
            <tr>
              <td>postitiivisia:</td>
              <td>{props.percentage}</td>
            </tr>
          </table>
        </div>
      )
    }

    const Button = ({ handleClick, text }) => (
      <button onClick={handleClick}>
        {text}
      </button>
    )

    const historia = () => {
      if (this.state.good.length === 0 & this.state.neutral.length ===0 & this.state.poor.length ===0) {
        return (
          <div>
            <p>ei yhtään palautetta annettu</p>
          </div>
        )
      }
      return (
        <div>
          <table>
            <tr>
              <td>hyvä:</td>
              <td>{this.state.good.length}</td>
            </tr>
            <tr>
              <td>neutraali:</td>
              <td>{this.state.neutral.length}</td>
            </tr>
            <tr>
              <td>huono:</td>
              <td>{this.state.poor.length}</td>
            </tr>
          </table>
          <Statistic average={average()} percentage={percentage()}/>
        </div>
      )
    }

    
    const percentage = () => Math.round(this.state.good.length/(this.state.good.length+this.state.neutral.length+this.state.poor.length)*10000)/100 + "%"
    const average = () => (this.state.good.length*1-this.state.poor.length*1)/10

    return (
      <div>
        <div>
          <h1>anna palautetta</h1>
          <Button 
            handleClick={this.klikVasen}
            text="hyvä"/>
            <Button 
            handleClick={this.klikOikea}
            text="neutraali"/>
            <Button 
            handleClick={this.klikOikeas}
            text="huono"/>
          <h1>statistiikka</h1>
          <Statistics historia={historia()}/>
        </div>
      </div>
    )
  }
}

ReactDOM.render(
  <App />, 
  document.getElementById('root')
)