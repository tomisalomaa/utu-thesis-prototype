import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
     <div>
       <p>{props.course}</p>
     </div>
  )

}

const Contents = (props) => {
  return (
    <div>
      <Part1 part1="Basics of React" exercises1="8" />
      <Part2 part2="Using props" exercises2="10" />
      <Part3 part3="Component states" exercises3="12" />
    </div>
  )

}

const Total = (props) => {
  return (
    <div>
      <p>Total {props.exercises1 + props.exercises2 + props.exercises3} exercises</p>
    </div>
  )

}

const Part1 = (props) => {
  return (
    <p>{props.part1} {props.exercises1}</p>
  )
}

const Part2 = (props) => {
  return (
    <p>{props.part2} {props.exercises2}</p>
  )
}

const Part3 = (props) => {
  return (
    <p>{props.part3} {props.exercises3}</p>
  )
}

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course.name} />
      <Contents parts={course.parts} />
      <p>Total 30 exercises</p>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)