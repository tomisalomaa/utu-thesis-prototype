import React from 'react'
import ReactDOM from 'react-dom'

const Header = (props) => {
  return (
    <div>
      <h1> Header </h1>
      <h3> {props.course}</h3>
    </div>
  )
}

const Part = (props) => {
  return (
    <div>
      <p> {props.name}: {props.exercises} </p>
      

    </div>
  )

}

const Contents = (props) => {
  
  return (
  <div>
    <h2> Contents </h2>
    <Part name = {props.parts[0].name} exercises = {props.parts[0].exercises}/>
    <Part name = {props.parts[1].name} exercises = {props.parts[1].exercises} />
    <Part name = {props.parts[2].name} exercises = {props.parts[2].exercises} />
    
  </div>
  )
}

const Total = (props) => {
  return (
    <div>
      <br/> <br/>
      <p>Total {props.parts[0].exercises + props.parts[1].exercises + props.parts[2].exercises}</p>
    </div>
  
  )
}

const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const parts = [
    {
      name: 'Basics of React',
      exercises: 8
    },
    {
      name: 'Using props',
      exercises: 10
    },
    {
      name: 'Component states',
      exercises: 12
    }
  ]
  
  
  return (
    <div>
      <Header course={course} />
      <Contents parts = {parts} />
      <Total parts = {parts} />
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
