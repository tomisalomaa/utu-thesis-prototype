import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import reportWebVitals from './reportWebVitals';

const Button = (props) => {
  return (
    
      <button onClick={props.funktio}>
          {props.name} </button>
  
  )
}
const Statistics = (props) => {
  if (props.hyva + props.neutraali + props.huono === 0) {
    return (
      <div>
        <h2> Statistiikka </h2>
        <p> ei yhtään palautetta annettu </p>
      </div>
    )
  }
  return (
    <div>
      <h2> Statistiikka </h2>
      <table>
      <tbody>
        
          <Statistic name = 'Hyvä' value = {props.hyva}/>
          <Statistic name = 'Neutraali' value = {props.neutraali} />
          <Statistic name = 'Huono' value = {props.huono}/>
          <Statistic name = 'Keskiarvo' value = {(props.hyva-props.huono)/(props.hyva+props.neutraali+props.huono)}/>
          <Statistic name = 'Positiivisia' value = {(props.hyva*100)/(props.hyva+props.neutraali+props.huono)} unit = '%' />
     
          </tbody>
        </table>
      
    </div>
  )
}
const Statistic = (props) => {
  return (
    <tr>
      <td>{props.name} </td>
      <td>{props.value} {props.unit} </td>
    </tr>
  )
}

class Feedback extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      neutraali: 0 ,
      huono: 0
    }
    this.kasvataHyvaa = this.kasvataHyvaa.bind(this)
    this.kasvataNeutraalia = this.kasvataNeutraalia.bind(this)
    this.kasvataHuonoa = this.kasvataHuonoa.bind(this)
  }

  kasvataHyvaa() {
    this.setState({ hyva: this.state.hyva + 1 })
  }
  kasvataNeutraalia() {
    this.setState({ neutraali: this.state.neutraali + 1 })
  }
  kasvataHuonoa() {
    this.setState({ huono: this.state.huono + 1 })
  }

  render() {
    return (
      <div>
        <h1> Anna palautetta </h1>
        
        <div>
        <Button name = 'Hyvä'
        funktio = {this.kasvataHyvaa}/>
        <Button name = 'Neutraali'
        funktio = {this.kasvataNeutraalia}/>
        <Button name = 'Huono'
        funktio = {this.kasvataHuonoa}/>
        <Statistics hyva = {this.state.hyva}
        neutraali = {this.state.neutraali}
        huono = {this.state.huono} />
        
        

        
          
      </div>
      </div>
    )
  }
}

ReactDOM.render(
  <React.StrictMode>
    <Feedback />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
