import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import reportWebVitals from './reportWebVitals';

class Feedback extends React.Component {
  constructor() {
    super()
    this.state = {
      hyva: 0,
      neutraali: 0 ,
      huono: 0
    }
    this.kasvataHyvaa = this.kasvataHyvaa.bind(this)
    this.kasvataNeutraalia = this.kasvataNeutraalia.bind(this)
    this.kasvataHuonoa = this.kasvataHuonoa.bind(this)
  }

  kasvataHyvaa() {
    this.setState({ hyva: this.state.hyva + 1 })
  }
  kasvataNeutraalia() {
    this.setState({ neutraali: this.state.neutraali + 1 })
  }
  kasvataHuonoa() {
    this.setState({ huono: this.state.huono + 1 })
  }

  render() {
    return (
      <div>
        <h1> Anna palautetta </h1>
        
        <div>
        <button onClick={this.kasvataHyvaa}>
          Hyvä </button>
        <button onClick={this.kasvataNeutraalia}>
          Neutraali </button>
        <button onClick={this.kasvataHuonoa}>
          Huono </button>
        
        <h2> Statistiikka </h2>

        <p> Hyvä {this.state.hyva}</p>
        <p> Neutraali {this.state.neutraali} </p>
        <p> Huono {this.state.huono}</p>
        <p> Keskiarvo {(this.state.hyva-this.state.huono)/(this.state.hyva+this.state.neutraali+this.state.huono)}</p>
        <p> Positiivisia {(this.state.hyva*100)/(this.state.hyva+this.state.neutraali+this.state.huono)}%</p>
          
      </div>
      </div>
    )
  }
}

ReactDOM.render(
  <React.StrictMode>
    <Feedback />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
