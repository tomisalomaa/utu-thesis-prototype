import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const course = {
    name: 'Superadvanced web and mobile programming',
    parts: [
      {
        name: 'Basics of React',
        exercises: 8
      },
      {
        name: 'Using props',
        exercises: 10
      },
      {
        name: 'Component states',
        exercises: 12
      }
    ]
  }

  return (
    <div>
      <Header course={course.name}/>
      <Contents parts={course.parts} />
      <Total parts={course.parts} />
    </div>
  )
}

const Header = (props) => {
  return(
    <h1>{props.course}</h1>
  )
}

const Part = (props) => {
  return(
    <p>{props.name} {props.exercises}</p>
  )
}

const Contents = (props) => {
  const parts = props.parts;
  return(
    <div>
      {parts.map((part) => (
        <Part key={part.name} name={part.name} exercises={part.exercises} />
      ))}
    </div>
  )
  // return(
  //   <div>
  //     <Part name={parts[0].name} exercises={parts[0].exercises}/>
  //     <Part name={parts[1].name} exercises={parts[1].exercises}/>
  //     <Part name={parts[2].name} exercises={parts[2].exercises}/>
  //   </div>
  // )
}

const Total = ({parts}) => {
  const sum = parts.reduce((result, part) => result + part.exercises, 0)
  return(
    <p>Total {sum} exercises</p>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
