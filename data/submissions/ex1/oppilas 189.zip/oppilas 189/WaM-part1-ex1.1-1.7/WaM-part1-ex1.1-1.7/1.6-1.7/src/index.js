import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {
  constructor(){
    super()
    this.state = {
      feedbackButtons: [
        {key: "good", sum: 0, text: "good"},
        {key: "neutral", sum: 0, text: "neutral"},
        {key: "poor", sum: 0, text: "poor"},
      ],
      average: 0,
      positive: 0
    }
  }

  handler = key => {
    const feedbackButtons = this.state.feedbackButtons;
    const item = feedbackButtons.find((item) => item.key==key)
    item.sum++;
    this.setState({
      feedbackButtons: feedbackButtons,
      average: this.calculateAverage(feedbackButtons),
      positive: this.calculatePositive(feedbackButtons)
    })
  }

  calculateAverage(feedbackButtons) {
    let sum = 0;
    let total = 0;
    feedbackButtons.forEach((item) => {
      if(item.key==="good"){
        sum+=item.sum;
      }
      if(item.key==="poor"){
        sum-=item.sum;
      }
      total+=item.sum;
    });
    return Math.round(sum/total*10)/10;
  }

  calculatePositive(feedbackButtons){
    let pos = 0;
    let sum = 0;
    feedbackButtons.forEach((item) => {
      if(item.key==="good"){
        pos+=item.sum
      }
      sum += item.sum;
    });
    return Math.round(pos/sum*1000)/10;
  }

  render(){
    
    return (
      <div>
        <div>
          <h1>Give feedback</h1>
          {this.state.feedbackButtons.map((item) =>
            <Button handleClick={this.handler} key={item.key} text={item.text} /> )}
        </div>
        <div>
          {this.state.feedbackButtons.map((item) =>
            <p key={item.key}> {item.text} {item.sum}</p>)}
          <p>Average {this.state.average}</p>
          <p>Positive {this.state.positive} %</p>
        </div> 
    </div>
    )
  }
}

const Button = (props) => (
  <button onClick={() => props.handleClick(props.text)}>
    {props.text}</button>
)

ReactDOM.render(<App />, document.getElementById('root'))
