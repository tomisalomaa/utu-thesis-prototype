import React from 'react';
import ReactDOM from 'react-dom';

const Header = (props) => <div><h1>{props.course}</h1></div>

const Part = (props) => <div><p>{props.name} {props.exercises}</p></div>

const Contents = (props) => {
  return (
    <div>
      <Part name={props.part_1.name} exercises={props.part_1.exercises} />
      <Part name={props.part_2.name} exercises={props.part_2.exercises} />
      <Part name={props.part_3.name} exercises={props.part_3.exercises} />
    </div>
  )
}
    
const Total = (props) => <div><p>Total {props.exercise_1 + props.exercise_2 + props.exercise_3} exercises</p></div>
  
const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = {
    name: 'Basics of React',
    exercises: 8
  }
  const part2 = {
    name: 'Using props',
    exercises: 10
  }
  const part3 = {
    name: 'Component states',
    exercises: 12
  }
    return (
      <div>
        <Header course={course} />
        <Contents part_1={part1} part_2={part2} part_3={part3} />
        <Total exercise_1={part1.exercises} exercise_2={part2.exercises} exercise_3={part3.exercises} />
      </div >
    )
}

ReactDOM.render(<App />, document.getElementById('root'));