import React from 'react';
import ReactDOM from 'react-dom';
class App extends React.Component {
  state = {
    good: 0,
    neutral: 0,
    bad: 0
  }

  addGood = () => { this.setState((prevState) => ({ good: prevState.good + 1 })) }
  addNeutral = () => { this.setState((prevState) => ({ neutral: prevState.neutral + 1 })) }
  addBad = () => { this.setState((prevState) => ({ bad: prevState.bad + 1 })) }

  render() {
    let sum = (this.state.good + this.state.neutral + this.state.bad)
    let average = (this.state.good - this.state.bad) === 0 ? 
                  0 : (this.state.good - this.state.bad) / sum
    let positivePercentage = (this.state.good === 0) ? 0 : ((this.state.good) / sum) * 100
    return (
      <div>
        <h2>anna palautetta</h2>
        <button onClick={this.addGood} >hyvä</button>
        <button onClick={this.addNeutral} >neutraali</button>
        <button onClick={this.addBad} >huono</button>
        <h2>statistiikka</h2>
        <p>hyvä {this.state.good}</p>
        <p>neutraali {this.state.neutral}</p>
        <p>huono {this.state.bad}</p>
        <p>keskiarvo {average.toFixed(1)}</p>
        <p>positiivisia {positivePercentage.toFixed(1)} %</p>
      </div>
    )
  }
}

ReactDOM.render(<App />, document.getElementById('root'));