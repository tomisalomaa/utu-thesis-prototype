import React from 'react';
import ReactDOM from 'react-dom';

const Button = ({ onClick, text }) => <button onClick={onClick}>{text}</button>
const Statistic = ({ label, value }) => <tr><td>{label}</td><td>{value}</td></tr>
const Statistics = ({ state }) => {

  if (state.good === 0 && state.neutral === 0 && state.bad === 0)
    return (<tbody><tr><td>ei yhtään palautetta annettu</td></tr></tbody>)
  else {
    let sum = (state.good + state.neutral + state.bad)
    let average = (state.good - state.bad) === 0 ? 0 : (state.good - state.bad) / sum
    let positivePercentage = (state.good === 0) ? 0 : ((state.good) / sum) * 100
    return (
      <tbody>
        <Statistic label='hyvä' value={state.good} />
        <Statistic label='neutraali' value={state.neutral} />
        <Statistic label='huono' value={state.bad} />
        <Statistic label='keskiarvo' value={average.toFixed(1)} />
        <Statistic label='positiivisia' value={positivePercentage.toFixed(1) + ' %'} />
      </tbody>
    )
  }
}
class App extends React.Component {
  state = {
    good: 0,
    neutral: 0,
    bad: 0
  }

  addGood = () => { this.setState((prevState) => ({ good: prevState.good + 1 })) }
  addNeutral = () => { this.setState((prevState) => ({ neutral: prevState.neutral + 1 })) }
  addBad = () => { this.setState((prevState) => ({ bad: prevState.bad + 1 })) }

  render() {
    return (
      <div>
        <div>
          <h2>anna palautetta</h2>
          <Button onClick={this.addGood} text='hyvä' />
          <Button onClick={this.addNeutral} text='neutraali' />
          <Button onClick={this.addBad} text='huono' />
        </div>
        <div>
          <h2>statistiikka</h2>
          <table>
            <Statistics state={this.state} />
          </table>
        </div>
      </div >
    )
  }
}

ReactDOM.render(<App />, document.getElementById('root'));