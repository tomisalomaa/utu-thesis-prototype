import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {
  state = {
    good: 0,
    neutral: 0,
    bad: 0
  }

  addGood = () => { this.setState((prevState) => ({ good: prevState.good + 1 })) }
  addNeutral = () => { this.setState((prevState) => ({ neutral: prevState.neutral + 1 })) }
  addBad = () => { this.setState((prevState) => ({ bad: prevState.bad + 1 })) }

  render() {
    return (
      <div>
        <h2>anna palautetta</h2>
        <button onClick={this.addGood} >hyvä</button>
        <button onClick={this.addNeutral} >neutraali</button>
        <button onClick={this.addBad} >huono</button>
        <h2>statistiikka</h2>
        <p>hyvä {this.state.good}</p>
        <p>neutraali {this.state.neutral}</p>
        <p>huono {this.state.bad}</p>
      </div>
    )
  }
}

ReactDOM.render(<App />, document.getElementById('root'));