import React from 'react';
import ReactDOM from 'react-dom';

const Header = (props) => <div><h1>{props.course}</h1></div>

const Part = (props) => <div><p>{props.part} {props.exercises}</p></div>

const Contents = (props) => {
  return (
    <div>
      <Part part={props.part_1} exercises={props.exercise_1} />
      <Part part={props.part_2} exercises={props.exercise_2} />
      <Part part={props.part_3} exercises={props.exercise_3} />
    </div>
  )
}
    
const Total = (props) => <div><p>Total {props.exercise_1 + props.exercise_2 + props.exercise_3} exercises</p></div>
  
const App = () => {
    const course = 'Superadvanced web and mobile programming'
    const part1 = 'Basics of React'
    const exercises1 = 8
    const part2 = 'Using props'
    const exercises2 = 10
    const part3 = 'Component states'
    const exercises3 = 12
    return (
      <div>
        <Header course={course} />
        <Contents part_1={part1} part_2={part2} part_3={part3} 
                  exercise_1={exercises1} exercise_2={exercises2} exercise_3={exercises3} />
        <Total exercise_1={exercises1} exercise_2={exercises2} exercise_3={exercises3} />
      </div >
    )
}

ReactDOM.render(<App />, document.getElementById('root'));
