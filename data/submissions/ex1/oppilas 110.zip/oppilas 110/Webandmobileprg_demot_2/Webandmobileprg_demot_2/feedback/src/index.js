﻿import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component{
  constructor(props) {
    super(props)
    this.state = {
      palaute: [{name: "hyvapalaute", counter: 0},
                {name: "neutraalipalaute", counter: 0},
                {name: "huonopalaute", counter: 0}]
    }
  }

asetaArvoon = (kohta) => {
    let palautekopio = [...this.state.palaute]
    let palauteyksilo = {...palautekopio[kohta]}
    palauteyksilo.counter +=1
    palautekopio[kohta] = palauteyksilo
    console.log(palauteyksilo.counter)
    console.log(palautekopio)
    this.setState({palaute: palautekopio})
    }

 render() {
 const Header = (props) => {
  return (
    <div>
      <p style = {{fontSize: 40}}><b>{props.name}</b></p>
    </div>
  )
}
const Statistic = (props) => {
    return(
    <tr>
    <td>{props.text}</td><td>{props.value+props.prosentti}</td>
    </tr>

)
}
const Statistics = (props) =>{
    if(props.palautus1 != 0 || props.palautus2 != 0 || props.palautus3 != 0){
    return (
    <React.Fragment>
    <table>
    <tbody>
    <Statistic text = "hyvä: " value = {props.palautus1} prosentti =""/>
    <Statistic text = "neutraali: "value = {props.palautus2} prosentti =""/> 
    <Statistic text = "huono: " value = {props.palautus3} prosentti =""/>
    <Statistic text = "keskiarvo: " value = {((props.palautus1-props.palautus3)/(props.palautus1+props.palautus2+props.palautus3)).toFixed(1)} prosentti = ""/>
    <Statistic text = "positiivisia: " value = {((props.palautus1)/(props.palautus1+props.palautus2+props.palautus3)*100).toFixed(1)} prosentti = "%"/>
    </tbody>
    </table>
    </React.Fragment>
)}
    return(
    <div>
    <p>Palautetta ei ole annettu</p>
    </div>
)
}


const Button = (props) => {
    return(
    <button onClick={Addtofeedback(parseInt(props.type))}>
        {props.name}
    </button>
    )
}

const Addtofeedback = (kohta) =>{
    const buttonhandler = () =>{
        this.asetaArvoon(kohta)
        console.log(this.state.palaute)
    }
    
    return buttonhandler
}
    return (
    <div>
    <Header name = "Anna palautetta"/>

    <Button name = "positiivinen" type = "0"/>

    <Button name = "neutraali" type = "1"/>

    <Button name = "negatiivinen" type = "2"/>

    <Header name = "statistiikka"/>

    <Statistics palautus1 = {this.state.palaute[0].counter} palautus2 = {this.state.palaute[1].counter} palautus3 = {this.state.palaute[2].counter}/>

    </div>
    )
  } 
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)