import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {
  const course = {
  name: 'Superadvanced web and mobile programming',
  parts: [
    {
      name: 'Basics of React',
      exercises: 8
    },
    {
      name: 'Using props',
      exercises: 10
    },
    {
      name: 'Component states',
      exercises: 12
    }
  ]
}
const Header = (props) => {
  return (
    <div>
      <p>{props.course.name}</p>
    </div>
  )
}

const Contents = (p) =>{
  return (
    <div>
      <Part part = {p.content.parts[0].name}/>
      <Part part = {p.content.parts[1].name}/>
      <Part part = {p.content.parts[2].name}/>
    </div>
  )
}
const Part = (content) =>{
  return (
    <div>
      <p>{content.part}</p>
    </div>
  )
}

const Total = (props) => {
  return (
    <div>
      <p>{props.exercises.parts[0].exercises+props.exercises.parts[1].exercises+props.exercises.parts[2].exercises}</p>
    </div>
  )
}

  return (
    <div>
      <Header course ={course} />
      <Contents content = {course}/>
      <Total exercises = {course}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
