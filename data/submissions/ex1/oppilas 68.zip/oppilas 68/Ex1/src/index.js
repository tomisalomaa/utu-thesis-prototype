import React from 'react'
import ReactDOM from 'react-dom'
import { Button } from "./button"
import './table.css'
//import './index.css'

/*Author @Jatorn exercise 1.6-1.10 */
class FeedbackApp extends React.Component  {
  constructor(props){
    super(props)
    this.state = {
      goodCounter: 0,
      neutCounter: 0,
      poorCounter: 0,
      total: 0,
      average: 0,
      positives: 0
    }
    this.raiseGood = this.raiseGood.bind(this)
    this.raiseNeut = this.raiseNeut.bind(this)
    this.raisePoor = this.raisePoor.bind(this)
  }
  raiseGood = () => {
    this.setState({ 
      goodCounter: this.state.goodCounter + 1,
      total: this.state.total + 1
    })
  }
  raiseNeut = () =>{
    this.setState({ 
      neutCounter: this.state.neutCounter + 1,
      total: this.state.total + 1
    })
  }
  raisePoor = () =>{
    this.setState({
      poorCounter: this.state.poorCounter + 1,
      total: this.state.total + 1
    })
  }
  average = () =>{
    this.setState({average: ((this.state.goodCounter + (this.state.poorCounter * -1)) / this.state.total).toFixed(1)})
  }
  positives = () =>{
    this.setState({positives: ((this.state.goodCounter / this.state.total) * 100).toFixed(1)})
  }

  render() {
    console.log(this.state.total)
    let StatState;
    if(this.state.total === 0){
      StatState = <h1>No inputs yet</h1>
    } else {
      StatState = 
      <div>
        <h1>Statistics</h1>
        <table>
          <tbody>
          <tr>
            <td>Good</td>
            <td>Neutral</td>
            <td>Poor</td>
            <td>Average</td>
            <td>Positives</td>
          </tr>
          <tr>
            <td>{this.state.goodCounter}</td>
            <td>{this.state.neutCounter}</td>
            <td>{this.state.poorCounter}</td>
            <td>{this.state.average}</td>
            <td>{this.state.positives} %</td>
          </tr>
          </tbody>
        </table>
        </div>
    }

    return(
      <div>
        <h1>Feedback Exercise</h1>
        <div>
          <Button clickHandler={this.raiseGood} label="Good" />
          <Button clickHandler={this.raiseNeut} label="Neutral"/>
          <Button clickHandler={this.raisePoor} label="Poor"/>
          <p><Button clickHandler={this.average} label="Get Average"/>
          <Button clickHandler={this.positives} label="Get Positive%"/></p>
        </div>
        {StatState}
      </div>
    )
  }
}


ReactDOM.render(
  <FeedbackApp />,
  document.getElementById('root')
)