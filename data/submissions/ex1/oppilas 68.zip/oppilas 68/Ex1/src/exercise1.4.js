import React from 'react'
import ReactDOM from 'react-dom'

/*Author @Jatorn exercise 1.4*/
const App = () => {
  const course = 'Superadvanced web and mobile programming'
  let parts = [
    {
      name: 'Basics of React',
      exercises : 8
    },
    {
      name: 'Using props',
      exercises : 10
    },
    {
      name: 'Component states',
      exercises : 12
    }
  ]
  const Header = () => {
    return(
      <h1>{course}</h1>
    )
  }

  const Contents = () => {
    return(
      <div>
      <Part name={parts[0].name} exercises={parts[0].exercises} />
      <Part name={parts[1].name} exercises={parts[1].exercises}/>
      <Part name={parts[2].name} exercises={parts[2].exercises}/>
      </div>
    )
  }
  const Total = () => {
    return(
      <p>Total {parts[0].exercises + parts[1].exercises + parts[2].exercises} exercises</p>
    )
  }
  const Part = (part) => {
    return(
    <p>{part.name} Exercises: {part.exercises}</p>
    )
  }

  return (
    <div>
      <Header course={course} />
      <Contents parts={parts}/>
      <Total parts={parts}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)
