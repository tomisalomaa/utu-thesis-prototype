import React from 'react'
import ReactDOM from 'react-dom'

/*Author @Jatorn exercise 1.5 */
const App = () => {
  const course = {
  name : 'Superadvanced web and mobile programming',
  parts : [
    {
      name: 'Basics of React',
      exercises : 8
    },
    {
      name: 'Using props',
      exercises : 10
    },
    {
      name: 'Component states',
      exercises : 12
    }
  ]
}
  const Header = () => {
    return(
      <h1>{course.name}</h1>
    )
  }
  const Contents = () => {
    return(
      <div>
      <Part name={course.parts[0].name} exercises={course.parts[0].exercises} />
      <Part name={course.parts[1].name} exercises={course.parts[1].exercises}/>
      <Part name={course.parts[2].name} exercises={course.parts[2].exercises}/>
      </div>
    )
  }
  const Total = () => {
    return(
      <p>Total {course.parts[0].exercises + course.parts[1].exercises + course.parts[2].exercises} exercises</p>
    )
  }
  const Part = (part) => {
    return(
    <p>{part.name} Exercises: {part.exercises}</p>
    )
  }

  return (
    <div>
      <Header course={course.name} />
      <Contents parts={course.parts}/>
      <Total parts={course.parts}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)