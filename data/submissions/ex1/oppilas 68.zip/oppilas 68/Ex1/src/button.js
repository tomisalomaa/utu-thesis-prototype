import React from "react";

export const Button = ({clickHandler, label}) => {
    return(
    <button onClick={clickHandler}>
      {label}
    </button>
    )
  }