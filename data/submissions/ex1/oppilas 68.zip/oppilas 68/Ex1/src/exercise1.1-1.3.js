import React from 'react'
import ReactDOM from 'react-dom'

/*Author @Jatorn exercises 1.1-1.3*/
const App = () => {
  const course = 'Superadvanced web and mobile programming'
  const part1 = {
    name: 'Basics of React',
    exercises: 8
  }
  const part2 = {
    name: 'Using props',
    exercises: 10
  }
  const part3 = {
    name: 'Component states',
    exercises: 12
  }
  const Header = () => {
    return(
      <h1>{course}</h1>
    )
  }
  const Contents = () => {
    return(
      <div>
      <Part name={part1.name} exercises={part1.exercises}/>
      <Part name={part2.name} exercises={part2.exercises}/>
      <Part name={part3.name} exercises={part3.exercises}/>
      </div>
    )
  }
  const Total = (total) => {
    return(
      <p>Total {total.total} exercises</p>
    )
  }
  const Part = (part) => {
    return(
    <p>{part.name} Exercises: {part.exercises}</p>
    )
  }

  return (
    <div>
      <Header course={course} />
      <Contents />
      <Total total={part1.exercises + part2.exercises + part3.exercises}/>
    </div>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)