import React from 'react'
import ReactDOM from 'react-dom'


const Header = () => {


  return (
    <div>
      <h1>Happy Hannukka or no</h1>     
    </div>
  )
}



  
const Statavg = (props) => {
  if (props.any === 0){
    return (
      <div>
        <p></p>
      </div>
    )
  }
  var keskiarvo = (props.good+(props.neut*0)+(props.bad*-1))/(props.good+props.bad+props.neut)
  return (
    <div>
      <p>keskiarvo {keskiarvo}</p>  
    </div>
  )
}

const Statpos = (props) => {
  if (props.any === 0){
    return (
      <div>
        <p></p>
      </div>
    )
  }
  var posi = props.good/(props.good+props.neut+props.bad)*100
  return (
    <div>     
      <p>positiivisia {posi}%</p>
    </div>
  )
}

const Buttons = (props) => {
  
  return (
    <div>
      <button onClick={props.good}>good</button>    
      <button onClick={props.bad}>neut</button> 
      <button onClick={props.neut}>bad</button> 
    </div>
  )
}

const Statistics = (props) => {
  if (props.any === 0){
    return (
      <div>
        <p>Empty</p>
      </div>
    )
  }
  return (
    <div>
      <p>good {props.good}</p>
      <p>neut {props.neut}</p>
      <p>bad {props.bad}</p>
    </div>
  )
}




class App extends React.Component{
  constructor() {
    super()
    this.state = {
      good: 0,
      neut: 0,
      bad: 0,
      any: 0
    }
  }
  addgood = () => {
    this.setState({
      good: this.state.good+1,
      any: 1
    })
  }

  addneut = () => {
    this.setState({
      neut: this.state.neut+1,
      any: 1
    })
  }

  addbad = () => {
    this.setState({
      bad: this.state.bad+1,
      any: 1
    })
  }

  render() {
    return (
      <div>        
          <Header />   
          <Buttons good={this.addgood} neut={this.addneut} bad={this.addbad} any={this.state.any}/>
          <h2>Statistiikka</h2>       
          <Statistics good={this.state.good} neut={this.state.neut} bad={this.state.bad} any={this.state.any}/>
          <Statavg good={this.state.good} neut={this.state.neut} bad={this.state.bad} any={this.state.any}/> 
          <Statpos good={this.state.good} neut={this.state.neut} bad={this.state.bad} any={this.state.any}/>  
      </div>
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)