import React from 'react';
import ReactDOM from 'react-dom';

const Header1 = () => {
  return (
    <div>
      <h1>anna palautetta</h1>
    </div>
  )
}

const Header2 = () => {
  return (
    <div>
      <h1>statistiikka</h1>
    </div>
  )
}

const NoStats = () => {
  return (
    <div>
      <p>ei yhtään palautetta annettu</p>
    </div>
  )
}

const Button = (props) => {
  return (
    <div>
      <button onClick={props.value1}>hyvä</button>
      <button onClick={props.value2}>neutraali</button>
      <button onClick={props.value3}>huono</button>
    </div>
  )
}

const Statistic = (props) => {
  return (
    <div>
      <p>{props.name} {props.value}</p>
    </div>
  )
}

const Statistics = (props) => {
  return (
    <table>
      <tr>
        <td><Statistic name ={'hyvä'} /> </td>
        <td><Statistic value = {props.value1} /></td>
      </tr>
      <tr>
        <td><Statistic name ={'neutraali'} /> </td>
        <td><Statistic value = {props.value2} /></td>
      </tr>
      <tr>
        <td><Statistic name ={'huono'} /> </td>
        <td><Statistic value = {props.value3} /></td>
      </tr>
      <tr>
        <td><Statistic name ={'keskiarvo'} /> </td>
        <td><Statistic value = {props.value4} /></td>
      </tr>
      <tr>
        <td><Statistic name ={'positiivisia'} /> </td>
        <td><Statistic value = {`${props.value5}%`} /></td>
      </tr>
    </table>
  )
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      huono: 0
    }
  }

  klikHyva = () => {
    this.setState({
      hyva: this.state.hyva + 1
    })
  }

  klikNeutraali = () => {
    this.setState({
      neutraali: this.state.neutraali + 1
    })
  }

  klikHuono = () => {
    this.setState({
      huono: this.state.huono + 1
    })
  }

  render() {
    if (this.state.hyva === 0 && this.state.neutraali === 0 && this.state.huono === 0) {
    return (
      <div>
        <div>
          <Header1 />
          <Button value1 = {this.klikHyva} value2 = {this.klikNeutraali} value3 = {this.klikHuono}/>
          <Header2 />
          <NoStats />
        </div>
      </div>
    ) }
    return (
      <div>
      <div>
        <Header1 />
        <Button value1 = {this.klikHyva} value2 = {this.klikNeutraali} value3 = {this.klikHuono}/>
        <Header2 />
        <Statistics value1 = {this.state.hyva} value2 = {this.state.neutraali} value3 = {this.state.huono} 
        value4 = {(this.state.hyva-this.state.huono)/(this.state.huono+this.state.neutraali+this.state.hyva)} value5 = {this.state.hyva/(this.state.huono+this.state.neutraali+this.state.hyva)*100} />
      </div>
    </div>
    )
 
  }

}

ReactDOM.render(
  <App />,
  document.getElementById('root')
)