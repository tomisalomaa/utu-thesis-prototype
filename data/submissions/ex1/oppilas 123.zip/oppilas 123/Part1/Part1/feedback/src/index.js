import React from 'react'
import ReactDOM from 'react-dom'

class App extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      hyva: 0,
      neutraali: 0,
      kehno:0
    }
    this.hyvaPalaute=this.hyvaPalaute.bind(this)
    this.neutriPalaute=this.neutriPalaute.bind(this)
    this.huonoPalaute=this.huonoPalaute.bind(this)
  }

  hyvaPalaute(){
    this.setState({hyva:this.state.hyva+1})
  }

  neutriPalaute(){
    this.setState({neutraali:this.state.neutraali+1})
  }
  
  huonoPalaute(){
    this.setState({kehno:this.state.kehno+1})
  }

  render() {

    return (
      <div>
      <h2>Anna palautetta:</h2>
      <Button name="Hyvä" action={this.hyvaPalaute} style = {{color:'green'}}/>
      <Button name="Neutraali" action={this.neutriPalaute} style = {{color:'blue'}}/>
      <Button name="Huono" action={this.huonoPalaute} style = {{color:'red'}}/>
      <h2>Statistiikka:</h2>
      <Results hyva={this.state.hyva} neutraali={this.state.neutraali} kehno={this.state.kehno}/>
      </div>
    )
  }
}

class Button extends React.Component {
  render() {
    return (
      <button onClick={this.props.action}>{this.props.name}</button>
    )
  }
}
class Results extends React.Component {
  constructor(props){
    super(props)
    this.state={average:(this.props.hyva-this.props.kehno)/(this.props.hyva+this.props.neutraali+this.props.kehno)}
  }

  render() {
    let avg=(this.props.hyva-this.props.kehno)/(this.props.hyva+this.props.neutraali+this.props.kehno)
    let pos=Math.floor((this.props.hyva*1000)/(this.props.hyva+this.props.neutraali+this.props.kehno))/10 +" %"
    let v=this.props.hyva+this.props.neutraali+this.props.kehno===0
    if(v){
      return(
        <div>
          Ei yhtään palautetta annettu.
        </div>
      )
    }
    return (
      <table>
      <tbody>
      <Statistic type="hyvä" value={this.props.hyva}/>
      <Statistic type="neutraali" value={this.props.neutraali}/>
      <Statistic type="huono" value={this.props.kehno}/>
      <Statistic type="keskiarvo" value={avg}/>
      <Statistic type="positiivista" value={pos}/>
      </tbody>
      </table>
    )
  }
}
class Statistic  extends React.Component {
  render(){
  return (
    <tr><td>{this.props.type}</td>
    <td>{this.props.value}</td></tr>

  )}
}
ReactDOM.render(
  <App />,
  document.getElementById('root')
)
