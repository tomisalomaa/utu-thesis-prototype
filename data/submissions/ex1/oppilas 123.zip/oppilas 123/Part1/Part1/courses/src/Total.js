import React, { Component } from "react";

class Total extends Component {

  constructor() {
    super();
    this.state = {
      name: "React",
    };
  }

  render() {

    const { parts } = this.props;
    const numRows = parts.reduce((partialSum, a) => partialSum + a.excercises, 0);

    return (
      <div>
        <p>Total of excercises in all course parts: {numRows}</p>
      </div>
    );

  }

}

export default Total
