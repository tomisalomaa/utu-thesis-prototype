import React, { Component } from "react";
import { render } from "react-dom";
import Header from '/Users/loviisamaenpaa/WebAndMobileProgramming/courses/src/Header.js';
import Contents from '/Users/loviisamaenpaa/WebAndMobileProgramming/courses/src/Contents.js';
import Total from '/Users/loviisamaenpaa/WebAndMobileProgramming/courses/src/Total.js';

class App extends Component {

  constructor() {
    super();
    this.state = {
      headers: [
        {
          otsikko: 'Superadvanced web and mobile programming'
        }
      ],
      parts: [
        {
          excercises: 8,
          name: "Basics of React"
        },
        {
          excercises: 10,
          name: "Using props"
        },
        {
          excercises: 12,
          name: "Component states"
        }
      ]
    };
  }

  render() {
    return (
      <div>
        <Header
          headers={this.state.headers}
        />
        <Contents
          parts={this.state.parts}
        />
        <Total
          parts={this.state.parts}
        />
      </div>
    );
  }
}

render(<App />, document.getElementById("root"));
