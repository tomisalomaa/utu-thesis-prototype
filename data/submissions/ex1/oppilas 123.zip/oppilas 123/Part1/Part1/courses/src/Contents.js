import React, { Component } from "react";

class Contents extends Component {

  constructor() {
    super();
    this.state = {
      name: "React",
    };
  }

  render() {

    const { parts } = this.props;
    const numRows = parts.length

    for (const element of parts) {
      console.log(element);
    }

    const pr = parts.map(part => `Course "${part.name}" has ${part.excercises} excercises.                              `)

    return (
      <div>
      {pr}
      </div>
    );

  }

}

export default Contents
