import React from 'react'
import ReactDOM from 'react-dom'


const Display = ({ text, stat }) => <div>{text} {stat}</div>

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyvaCounter: 0,
      neutraaliCounter: 0,
      huonoCounter: 0
    }
  }

  clickHyva = () => {
    this.setState({ hyvaCounter: this.state.hyvaCounter + 1 })
  }

  clickNeutraali = () => {
    this.setState({ neutraaliCounter: this.state.neutraaliCounter + 1 })
  }

  clickHuono = () => {
    this.setState({ huonoCounter: this.state.huonoCounter + 1 })
  }

  countAverage() {
    const allCounter = this.state.hyvaCounter + this.state.neutraaliCounter + this.state.huonoCounter
    const average = Math.round(((this.state.hyvaCounter - this.state.huonoCounter) / (allCounter))*10) / 10
    if (allCounter !== 0) {
      return average
    }
    return 0
  }

  countPositivePercentage() {
    const allCounter = this.state.hyvaCounter + this.state.neutraaliCounter + this.state.huonoCounter
    const percentage = Math.round(100*(this.state.hyvaCounter / (allCounter))*10) / 10
    if (allCounter !== 0) {
      return percentage + ' %'
    }
    return 0 + ' %'
  }

  render() {
    return (
      <div>
        <h1>Anna palautetta</h1>
        <div>
          <Button 
            handleClick={this.clickHyva}
            text="Hyvä"
          />
          <Button 
            handleClick={this.clickNeutraali}
            text="Neutraali"
          />
          <Button 
            handleClick={this.clickHuono}
            text="Huono"
          />
        </div>
        <h1>Statistiikka</h1>
        <Display text="hyvä" stat={this.state.hyvaCounter}/>
        <Display text="neutraali" stat={this.state.neutraaliCounter}/>
        <Display text="huono" stat={this.state.huonoCounter}/>
        <Display text="keskiarvo" stat={this.countAverage()}/>
        <Display text="positiivisia" stat={this.countPositivePercentage()}/>
      </div>
    )
  }
}


ReactDOM.render(<App />, document.getElementById('root'))