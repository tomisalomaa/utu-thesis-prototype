import React from 'react'
import ReactDOM from 'react-dom'


const Display = ({ text, counter }) => <div>{text} {counter}</div>

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyvaCounter: 0,
      neutraaliCounter: 0,
      huonoCounter: 0
    }
  }

  clickHyva = () => {
    this.setState({ hyvaCounter: this.state.hyvaCounter + 1 })
  }

  clickNeutraali = () => {
    this.setState({ neutraaliCounter: this.state.neutraaliCounter + 1 })
  }

  clickHuono = () => {
    this.setState({ huonoCounter: this.state.huonoCounter + 1 })
  }

  render() {
    return (
      <div>
        <h1>Anna palautetta</h1>
        <div>
          <Button 
            handleClick={this.clickHyva}
            text="Hyvä"
          />
          <Button 
            handleClick={this.clickNeutraali}
            text="Neutraali"
          />
          <Button 
            handleClick={this.clickHuono}
            text="Huono"
          />
        </div>
        <h1>Statistiikka</h1>
        <Display text="Hyvä" counter={this.state.hyvaCounter}/>
        <Display text="Neutraali" counter={this.state.neutraaliCounter}/>
        <Display text="Huono" counter={this.state.huonoCounter}/>
      </div>
    )
  }
}


ReactDOM.render(<App />, document.getElementById('root'))