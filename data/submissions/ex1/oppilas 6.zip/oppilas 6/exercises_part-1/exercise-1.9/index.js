import React from 'react'
import ReactDOM from 'react-dom'


function countAverage(hyvaCounter, huonoCounter, allCounter) {
  const average = Math.round(((hyvaCounter - huonoCounter) / (allCounter))*10) / 10
  if (allCounter !== 0) {
    return average
  }
  return 0;
}

function countPositivePercentage(hyvaCounter, allCounter) {
  const percentage = Math.round(100*(hyvaCounter / (allCounter))*10) / 10
  if (allCounter !== 0) {
    return percentage + ' %'
  }
  return 0 + ' %'
}

const Statistics = (props) => {
  if (props.stats.allCounter === 0) {
    return (
      <div>
        <p>ei yhtään palautetta annettu</p>
      </div>
    )
  }
  return (
    <div>
      <Statistic text="hyvä" stat={props.stats.hyvaCounter}/>
      <Statistic text="neutraali" stat={props.stats.neutraaliCounter}/>
      <Statistic text="huono" stat={props.stats.huonoCounter}/>
      <Statistic text="keskiarvo" stat={countAverage(props.stats.hyvaCounter, props.stats.huonoCounter, props.stats.allCounter)}/>
      <Statistic text="positiivisia" stat={countPositivePercentage(props.stats.hyvaCounter, props.stats.allCounter)}/>
    </div>
  )
}

const Statistic = (props) => {
  return (
    <div>
      <p>{props.text} {props.stat}</p>
    </div>
  )
}

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)

class App extends React.Component {
  constructor() {
    super()
    this.state = {
      hyvaCounter: 0,
      neutraaliCounter: 0,
      huonoCounter: 0,
      allCounter: 0
    }
  }

  clickHyva = () => {
    this.setState({ hyvaCounter: this.state.hyvaCounter + 1 })
    this.setState({ allCounter: this.state.allCounter + 1 })
  }

  clickNeutraali = () => {
    this.setState({ neutraaliCounter: this.state.neutraaliCounter + 1 })
    this.setState({ allCounter: this.state.allCounter + 1 })
  }

  clickHuono = () => {
    this.setState({ huonoCounter: this.state.huonoCounter + 1 })
    this.setState({ allCounter: this.state.allCounter + 1 })
  }

  render() {
    return (
      <div>
        <h1>Anna palautetta</h1>
        <div>
          <Button 
            handleClick={this.clickHyva}
            text="Hyvä"
          />
          <Button 
            handleClick={this.clickNeutraali}
            text="Neutraali"
          />
          <Button 
            handleClick={this.clickHuono}
            text="Huono"
          />
        </div>
        <h1>Statistiikka</h1>
        <Statistics stats={this.state}/>
      </div>
    )
  }
}


ReactDOM.render(<App />, document.getElementById('root'))