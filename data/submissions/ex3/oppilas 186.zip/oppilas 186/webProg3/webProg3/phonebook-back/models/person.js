const mongoose = require('mongoose')

const url = 'mongodb+srv://sebu-user:pazwrd123@cluster0.7g4f6.mongodb.net/fullstack-persons'

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String,
    id: Number
})

module.exports = Person