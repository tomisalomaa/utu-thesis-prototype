const { response } = require('express')
const mongoose = require('mongoose')

const url = 'mongodb+srv://sebu-user:pazwrd123@cluster0.7g4f6.mongodb.net/fullstack-persons'
const args = process.argv.slice(2)

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String,

})

if (args.length >= 2) {
    const person = new Person({
        name: args[0],
        number: args[1]
    })
    person
        .save()
        .then(response => {
            console.log(`adding person ${args[0]} number ${args[1]} to the directory`)
            mongoose.connection.close()
        })
} else {
    console.log("puhelinluettelo:")
    Person
        .find({})
        .then(persons => {
            persons.forEach(p => {
                console.log(p.name, p.number)
            })
            mongoose.connection.close()
        })
}



