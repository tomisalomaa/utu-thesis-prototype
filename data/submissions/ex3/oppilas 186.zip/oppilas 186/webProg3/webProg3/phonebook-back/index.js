
const { response } = require('express')
const express = require('express')
const cors = require('cors')
const Person = require("./models/person")
const bodyParser = require('body-parser')
const app = express()


//Middleware
const logger = (req, res, next) => {
    console.log("Method:", req.method)
    console.log("Path:", req.path)
    console.log("Body:", req.body)
    console.log("---")
    next()
}


app.use(cors())
app.use(express.static('build'))
app.use(logger)
app.use(bodyParser.json())


//Requests
app.post('/api/persons/', (req, res) => {
    const entry = req.body
    
    if (entry.name === undefined) {
        return res.status(400).json({error: "name missing"})
    } else if (entry.number === undefined) {
        return res.status(400).json({error: "number missing"})
    }

    const person = new Person({
        name: entry.name,
        number: entry.number,
        id: 1
    })
    person
        .save()
        .then(saved => {
            res.json(saved)
        })
})
const format = (person) => {
    const formatted = {...person._doc, id: person._id}
    delete formatted._id
    delete formatted.__v

    return formatted
}
app.get('/api/persons/', (req, res) => {
    Person
        .find({})
        .then(persons=> {
            res.json(persons.map(format))
        })
})

app.get('/api/persons/:id', (req, res) => {
    Person
        .findById(req.params.id)
        .then(person => {
            if (person) {
                res.json(format(person))
            } else {
                response.status(404).end()
            }
        })
        .catch(error => {
            response.status(400).send({error: "malformed id"})
        })
})

app.delete('/api/persons/:id', (req, res) => {
    Person
        .findByIdAndRemove(req.params.id)
        .then(result => {
        res.status(204).end()
        })
        .catch(error => {
        res.status(400).send({ error: 'malformatted id' })
        })
})

//Unhandled error
const error = (request, response) => {
    response.status(404).send({error: 'unknown endpoint'})
}
app.use(error)

//Port
const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
})