import React from 'react';
import Entry from './components/Entry';
import Form from './components/Form';
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/api/persons')
      .then(response => {
        this.setState({persons: response.data})
      })
  }

  handleNameChange = (event) => {
    this.setState({newName: event.target.value})
  }
  handleNumberChange = (event) => {
    this.setState({newNumber: event.target.value})
  }
  deleteEntryAt = (id, name) => {
    return () => {
      if (window.confirm(`poistetaanko ${name}`)) {
        axios
          .delete(`http://localhost:3001/api/persons/${id}`)
          .then(response => {
            console.log(response)
          })
        const persons = this.state.persons.filter(p => p.name !== name)
        this.setState({persons})
      }
    }
  }
  handleSubmit = (event) => {
    event.preventDefault()
    const maxId = this.state.persons.length > 0 ? this.state.persons.map(p => p.id).sort((a, b) => a-b).reverse()[0] : 1
    const newId = maxId + 1
    const addedEntry = {name: this.state.newName, number: this.state.newNumber, id: newId}
    if (!this.state.persons.some(p => p.name === this.state.newName)) {
      axios
        .post('http://localhost:3001/api/persons', addedEntry)
        .then(response => {
          console.log(response)
          if (response.status === 200) {
            console.log(response.status)
            const persons = this.state.persons.concat(addedEntry)
            this.setState({persons, newName: '', newNumber: ''})
          }
        })
    } 
  }

  render() {
    const numerot = () => this.state.persons.map((p, i) => <Entry key={p.id} name={p.name} number={p.number} handle={this.deleteEntryAt(p.id, p.name)}/>)
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form nameVal={this.state.newName} numberVal={this.state.newNumber} 
          onNameChng={this.handleNameChange} onNumChng={this.handleNumberChange} 
          onSbmt={this.handleSubmit}/>
        <h2>Numerot</h2>
        {numerot()}

      </div>
    )
  }
}

export default App
