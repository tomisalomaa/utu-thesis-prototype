const mongoose = require('mongoose')

const url = 'mongodb+srv://phonebook:Phonebook-front-back@phonebook.qccuy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String,
    id: Number
})

if(process.argv[2] === undefined){
    console.log("Puhelinluettelo:")
    Person
    .find({})
    .then(result => {
        result.forEach(person => {
            console.log(`${person.name} ${person.number}`)
        })
        mongoose.connection.close()
    })
}
else{
    const person = new Person ({
        name: process.argv[2],
        number: process.argv[3]
    })

    person
    .save()
    .then(res => {
        console.log(`adding person ${process.argv[2]} number ${process.argv[3]} to the directory`)
        mongoose.connection.close()
    })
}