const mongoose = require('mongoose')

const url = 'mongodb+srv://phonebook:Phonebook-front-back@phonebook.qccuy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String
})

module.exports = Person