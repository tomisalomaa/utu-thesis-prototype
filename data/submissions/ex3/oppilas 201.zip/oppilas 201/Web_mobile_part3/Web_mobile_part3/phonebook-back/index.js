const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')

app.use(cors())
app.use(bodyParser.json())
app.use(express.static('build'))

const Person = require('./models/person')
const { format } = require('express/lib/response')

const formatPerson = (person) => {
  return {
    name: person.name,
    number: person.number,
    id: person._id
  }
}

function uusiId(min, max) {
  min = Math.ceil(min)
  max = Math.floor(max)
  return Math.floor(Math.random() * (max - min + 1)) + min
}

app.get('/api/persons',(req,res) => {
  Person
    .find({}, {__v: 0})
    .then(persons => {
      res.json(persons.map(formatPerson))
        })
})

app.get('/api/persons/:id', (req, res) => {
  Person
    .findById(req.params.id)
    .then(person => {
      if(person){
        res.json(formatPerson(person))
      } else {
        res.status(404).end()
      } 
    })
    .catch(error => {
      console.log(error)
      res.status(400).send({error: 'malformatted id'})
    })
})

app.delete('/api/persons/:id', (request, response) => {
  Person
    .findByIdAndRemove(request.params.id)
    .then(result => {
      response.status(204).end()
    })
    .catch(error => {
      response.status(400).send({error: 'malformatted id'})
    })
})

app.post('/api/persons', (request,response) => {
  const body = request.body

  if (body.name === undefined || body.number === undefined) {
    console.log(body.name)
    return response.status(400).json({error: 'name or number is missing from the request'})
  }

  const person = new Person({
    name: body.name,
    number: body.number,
    id: uusiId(0,100000)
  })

  person
    .save()
    .then(savedPerson => {
      response.json(formatPerson(savedPerson))
    })
})


const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})