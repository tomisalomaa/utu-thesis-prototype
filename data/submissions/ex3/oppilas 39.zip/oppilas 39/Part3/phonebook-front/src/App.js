import React from 'react';
import Person from './components/Person';

class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
        persons: [
            {   name: 'Arto Hellas',
                number: '0401234567',
                id: 1,
                important: true
            }
        ],
        newName: '',
        newNumber: '',
        showAll: true
        }
    }
    addPerson = (event) => {
        if (this.state.persons.some(elem => elem.name === this.state.newName)){
            event.preventDefault()
            alert('nimi on jo listassa')
        }else if (this.state.persons.some(elem => elem.number === this.state.newNumber)){
            event.preventDefault()
            alert('numero on jo listassa')
        } else {
            event.preventDefault()
            const nameObject = {
                name: this.state.newName,
                number: this.state.newNumber,
                id: this.state.persons.length + 1,
                important: true
            }
            const persons = this.state.persons.concat(nameObject)
            this.setState({
                persons: persons,
                newName: '',
                newNumber: ''
            })
        }
    }


    handleNameChange = (event) => {
        console.log(event.target.value)
        this.setState({ newName: event.target.value })
    }
    handleNumberChange = (event) => {
        console.log(event.target.value)
        this.setState({ newNumber: event.target.value })
    }

    render() {
        const namesToShow =
        this.state.showAll ?
        this.state.persons :
        this.state.persons.filter(name => name.important === true)

        return (
        <div>
            <h2>Puhelinluettelo</h2>
            <form onSubmit={this.addPerson}>
            <div>
                nimi: <input value={this.state.newName} onChange={this.handleNameChange}/>
            </div>
            <div>
                numero: <input value={this.state.newNumber} onChange={this.handleNumberChange}/>
            </div>
            <div>
                <button type="submit">lisää</button>
            </div>
            </form>
            <h2>Nimet ja Numerot</h2>
            <ul>
                {namesToShow.map(person => <Person key={person.id} person={person} />)}
            </ul>
        </div>
      
        )
    }
}
export default App