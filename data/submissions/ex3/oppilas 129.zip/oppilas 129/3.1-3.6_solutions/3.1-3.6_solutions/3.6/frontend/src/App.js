import React from 'react';
import Person from './Person';

class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			persons: [{ name: 'Arto Hellas', number: '040-123456' }],
			newName: '',
			newNumber: '',
		};

		this.connectBackEnd();
	}

	connectBackEnd() {
		fetch('http://localhost:3001')
			.then((res) => res.text())
			.then((res) => this.setState({ newName: res }));
	}

	addPerson = (event) => {
		event.preventDefault();
		let isExisted = false;
		for (let i = 0; i < this.state.persons.length; i++) {
			if (this.state.persons[i].name === this.state.newName) {
				alert(this.state.newName + ' on jo olemassa.');
				isExisted = true;
				return;
			}
		}

		if (!isExisted) {
			const newPerson = {
				name: this.state.newName,
				number: this.state.newNumber,
			};
			const persons = this.state.persons.concat(newPerson);

			this.setState({
				persons,
				newName: '',
				newNumber: '',
			});
		}
	};

	handleNameChange = (event) => {
		this.setState({ newName: event.target.value });
	};

	handleNumberChange = (event) => {
		this.setState({ newNumber: event.target.value });
	};

	render() {
		return (
			<div>
				<h2>Puhelinluettelo</h2>
				<form onSubmit={this.addPerson}>
					<div>
						nimi:{' '}
						<input
							value={this.state.newName}
							onChange={this.handleNameChange}
						/>
					</div>
					<div>
						numero:{' '}
						<input
							value={this.state.newNumber}
							onChange={this.handleNumberChange}
						/>
					</div>
					<div>
						<button type="submit">lisää</button>
					</div>
				</form>
				<h2>Numerot</h2>
				{this.state.persons.map((person) => (
					<Person key={person.name} person={person} />
				))}
			</div>
		);
	}
}

export default App;
