const mongoose = require("mongoose");

const url =
  "mongodb+srv://tancetiner:TURKUCS@phonebook.c2r3x.mongodb.net/phonebook-database";

mongoose.connect(url);

const Person = mongoose.model("Person", {
  name: String,
  number: Number,
});

if (process.argv[2] && process.argv[3]) {
  const person = new Person({
    name: process.argv[2],
    number: parseInt(process.argv[3]),
  });

  person.save().then((response) => {
    console.log(
      `adding person ${process.argv[2]} number ${process.argv[3]} to the directory`
    );
    mongoose.connection.close();
  });
} else {
  Person.find({}).then((result) => {
    console.log("Number list:");
    result.forEach((person) => {
      console.log(person.name, person.number);
    });
    mongoose.connection.close();
  });
}

// if (process.argv[2]) console.log(typeof process.argv[2]);
// else console.log("no data");
// console.log(process.argv[3]);
