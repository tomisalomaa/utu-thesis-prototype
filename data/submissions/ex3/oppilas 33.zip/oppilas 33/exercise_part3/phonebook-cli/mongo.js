const mongoose = require("mongoose");
require("dotenv").config();

const URL = process.env.MONGODB_URI;

mongoose.connect(URL);

const Person = mongoose.model("Person", {
    name: String,
    number: String
});

function addperson(person) {
    person
    .save()
    .then(response => {
        console.log(`adding person ${person.name} number ${person.number} to the directory`);
        mongoose.connection.close();
    });
}

function getPersons() {
    console.log("puhelinluettelo:");
    Person
    .find({})
    .then(result => {
        result.forEach(person => {
            console.log(`${person.name} ${person.number}`);
        })
        mongoose.connection.close();
    })
    .catch(error => {
        console.log(error);
    });
}

if(process.argv.length == 2) {
    getPersons();   
} else if(process.argv.length == 4) {
    const newPerson = new Person({
        name: process.argv[2],
        number: process.argv[3]
    });
    addperson(newPerson);
} else {
    console.log("Incorrect number of arguments!");
    mongoose.connection.close();
}