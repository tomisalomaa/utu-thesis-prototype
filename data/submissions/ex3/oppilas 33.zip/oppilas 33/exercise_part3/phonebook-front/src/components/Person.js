const Person = ({name, number, onClickDelete}) => {
	return (
		<div>
			{name} {number} 
			<button onClick={onClickDelete}>
				poista
			</button>
		</div>
	)
}

export default Person;