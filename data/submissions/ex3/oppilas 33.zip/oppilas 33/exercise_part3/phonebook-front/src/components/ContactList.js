import Person from "./Person.js";

const ContactList = ({persons, onClickDelete}) => {
    return (
      <>
        <h2>Numerot</h2>
        <ul>
          {persons.map(person => 
            <Person 
              key={person.name}
              name={person.name}
              number={person.number}
              onClickDelete={onClickDelete(person.id)}
            />)
          }
        </ul>
      </>
    )
}

export default ContactList;