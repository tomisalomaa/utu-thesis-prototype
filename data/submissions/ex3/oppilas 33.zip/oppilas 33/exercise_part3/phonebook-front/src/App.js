import React from 'react';
import axios from "axios";
import ContactList from "./components/ContactList.js";
import ContactForm from "./components/ContactForm.js";

const PERSONS_URL = "/api/persons";

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ""
    }
  }

  componentDidMount() {
    axios
      .get(PERSONS_URL)
      .then(response => {
        this.setState({persons: response.data});
      });
  }

  addPerson = (event) => {
    event.preventDefault();
    if(this.state.persons.map(x => x.name).includes(this.state.newName)) { // Prevent adding same names
      window.alert("Virhe: nimi on jo luettelossa!");
      return;
    }
    axios
      .post(PERSONS_URL, {name: this.state.newName, number: this.state.newNumber})
      .then(response => {
        this.setState({
          persons: this.state.persons.concat(response.data),
          newName: "",
          newNumber: ""
        });
      });
  }

  deletePerson = (id) => {
    return () => {
      const url = `/api/persons/${id}`;
      const person = this.state.persons.find(p => p.id === id);
      if(!window.confirm(`Poistetaanko ${person.name}?`))
        return;
      axios
        .delete(url, person)
        .then(() => {
          this.setState({
            persons: this.state.persons.filter(p => p.id !== id)
          })
        });
    }
  }

	handleNameChange = (event) => {
		this.setState({newName: event.currentTarget.value});
	}

  handleNumberChange = (event) => {
    this.setState({newNumber: event.currentTarget.value});
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <ContactForm 
          addPerson={this.addPerson}
          newName={this.state.newName}
          newNumber={this.state.newNumber}
          handleNameChange={this.handleNameChange}
          handleNumberChange={this.handleNumberChange}
        />
        <ContactList 
          persons={this.state.persons}
          onClickDelete={this.deletePerson}
        />
      </div>
    )
  }
}


export default App;