const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')
const mongoose = require('mongoose')


const url = 'mongodb+srv://Troija:Asdfasdf12@webcourse.afufs.mongodb.net/phonebook'

mongoose.connect(url)

const Person = mongoose.model('persons', {
  name: String,
  number: String
  })

app.use(cors())
app.use(bodyParser.json())
app.use(express.static('build'))

let persons = [
    {
      id: 1,
      name: 'Arto Hellas1',
      number: '040-123456'
    },
    {
      id: 2,
      name: 'Arto Hellas2',
      number: '044-123456'
    },
    {
      id: 3,
      name: 'Arto Hellas3',
      number: '045-123456'
    }
  ]
  
  //app.get('/api/persons', (req, res) => {
  //  res.json(persons)
  //})

  //app.get('/api/persons/:id', (request, response) => {
  //  const id = Number(request.params.id)
  //  const person = persons.find(person => person.id === id)
  //  if ( person ) {
  //      response.json(person)
  //    } else {
  //      response.status(404).end()
  //    }
  //  })

  app.get('/api/persons', (request, response) => {
    Person.find({}).then(persons => {
        response.json(persons.map(formatPerson))
      })
      .catch(error => {
        console.log(error)
        response.status(400).send({ error: 'something went wrong' })
      })
  })

  const formatPerson = (person) => {
    return {
      name: person.name,
      number: person.number,
      id: person._id
    }
  }
  app.post('/api/persons', (request, response) => {
    const body = request.body
  
    if (body.name === undefined) {
      return response.status(400).json({error: 'name missing'})
    }
    if (body.number === undefined) {
      return response.status(400).json({error: 'number missing'})
    }
  
    const person = new Person({
      name: body.name,
      number: body.number
    })
  
    person
      .save()
      .then(savedPerson => {
        response.json(formatPerson(savedPerson))
      })
      .catch(error => {
        console.log(error)
        response.status(400).send({ error: 'something went wrong' })
      })
  })
  app.get('/api/persons/:id', (request, response) => {
    Person
      .findById(request.params.id)
      .then(person => {
        response.json(formatPerson(person))
      })
      .catch(error => {
        console.log(error)
        response.status(404).end()
      })
  })
  app.delete('/api/persons/:id', (request, response) => {
    Person
      .findByIdAndRemove(request.params.id)
      .then(result => {
        response.status(204).end()
      })
      .catch(error => {
        response.status(400).send({ error: 'malformatted id' })
      })
  })

    app.delete('/api/persons/:id', (request, response) => {
        const id = Number(request.params.id)
        persons = persons.filter(person => person.id !== id)
      
        response.status(204).end()
      })

      const generateId = () => {
        const id = Math.floor(Math.random() * 100000)
        return id
      }
      
      app.post('/api/persons', (request, response) => {
        const body = request.body

        if (body.name === undefined) {
            return response.status(400).json({error: 'name missing'})
        }
        if (body.number === undefined) {
            return response.status(400).json({error: 'number missing'})
        }
        var names = persons.map(function(person){
            return person.name
        })
        if (names.includes(body.name)){
          return response.status(400).json({error: 'name must be unique'})
        }
    
      
        const person = {
          name: body.name,
          number: body.number,
          id: generateId()
        }
      
        persons = persons.concat(person)
      
        response.json(person)
      })
  
      const PORT = process.env.PORT || 3001
      app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`)
      })