const mongoose = require('mongoose')


const url = 'mongodb+srv://Troija:Asdfasdf12@webcourse.afufs.mongodb.net/phonebook'

mongoose.connect(url)

const Person = mongoose.model('persons', {
  name: String,
  number: String
  })




module.export = Person