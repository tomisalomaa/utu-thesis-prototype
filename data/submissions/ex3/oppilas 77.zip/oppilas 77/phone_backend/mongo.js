const mongoose = require('mongoose')


const url = 'mongodb+srv://Troija:Asdfasdf12@webcourse.afufs.mongodb.net/phonebook'

mongoose.connect(url)

const Person = mongoose.model('persons', {
  name: String,
  number: String,
})

if (process.argv.length <= 2){
    Person
    .find({})
    .then(result => {
        console.log('puhelinluettelo:')
      result.forEach(person => {
        console.log(person.name + ' ' + person.number)
      })
      mongoose.connection.close()
    })
}

if(process.argv.length > 2){
const person = new Person({
  name: process.argv[2],
  number: process.argv[3]
})
person
  .save()
  .then(response => {
    console.log('Adding person ' + person.name + ' number ' + person.number + ' to the directory')
    mongoose.connection.close()
  })
}


