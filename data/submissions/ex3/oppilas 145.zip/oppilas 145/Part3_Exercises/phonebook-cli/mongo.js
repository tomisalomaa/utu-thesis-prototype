
const mongoose = require('mongoose')
const url = 'mongodb+srv://WM-programmer:eDz8AypPNDyLgg7k@webcluster.q7dbx.mongodb.net/fullstack-phonebook'
mongoose.connect(url)

const { argv } = process;

const personSchema = new mongoose.Schema({
    name: String,
    number: String,
  })

const Person = mongoose.model('Person', personSchema);


if (argv.length <= 2) {
    console.log('Starting search as requested')
    Person
    .find({})
    .then(result => {
        console.log('puhelinluettelo:')
        result.forEach(person => {
            console.log(person.name + ' ' + person.number)
        })
        mongoose.connection.close()
        process.exit()
    })
}
if (argv.length === 3) {
    console.log('Stop right here, I need more arguments')
    process.exit()
}
if (argv.length === 4) {
    console.log('Adding person ' + argv[2]+ ' ' + argv[3] + ' to the directory.')
    const person = new Person({
        name : argv[2],
        number : argv[3]
    })
    person
    .save()
    .then(response => {
        console.log('The process was successful')
        mongoose.connection.close()
    })
}