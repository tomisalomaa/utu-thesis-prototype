import axios from 'axios';
import React from 'react';
import Names from './components/Names'

const baseUrl = '/api/persons'

const getAll = () => {
  const request = axios.get(baseUrl)
  return request.then(response => response.data)
}

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
  }


  componentDidMount() {
    axios
      .get('https://fierce-sands-78270.herokuapp.com/api/persons')
      .then(response => {
        this.setState({ persons: response.data })
      })
  }


  addName = (event) => {
    event.preventDefault()
    const newNameAdded = {
      name: this.state.newName,
      number: this.state.newNumber,
    }

    axios
      .post('https://fierce-sands-78270.herokuapp.com/api/persons', newNameAdded)
      .then(response => {
        this.setState({
          persons: this.state.persons.concat(response.data),
          newName:'',
          newNumber:''
        })
      })
    }


  addNewNameEvent = (event) => {
    console.log(event.target.value)
    this.setState({ newName: event.target.value })
  }

  addNewNumberEvent = (event) => {
    console.log(event.target.value)
    this.setState({ newNumber: event.target.value})
  }

  checkList = (event) => {
    event.preventDefault()
    if(!this.state.persons.filter(name => name.name === this.state.newName).length > 0){
      this.addName(event)
    }
  }

  clickToRemove = (id) => {
    return () => {
      const url = `https://fierce-sands-78270.herokuapp.com/api/persons/${id}`
      const personID = this.state.persons.find(person => person.id === id)
      if (window.confirm("Poistetaanko " + personID.name)) {

        axios
          .delete(url, personID)
          .then(response => {
            this.setState({
              persons: this.state.persons.filter(person => person.id !== id)
            })
          })
        }
      }
    }
  


  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit = {this.checkList}>
          <div>
            nimi: <input value={this.state.newName} onChange={this.addNewNameEvent}/>
          </div>
          <div>
            numero: <input value={this.state.newNumber} onChange={this.addNewNumberEvent}/>
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
        <table>
          <tbody>

            {this.state.persons.map(names => <Names key={names.name} names={names} clickToRemove={this.clickToRemove(names.id)}/>)}
          
          </tbody>
        </table>                
      </div>
    )
  }
}

export default App