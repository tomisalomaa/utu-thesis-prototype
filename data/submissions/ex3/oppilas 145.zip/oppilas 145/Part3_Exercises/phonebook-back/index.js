

const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')
const generateId = (max) => {
    return Math.floor(Math.random() * max);
}

//middleware printer
const logger = (request, response, next) => {
    console.log('Method:',request.method)
    console.log('Path:  ', request.path)
    console.log('Body:  ', request.body)
    console.log('---')
    next()
}
const error = (request, response) => {
  response.status(404).send({error: 'unknown endpoint'})
}

const Person = require('./models/person')
const res = require('express/lib/response')

const formatPerson = (person) => {

  return {
    name: person.name,
    number: person.number,
    id: person._id
  }
}

let persons = []

app.use(express.static('build'))
app.use(bodyParser.json())
app.use(cors())
app.use(logger)

app.get('/api/persons', (request, response) => {
  Person
  .find({}, {__v: 0})
  .then(persons => {
    response.json(persons.map(formatPerson))
  })
})

app.get('/api/persons/:id', (request, response) => {
  Person
  .findById(request.params.id)
  .then(person => {
    if (person) {
      response.json(formatPerson(person))
    } else {
      response.status(404).end()
      }
    })
    .catch(error => {
    console.log(error)
    response.status(404).send({ error: 'ID not found' })
  })
})

app.delete('/api/persons/:id', (request, response) => {
  Person
  .findByIdAndRemove(request.params.id)
  .then(person => {
    if (person) {
      response.json(formatPerson(person))
    } else {
      response.status(204).end()
      }
    })
    .catch(error => {
    console.log(error)
    response.status(404).send({ error: 'ID not found' })
  })
})

app.post('/api/persons', (request, response) => {
    const body = request.body
  
    if (body.name === undefined || body.number === undefined) {
      return response.status(400).json({error: 'content missing'})
    }

    if (persons.filter(name => name.name === body.name).length > 0) {
        return response.status(400).json({error: 'name must be unique'})
      }
  
    const person = new Person({
      name: body.name,
      number: body.number,
      //ID-generaattori vaihdetaan mongon antamaan id-sarjaan
      id: body._id,
    })

    person
    .save()
    .then(savedPerson => {
      response.json(formatPerson(savedPerson))
    })
  })


//middleware error route for JSON, always at the end
app.use(error)

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})