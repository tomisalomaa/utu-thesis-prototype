const mongoose = require('mongoose')

const url = ''

mongoose.connect(url) 

const Person = mongoose.model('persons', {
    name: String,
    number: String
})

module.exports = Person