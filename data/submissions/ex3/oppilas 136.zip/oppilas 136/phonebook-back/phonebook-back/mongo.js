const mongoose = require('mongoose')

const url = ''

mongoose.connect(url)

const personSchema = new mongoose.Schema({
    name: String,
    number: String
})

const Person = mongoose.model('persons', personSchema)

const person = new Person({
    name: process.argv[2],
    number: process.argv[3]
})

if (process.argv[2] === undefined) {
    Person
    .find({})
    .then(result => {
        console.log(`puhelinluettelo:`)
        result.map(person => {
        console.log(person.name, person.number)
        mongoose.connection.close()
    })
})
} else {
    person
    .save()
    .then(result => {
        console.log(`adding person ${process.argv[2]} number ${process.argv[3]} to the directory`)
        mongoose.connection.close()
    })
}