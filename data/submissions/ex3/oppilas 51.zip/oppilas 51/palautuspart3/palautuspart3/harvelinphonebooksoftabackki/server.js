const http = require('http')
const mongoose = require('mongoose')
const MongooseUrl = 'mongodb+srv://hharveli:{password}h@phonebookcluster.snjm5.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
const express = require('express')
const app = express()
const bodyParser = require('body-parser')
app.use(bodyParser.json())
const cors = require('cors')
app.use(cors())
app.use(express.static('build'))


mongoose.connect(MongooseUrl)

const Information = mongoose.model('Information', {
  name: String,
  number: String
})

app.get('/api/persons', (req, res) => {
  Information
    .find({})
    .then(persons => {
      console.log(persons)
      res.json(persons)
    })
  })

  app.delete('/api/persons/:id', (req, res) => {
    const name = req.params.id
    
    Information
    .find({})
    .then(persons => {
    console.log(persons)
    const rv = persons.filter(rv => rv.name === name)
    console.log('comparing incoming name to:' + rv);
    console.log(typeof(rv));
    console.log(Object.entries(rv).length)
    if((Object.entries(rv).length > 0)){
          Information
          .findByIdAndRemove(rv[0]._id)
          .then(result => {
            return res.status(204).end()
          })
          .catch(error => {
            console.log(error)
            return res.status(400).send({ error: 'error when deleting entry' })
          })
    } else {
      return res.status(404).json({error: 'no such name'})
    }
    })
  })

  app.post('/api/persons/', (req, res) => {

    
    console.log(req.headers) 
    const body = req.body
    console.log('body:' + body);
  if (body == undefined) {
    return res.status(400).json({error: 'bad request:no body'})
  }

  const name = body.name
  const number = body.number

  console.log('name:' + name);
  console.log('number:' + number);

  if(name == undefined || number == undefined){
    return res.status(400).json({error: 'bad request:bad body'})
  }

  try{
    //in future save entry
    Information
    .find({})
    .then(persons => {
    const rv = persons.filter(rv => rv.name === name)
    console.log('comparing incoming name to:' + rv);
    if(rv.length > 0){
        return res.status(400).json({error: 'bad request:name must be unique'})
    }
    const info = new Information({
      name: name,
      number: number
    })
    info
      .save()
      .then(
        res.json({
          "message":"Saving successful"
      })
      )
    })
  } catch(error) {
    console.log(error)
    return res.status(500).json({error: 'internal server error'})
  }


 

  })
  
  const PORT = process.env.PORT || 3001
  app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
  })
