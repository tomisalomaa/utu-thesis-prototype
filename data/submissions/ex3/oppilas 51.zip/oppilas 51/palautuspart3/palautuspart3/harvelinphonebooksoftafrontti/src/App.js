import React from 'react';
import axios from 'axios'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: this.props.persons,
      newName: 'Uusi nimi',
      newNumber: '00000000'
    }
  }

  

  validate(array, name){
    let rv = true;
    array.forEach(element => {
        if(element.name === name){
            rv = false;
        }
    });
    return rv;
  }

  add = (event) => {
    event.preventDefault()
    console.log('nappia painettu')
    const number = {
        name: this.state.newName,
        number: this.state.newNumber,
        id: this.state.persons.length + 1
      }
      
      if(this.validate(this.state.persons, number.name)){
        const tmpPersons = this.state.persons.concat(number)
        this.setState({
            persons: tmpPersons,
            newName: 'Uusi nimi'
        });
        axios.post('/api/persons', number)
        .then(response => {
            console.log(response)
        })
      } else {
        alert('name taken');
      }
  }

  delete = (event) => {
    console.log(event.target.value)
    event.preventDefault()
    axios.delete('/api/persons/'+event.target.value).then(
      axios.get('/api/persons').then(response => {
        this.setState({
          persons: response.data,
          newName: 'Uusi nimi'
        });
      })
    )
  }

  handleChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleChangeNumber = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.add}>
          <div>
            nimi: <input value={this.state.newName} onChange={this.handleChange}/>
          </div>

          <div>
            numero: <input value={this.state.newNumber} onChange={this.handleChangeNumber}/>
          </div>

          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
        {this.state.persons.map(
            element => (
                <p>{element.name} {element.number} <button id="del" value={element.name} onClick={this.delete}>poista</button></p>
            )
        )}
      </div>
    )
  }
}

export default App
