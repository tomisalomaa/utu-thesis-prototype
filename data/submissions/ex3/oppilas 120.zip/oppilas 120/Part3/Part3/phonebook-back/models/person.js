const mongoose = require('mongoose')
// Replace with the URL of your own database. Do not store the password on GitLab!
const url =
  'mongodb+srv://<user>:<password>@cluster0.rbz33.mongodb.net/phonebookapp?retryWrites=true&w=majority'

mongoose.connect(url)

const personSchema = new mongoose.Schema({
  name: String,
  number: String,
  id: Number,
})

const Person = mongoose.model('Person', personSchema)

module.exports = Person
