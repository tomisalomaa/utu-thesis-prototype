// print process.argv
process.argv.forEach((person) => {
    console.log(`´${person}: ${number}`);
})