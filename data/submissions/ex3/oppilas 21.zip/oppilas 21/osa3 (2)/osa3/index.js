// Tehtävät 3.11 & 3.12

const express = require('express')
const app = express()
const cors = require('cors')
const Person = require('./models/Person')
const { request } = require('express')
const { response } = require('express')
const res = require('express/lib/response')


app.use(cors())
app.use(express.json())
app.use(express.static('build'))

let persons = [
  {
    "name": "Arto Hellas",
    "number": "040-123456",
    "id": 1
  },
  {
    "name": "Martti Tienari",
    "number": "040-123456",
    "id": 2
  },
  {
    "name": "Arto Järvinen",
    "number": "040-123456",
    "id": 3
  },
  {
    "name": "Lea Kutvonen",
    "number": "040-123456",
    "id": 4
  },
  {
    "name": "Tea Kutvonen",
    "number": "040-123456",
    "id": 5
  }
]

app.get('/', (req, res) => {
  res.send('<h1>Phonebook</h1>')
})

app.get('/persons', (req, res) => {
  Person
    .find({})
    .then(persons => {
      res.json(persons.map(formatPerson))
    })
})

/* app.get...
const id = Number(req.params.id)
 const person = persons.find(person => person.id === id)
 
 if (person) {
   res.json(person)
 } else {
   res.status(404).end()
 }
*/
app.get('/persons/:id', (req, response) => {
  Person
    .findById(req.params.id)
    .then(person => {
      if (person) {
        response.json(formatPerson(person))
      } else {
        response.status(404).end()
      }
    })
    .catch(error => {
      console.log(error)
      response.status(400).send({ error: 'malformatted id' })
    })

})
/*
  const id = Number(req.params.id)
  if (persons.some(person => id === person.id)) {
    persons = persons.filter(person => person.id !== id)
 
    res.status(200).end()
 
  } else {
    res.status(404).end()
  }
*/
app.delete('/persons/:id', (req, res) => {

  Person
    .findByIdAndRemove(req.params.id)
    .then(result => {
      res.status(204).end()
    })
    .catch(error => {
      res.status(400).send({ error: 'maformatted id' })
    })
})

app.post('/persons', (req, res) => {
  const body = req.body
  if (body.name === undefined || body.number === undefined) {
    return res.status(400).json({ error: 'content missing' })
  }
  /*
  if (persons.some(personX => personX.name === person.name)) {
    return res.status(400).json({ error: 'name must be unique' })
  }
*/
  const person = new Person({
    name: body.name,
    number: body.number,
    // id: person.id = Math.floor(Math.random() * 10000)
  })
  //console.log(person)
  //person.id = Math.floor(Math.random() * 10000)
  //persons = persons.concat(person)

  person
    .save()
    .then(savedPerson => {
      res.json(formatPerson(savedPerson))
    })



})

const formatPerson = (person) => {
  return {
    name: person.name,
    number: person.number,
    // id: person.id
  }
}

const port = process.env.PORT || 3001
app.listen(port, () => {
  console.log(`Server running on port ${port}`)
})






