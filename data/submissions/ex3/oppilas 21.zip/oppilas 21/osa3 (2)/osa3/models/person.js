const mongoose = require('mongoose')

const url = 'mongodb+srv://at:mongodb@cluster0.p7w4d.mongodb.net/webmob?retryWrites=true&w=majority'

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String,
    id: Number
})

module.exports = Person