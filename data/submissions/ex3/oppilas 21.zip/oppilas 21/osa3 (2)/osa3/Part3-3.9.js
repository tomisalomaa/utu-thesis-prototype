const mongoose = require('mongoose')

// Replace with the URL of your own database. Do not store the password on GitLab!
const url = 'mongodb+srv://at:mongodb@cluster0.p7w4d.mongodb.net/webmob?retryWrites=true&w=majority'

mongoose.connect(url)
let myArgs = process.argv.slice(2);
const Person = mongoose.model('Person', {
    name: String,
    number: String

})

const person = new Person({
    name: myArgs[0],
    number: myArgs[1]

})

person
    .save()
    .then(persons => {
        console.log('adding person to the directory')

        Person

            .find({})
            .then(persons => {
                console.log("Puhelinluettelo:")
                persons.forEach(person => {
                    console.log(person.name)
                    console.log(person.number)
                    mongoose.connection.close()
                })


            })

    })
