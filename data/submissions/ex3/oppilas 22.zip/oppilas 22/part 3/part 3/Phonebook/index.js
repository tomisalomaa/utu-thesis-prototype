const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')
const Nro = require('./models/nro')

app.use(cors())
app.use(express.json())
app.use(express.static('build'))
app.use(bodyParser.json())

/*
const requestLogger = (request, response, next) => {
  console.log('Method:', request.method)
  console.log('Path:  ', request.path)
  console.log('Body:  ', request.body)
  console.log('---')
  next()
}

app.use(requestLogger)
*/
/*
let persons = [
    {
      name: "Arto Hellas",
      number: "040-123456",
      id: 1
    },
    {
      name: "Martti Tienari",
      number: "040-123456",
      id: 2
    },
    {
      name: "Arto Järvinen",
      number: "040-123456",
      id: 3
    },
    {
      name: "Lea Kutvonen",
      number: "040-123456",
      id: 4
    }
  ]
  */
  
  //GET
  app.get('/api/persons', (request, response) => {
    Nro
    .find({})
    .then(nro => {
      response.json(nro.map(formatNro))
      }).catch(error => {
        console.log(error)
        response.status(404).end()
      })
  
  })

  app.get('/api/persons/:id', (request, response) => {
    Nro
    .findById(request.params.id)
    .then(nro => {
      if (nro) {
        response.json(formatNro(nro))
      } else {
        response.status(404).end()
      }
    }).catch(error => {
      console.log(error)
      response.status(404).end({error: 'malformatted id' })
    })

})

//POST
app.post('/api/persons', (request, response) => {
  const body = request.body
  delete body.id;
  if (body === undefined) {
    console.log('Body:  ', request.body)
    return response.status(400).json({error: 'content missing'})
  }

  const nro = new Nro({
    name: body.name,
    number: body.number
  })
 
 
  nro
    .save()
    .then(savedNro => {
      response.json(formatNro(savedNro))
    }).catch(error => {
      console.log(error)
      response.status(404).end()
    })
})

//DELETE
app.delete('/api/persons/:id', (request, response) => {
  Nro
    .findByIdAndRemove(request.params.id)
    .then(result => {
      response.status(204).end()
    })
    .catch(error => {
      response.status(400).send({ error: 'malformatted id' })
    })
})

const formatNro = (nro) => {
  return {
    name: nro.name,
    number: nro.number,
    id: nro._id
  }
}

/*
const generateId = () => {
  const newId = Math.floor((Math.random() * 1000));
  return newId
}
*/
/*
app.post('/api/persons', (request, response) => {
  const body = request.body

  if (body.name === undefined) {
    return response.status(400).json({error: 'content missing'})
  }

  for(const [name, num, id] of persons)
  if (body.name === name) {
    return response.status(400).json({error: 'name must be unique'})
  }

  if (body.number === undefined) {
    return response.status(400).json({error: 'number missing'})
  }


  const person = {
    name: body.name,
    number: body.number,
    id: generateId()
  }

  persons = persons.concat(person)

  response.json(person)
})
*/

const unknownEndpoint = (request, response) => {
  response.status(404).send({ error: 'unknown endpoint' })
}

app.use(unknownEndpoint)

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})