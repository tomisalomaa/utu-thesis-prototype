const mongoose = require('mongoose')

const url = 'mongodb+srv://aehork:qZ5a8iAv4oHLu6rj@phonebook.cqsqm.mongodb.net/phonebook-numbers'

mongoose.connect(url)


const nroSchema = new mongoose.Schema({
    name: String,
    number: String
})

nroSchema.set('toJSON', {
    transform: (document, returnedObject) => {
      returnedObject.id = returnedObject._id.toString()
      delete returnedObject._id
      delete returnedObject.__v
    }
  })

module.exports = mongoose.model('Nro', nroSchema)
