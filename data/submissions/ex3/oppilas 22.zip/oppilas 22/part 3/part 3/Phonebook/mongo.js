const mongoose = require('mongoose')

const url = 'mongodb+srv://aehork:qZ5a8iAv4oHLu6rj@phonebook.cqsqm.mongodb.net/phonebook-numbers'

mongoose.connect(url)


const nroSchema = new mongoose.Schema({
    name: String,
    number: String
})
const Nro = mongoose.model('Nro', nroSchema)

if(process.argv[2] === undefined){
    console.log('puhelinluettelo:')
    Nro
  .find({})
  .then(result => {
      result.forEach(nro => {    
        console.log(nro.name, nro.number)
      })
    mongoose.connection.close()
  })
}else{

const { argv } = process;
const [, , nam, num] = argv;

const nro = new Nro({
    name: (nam),
    number: (num)
  })

  nro
  .save()
  .then(result => {
    console.log('number added')
    mongoose.connection.close()
  })
}
