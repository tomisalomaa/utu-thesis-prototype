import ReactDOM from 'react-dom'
import React from 'react'
import App from './App'
import axios from 'axios'
const baseUrl = '/api/persons'
const promise = axios.get(baseUrl)

promise.then(response => {
  console.log(response)
})

ReactDOM.render(
  <App/>,
  document.getElementById('root')
)