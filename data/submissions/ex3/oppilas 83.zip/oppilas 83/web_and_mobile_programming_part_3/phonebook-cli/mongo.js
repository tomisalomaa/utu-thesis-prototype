const mongoose = require('mongoose')

// Replace with the URL of your own database. Do not store the password on GitLab!
const url = 'mongodb+srv://frozen:moi123@cluster0.6rsg7.mongodb.net/fullstack-persons'

mongoose.connect(url)

const personSchema = new mongoose.Schema({
  name: String,
  number: String
})

const Person = mongoose.model('person',personSchema);

if(process.argv.slice(2).length===0) {
    console.log('puhelinluettelo:')
    Person
  .find({})
  .then(persons=> {
    for(let i=0; i < persons.length;i++){
        console.log(persons[i].name+' '+persons[i].number)
    }
    mongoose.connection.close()
  })
}
else{
    const person = new Person({name:process.argv.slice(2)[0], number:process.argv.slice(2)[1]})

    person
    .save()
    .then(response => {
        console.log('adding person '+process.argv.slice(2)[0]+' number '+process.argv.slice(2)[1]+' to the directory')
        mongoose.connection.close()
    })
}