console.log('hello world')
const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')

app.use(express.static('build'))
app.use(cors())
app.use(bodyParser.json())

const mongoose = require('mongoose')

// Replace with the URL of your own database. Do not store the password on GitLab!
const url = 'mongodb+srv://frozen:moi123@cluster0.6rsg7.mongodb.net/fullstack-persons'

mongoose.connect(url)

const Person = mongoose.model('person', {
  name: String,
  number: String
})

module.exports = Person
/*
let persons = [
    {
        name: "Arto Hellas",
        number: "040-123456",
        id: 1
      },
      {
        name: "Martti Tienari",
        number: "040-123456",
        id: 2
      },
      {
        name: "Arto Järvinen",
        number: "040-123456",
        id: 3
      },
      {
        name: "Lea Kutvonen",
        number: "040-123456",
        id: 4
      }
  ]
*/
  const formatPerson = (person) => {
    return {
      name: person.name,
      number: person.number,
      id: person._id
    }
  }

  app.get('/api/persons', (request, response) => {
    Person
    .find({})
    .then(persons => {
      response.json(persons.map(formatPerson))
    })
  })

  app.get('/api/persons/:id', (request, response) => {
      Person
    .findById(request.params.id)
    .then(person => {
      if (person) {
        response.json(formatPerson(person))
      } else {
        response.status(404).end()
      }
    })
    .catch(error => {
      console.log(error)
      response.status(400).send({ error: 'malformatted id' })
    })

  })

  app.delete('/api/persons/:id', (request, response) => {
    Person
    .findByIdAndRemove(request.params.id)
    .then(result => {
      response.status(204).end()
    })
    .catch(error => {
      response.status(400).send({ error: 'malformatted id' })
    })
  })

  /*
  const generateId = () => {
    const maxId = persons.length > 0
      ? Math.max(...persons.map(n => n.id))
      : 0
    return maxId + 1
  }*/

  const generateNumber = (num) => {
    console.log(num)
    if(!num)
    {
      return String("040-"+Math.floor(100000 + Math.random() * 900000))
    }
    else
    {
      return num
    }
  }
  
  app.post('/api/persons', (request, response) => {
    const body = request.body
    console.log(request.body)
    console.log(!body.name)
    if (!body.name) {
        return response.status(400).json({error: 'content missing'})
      }
    
    const person = new Person({
      name: body.name,
      number: generateNumber(body.number)
    })
  
    person
      .save()
      .then(savedPerson => {
        response.json(formatPerson(savedPerson))
      })
  })
  

  const PORT = process.env.PORT || 3001
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
  })