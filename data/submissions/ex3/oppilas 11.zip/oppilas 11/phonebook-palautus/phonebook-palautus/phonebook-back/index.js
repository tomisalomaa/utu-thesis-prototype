const express = require('express')
const app = express()
const personsApi = express.Router()
const bodyParser = require('body-parser')
const cors = require('cors')
const { Person } = require('./mongo')

app.use('/api/persons', personsApi)
personsApi.use(bodyParser.json())
personsApi.use(cors())

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
})

app.use(express.static('build'));

personsApi.get('/', async (req, res) => {
    const persons = await Person.find()
    res.send(persons)
})
    .get('/:personId', async (req, res) => {
        console.log(req.params)

        const person = await Person.findById(req.params.id).exec()
        if (person === null) {
            res.status(404)
            res.send('Not found')
        } else {
            res.send(person)
        }
    })
    .delete('/:personId', async (request, response) => {
        await Person.findByIdAndDelete(request.params.personId)
        response.status(204).end()
    })
    .post('/', async (request, response) => {
        const person = request.body
        console.log(person)

        const newPerson = {
            name: person.name,
            number: person.number
        }

        if (!person.name) {
            return response.status(400).json({ error: 'name missing' })
        }
        if (!person.number) {
            return response.status(400).json({ error: 'number missing' })
        }
        let findName = await Person.findOne({ name: person.name })
        if (findName) {
            return response.status(400).json({ error: 'name already exists' })
        }

        const p = new Person(newPerson)
        await p.save();

        response.json(newPerson)
    })

