#!/bin/sh
npm run build
rm -rf ../phonebook-back/build
cp -r build ../phonebook-back/
cd ../phonebook-back/
git add build
git commit -m "Update front-end"
git push heroku master