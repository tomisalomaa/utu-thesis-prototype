import axios from 'axios';
import React from 'react';
import PuhelinluetteloForm from './PuhelinluetteloForm';
import PuhelinluetteloTable from './PuhelinluetteloTable';

const personsApiUrl = process.env.NODE_ENV === "production"
  ? "/api/persons"
  : "http://localhost:3001/api/persons"

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: null,
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    axios.get(personsApiUrl).then(response => {
      this.setState({
        persons: response.data,
      })
    })
  }

  handleNameChange = (event) => {
    this.setState({ newName: event.target.value })
  }

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value })
  }

  add = (event) => {
    event.preventDefault()

    const newPerson = {
      name: this.state.newName,
      number: this.state.newNumber
    }

    if (this.state.persons.map((person) => person.name).includes(this.state.newName)) {
      alert("Nimi on jo luettelossa")
      return
    }

    axios.post(personsApiUrl, newPerson).then(() => {
      let newPersons = this.state.persons.concat([
        newPerson
      ])
      this.setState({
        persons: newPersons,
        newName: '',
        newNumber: ''
      })
    }, err => {
      alert(err)
    })
  }

  remove = async (personToRemove) => {

    const shouldRemove = window.confirm("poistetaanko " + personToRemove.name)
    if (!shouldRemove) {
      return
    }

    let newPersons = this.state.persons
      .filter(person => person !== personToRemove)
console.log(personToRemove._id)
    await axios.delete(personsApiUrl + "/" + personToRemove._id)

    this.setState({
      persons: newPersons,
    })
  }

  render() {
    if (this.state.persons == null) {
      return 'Lataa...'
    }
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <PuhelinluetteloForm add={this.add}
          newName={this.state.newName}
          handleNameChange={this.handleNameChange}
          newNumber={this.state.newNumber}
          handleNumberChange={this.handleNumberChange}
        />
        <h2>Numerot</h2>
        <PuhelinluetteloTable persons={this.state.persons} remove={this.remove} />
      </div>

    )
  }
}

export default App
