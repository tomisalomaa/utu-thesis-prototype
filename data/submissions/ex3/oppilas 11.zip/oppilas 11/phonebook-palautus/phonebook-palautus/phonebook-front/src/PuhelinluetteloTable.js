export default function PuhelinluetteloTable(props) {
    return <table>
        <tbody>
            {
                props.persons.map((person) =>
                    <tr key={person.name}>
                        <td>{person.name}</td> 
                        <td>{person.number}</td>
                        <td><button onClick={() => props.remove(person)}>poista</button></td>
                    </tr>
                )
            }
        </tbody>
    </table>
}