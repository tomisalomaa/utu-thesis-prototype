const mongoose = require("mongoose")
require("dotenv").config()

const url = process.env.MONGODB_URI

mongoose.connect(url)

const Contact = mongoose.model("Contact", {
  name: String,
  number: String,
})

if (process.argv.length === 4) {
  const person = new Contact({
    name: process.argv[2],
    number: process.argv[3],
  })

  person.save().then((response) => {
    console.log(
      `adding person ${person.name} number ${person.number} to the directory`
    )
    mongoose.connection.close()
  })
} else {
  console.log("puhelinluettelo:")
  Contact.find({}).then((result) => {
    result.forEach((contact) => {
      console.log(`${contact.name} ${contact.number}`)
    })
    mongoose.connection.close()
  })
}
