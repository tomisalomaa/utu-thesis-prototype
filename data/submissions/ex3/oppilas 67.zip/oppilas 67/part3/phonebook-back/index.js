const express = require("express")
const app = express()
const cors = require("cors")
const bodyParser = require("body-parser")
const Contact = require("./models/contact")

app.use(express.static("build"))
app.use(cors())
app.use(bodyParser.json())

const BASEROUTE = "/api/persons"

const formatContact = (contact) => {
  return {
    name: contact.name,
    number: contact.number,
    id: contact._id,
  }
}

app.get(BASEROUTE, (request, response) => {
  Contact.find({})
    .then((persons) => {
      response.json(persons.map(formatContact))
    })
    .catch((error) => {
      console.log(error)
      response.status(404).end()
    })
})

app.get(`${BASEROUTE}/:id`, (request, response) => {
  Contact.findById(request.params.id)
    .then((person) => {
      if (person) {
        response.json(formatContact(person))
      } else {
        response.status(404).end()
      }
    })
    .catch((error) => {
      console.log(error)
      response.status(400).send({ error: "malformatted id" })
    })
})

app.delete(`${BASEROUTE}/:id`, (request, response) => {
  Contact.findByIdAndDelete(request.params.id)
    .then((result) => {
      response.status(204).end()
    })
    .catch((error) => {
      console.log(error)
      response.status(400).end()
    })
})

app.post(`${BASEROUTE}`, (request, response) => {
  const body = request.body
  if (!body.name || !body.number) {
    return response.status(400).json({ error: "content missing" })
  }

  const person = new Contact({
    name: body.name,
    number: body.number,
  })

  person
    .save()
    .then((saved) => {
      response.json(formatContact(saved))
    })
    .catch((error) => {
      console.log(error)
      response.status(418).end()
    })
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
