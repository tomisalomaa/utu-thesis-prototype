import React from 'react'
import ReactDOM from 'react-dom'
import axios from 'axios'
const baseUrl = '/api/persons'

class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            persons: [],
            newName: '',
            newNum: '',
            Id: ''
        }
        console.log('constructor')
    }   

    componentDidMount() {
        console.log('did mount')
        axios
            .get(baseUrl)
            .then(response => {
                console.log('promise fulfilled')
                this.setState({persons: response.data})
            })
    }

    deleteName(id){
        console.log(id)
        console.log(typeof id)
        axios  
            .delete(`${baseUrl}/${id}`)
            .then(res => {
                console.log(res);
                console.log(res.data);

                const persons = this.state.persons.filter(person => person.id !== id);
                this.setState({persons})
            })
        }

    addName = (event) => {
        event.preventDefault()
        if (this.state.persons.find(p => p.name === this.state.newName)) {
            window.alert("!!!");
            return false;
        } else {
        const nameObject = {
            name: this.state.newName,
            number: this.state.newNum
        }

        axios
            .post(baseUrl, nameObject)
            .then(response => {
                this.setState({
                    persons: this.state.persons.concat(response.data),
                    newName: '',
                    newNum: ''
                })
            })
        }
        console.log('nappia painettu')
        console.log(event.target)
    }

    handleNameChange = (event) => {
        console.log(event.target.value)
        this.setState({newName: event.target.value})
    }

    handleNumChange = (event) => {
        this.setState({newNum: event.target.value})
    }

    render() {
        console.log('render')
        return (
            <div>
                <h2>Puhelinluettelo</h2>
                <form onSubmit={this.addName}>
                    <div>
                        nimi: <input 
                            value={this.state.newName}
                            onChange={this.handleNameChange}
                            />
                    </div>
                    <div>
                        number: <input
                            value={this.state.newNum}
                            onChange={this.handleNumChange}
                            />
                    </div>
                    <div>
                        <button type="submit">lisää</button>
                    </div>
                </form>
                <h2>numerot</h2>
                <div>
                    {this.state.persons.map(person => <li key={person.id}>{person.name}  {person.number}  <button onClick={() => this.deleteName(person.id)}>delete</button></li>)} 
                </div>
            </div>
        )
    }
}
ReactDOM.render(<App />, document.getElementById('root'))
export default App