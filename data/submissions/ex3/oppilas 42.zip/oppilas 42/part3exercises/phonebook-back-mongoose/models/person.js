const mongoose = require('mongoose')
const url = 'mongodb+srv://emilh:xLklb@part3.4nl8f.mongodb.net/phonebook-cli'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String,
  id: String
})


module.exports = Person
