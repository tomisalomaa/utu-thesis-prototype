const mongoose = require('mongoose')
const url = 'mongodb+srv://emilh:xLklb@part3.4nl8f.mongodb.net/phonebook-cli'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String,
  id: Number
})

if (process.argv.length < 3) {
    Person
        .find({})
        .then(result => {
            result.forEach(person => {
                console.log('puhelinluettelo:')
                console.log(person)
            })
            mongoose.connection.close()
        })
  } else {
    const person = new Person({
        name: process.argv[2],
        number: process.argv[3],
        id: Math.floor(Math.random() * 100001)
      }) 

    person
      .save()
      .then(response => {
        console.log(`adding person ${person.name} number ${person.number} to the directory`)
        mongoose.connection.close()
      })
  }

