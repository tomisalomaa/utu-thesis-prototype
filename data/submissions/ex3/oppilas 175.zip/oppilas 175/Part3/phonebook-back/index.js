const { response } = require('express')
const express = require('express')
const app = express()
const bodyParser = require ('body-parser')
const cors = require('cors')

const logger = (request, response, next) => {
    console.log('Method:', request.method)
    console.log('Path:', request.path)
    console.log('Body:', request.body)
    console.log('---')
    next()
}

app.use(express.static('build'))
app.use(cors())
app.use(logger)
app.use(bodyParser.json())

let persons = [
    {
        name: "Arto Hellas",
        number: "040-123456",
        id: 1 
    },
    {
        name: "Matti Tienari",
        number: "040-123456",
        id: 2
    },
    {
        name: "Arto Järvinen",
        number: "040-123456",
        id: 3
    },
    {
        name: "Lea Kutvonen",
        number: "040-123456",
        id: 4
    }
]

app.get('/', (req, res) => {
    res.send('<h1> Phonebook backend; add /api/persons to see more </h1>')
})

app.get('/api', (req, res) =>{
    res.send('<h1> Not yet there mate. </h1>')
})

app.get('/api/persons', (req, res) => {
    res.json(persons)
})

app.get('/api/persons/:id', (req, res) => {
    const id = Number(req.params.id)
    const person = persons.find(person => person.id === id)
    
    if (person){
        res.json(person)
    }else {
        res.send('We did not find any matches with this specific id')
    }
})

app.delete('/api/persons/:id', (req, res) => {
    const id = Number(req.params.id)
    persons = persons.filter(person => person.id !== id)

    res.status(204).end()
})

const generateId = () => {
    const newId = Math.floor(Math.random() * 15000);
    return newId
}

const differentName = (req, res) => {
    const name = req.params.name
    const person = persons.find(person => person.name === name) 
    res.json(person)
}

app.post('/api/persons', (req, res) => {
    const body = req.body
    const name = req.params.name

    if (body.name === undefined){
        return res.status(400).json({error: 'name missing'})
    }

    if (body.number === undefined){
        return res.status(400).json({error: 'number missing'})
    }

    if (body.name === differentName){
      return res.status(400).json({error: 'name already exists'})
}
    const person = {
        name: body.name,
        number: body.number,
        id: generateId()
    }

    res.json(person)
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
})