const mongoose = require('mongoose')
const url = 'mongodb+srv://fullstack:fullstackpersons@cluster0.fuzgk.mongodb.net/fullstack-persons'
const process = require('process');

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String
})

const person = new Person({
    name: 'Jukka Palmu',
    number: '040-123456'
})

person.save().then(response => {
    console.log('Person saved!')
})

Person.find({}).then(result => {
    result.forEach(person => {
        console.log(person)
    })
    mongoose.connection.close()
})