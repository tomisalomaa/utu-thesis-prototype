import React from 'react'
function Print (input) {
    return (
    <div>
      <h2>Numerot</h2>
            {input.persons.map((persons) =>(
          <p key={persons.name}>
            {persons.name} {persons.number}
          </p> ))}
    </div> )
}

export default Print