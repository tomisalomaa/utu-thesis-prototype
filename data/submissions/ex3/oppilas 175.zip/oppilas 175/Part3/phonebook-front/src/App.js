import React, { useEffect } from 'react'
import Print from './components/Print';
import axios from 'axios'
const baseURL = 'api/persons'

const getAll = () => {
  const request = axios.get(baseURL)
  return request.then(response => response.data)
}

class App extends React.Component{
  constructor(props) {
    super(props)
    
    this.state = ({
      persons: [],   
      newName: "",
      newNumber: ""
    })
  }
  
  componentDidMount() {
    axios
      .get('https://fierce-chamber-36859.herokuapp.com/')
      .then(response => {
        this.setState({ persons : response.data })
  })}
  
  eventHandler = (event) => {  
    this.setState(
      {[event.target.id]:event.target.value})
  }
  
  saveInfo = (event) => {
      event.preventDefault()         
      const persons= {
        name: this.state.newName,
        number: this.state.newNumber
      }
      if (this.state.persons.some(name => name.name === this.state.newName)) {
        alert('Nimi lisätty jo')
      }
      else {
        axios
        .post('https://fierce-chamber-36859.herokuapp.com/', persons)
        .then(response => {
          this.setState({
            persons : this.state.persons.concat(response.data),
            newNote: ''
          })
        })
      }} 

render() {
  return (
      <div>
        
        <h1>Puhelinluettelo</h1>
        <form onSubmit={this.addPerson}>
          <div>
            Nimi: <input id="newName" value={this.state.newName} onChange={this.eventHandler} />
          </div>
          <div>
            Numero: <input id="newNumber" value={this.state.newNumber} onChange={this.eventHandler} />
          </div>
          <div>
            
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
         <div>
            {Print(this.state)}
          </div>
        </div>
    )
  }
}

export default App