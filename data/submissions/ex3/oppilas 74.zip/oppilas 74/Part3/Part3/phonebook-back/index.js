const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const Person = require('./models/person')
const logger = (request, response, next) => {
    console.log('Method:', request.method)
    console.log('Path: ', request.path)
    console.log('Body: ', request.body)
    console.log('---')
    next()
}

app.use(logger)


const cors = require('cors')
const { response } = require('express')

app.use(cors())

app.use(bodyParser.json())

app.use(express.static('build'))


let phonebook = [
    {
        name: "Arto Hellas",
        number: "040-123458",
        id: 1
    },
    {
        name: "Martti Tienari",
        number: "040-123456",
        id: 2
    },
    {
        name: "Arto Järvinen",
        number: "040-123456",
        id: 3
    },
    {
        name: "Lea Kutvonen",
        number: "040-123456",
        id: 4
    }
]



const formatPerson = (person) => {
    return {
        name: person.name,
        number: person.number,
        id: person._id
    }
}

app.get('/', (req, res) => {
    res.send('<h1>Hello World!</h1>')
})

app.get('/api/persons', (req, res) => {
    Person
        .find({}, {__v: 0})
        .then(phonebook => {
            res.json(phonebook.map(formatPerson))
        })
})

app.get('/api/persons/:id', (req, res) => {
    
    Person
        .findById(req.params.id)
        .then(person => {
            if (person) {
                res.json(formatPerson(person))
            } else {
                res.status(404).end()
            }
        })
        .catch(error => {
            console.log(error)
            res.status(400).send({error: 'malformatted id'})
        })
    /*const id = Number(req.params.id)
    const person = phonebook.find(person => person.id === id)
    
    if (person) {
        res.json(person)
    } else {
        res.status(404).end()
    }
    */
})

app.delete('/api/persons/:id', (request, response) => {
    Person
        .findByIdAndRemove(request.params.id)
        .then(result => {
            response.status(204).end()
        })
        .catch(error => {
            response.status(400).send({ error: 'malformatted id'})
        })
    /*
    const id = Number(req.params.id)
    phonebook = phonebook.filter(person => person.id !== id)
    res.status(204).end()
    */
})

/*
function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max-min) + min);
}


const generateId = () => {
    const newId = getRandomInt(100, 99999)
    return newId
}
*/

app.post('/api/persons', (req, res) => {
    const body = req.body

    findName = phonebook.find(person => person.name === body.name)
    if (body.name === undefined) {
        return res.status(400).json ({error: 'name undefined'})
    } else if (body.number === undefined) {
        return res.status(400).json ({error: 'number undefined'})
    } else if (findName) {
        return res.status(405).json ({error: 'name must be unique'})
    }
    
    const person = new Person({
        name: body.name,
        number: body.number,
        //id: generateId()
    })

    person
        .save()
        .then(savedPerson => {
            res.json(formatPerson(savedPerson))
        })
    
    //phonebook = phonebook.concat(person)

    //res.json(person)
})
const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
})

const error = (request, response) => {
    response.status(404).send({error: 'unknown endpoint'})
  }
  
  app.use(error)
