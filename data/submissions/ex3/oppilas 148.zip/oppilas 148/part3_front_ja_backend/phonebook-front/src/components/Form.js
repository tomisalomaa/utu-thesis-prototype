import React from 'react'

const Form = ({ addPerson, valueName, handleNameChange, valueNumber, handleNumberChange }) => {
  return (
	<form onSubmit={addPerson}>
		<div>
			<p>Nimi:
			<input
				value={valueName} 
				onChange={handleNameChange}
			/></p>
		</div>
		
		<div>
		    <p>
			Numero:
			<input
				value = {valueNumber}
				onChange={handleNumberChange} 
			/></p>
		</div>
		
		<div>
			<button type="submit">lisää</button>
		</div>
	</form>
  )
}

export default Form