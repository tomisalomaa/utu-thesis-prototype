import axios from 'axios';
const baseUrl = '/api/people';

const getAll = () => {
    return axios.get(baseUrl);
}

const create = obj => {
    return axios.post(baseUrl, obj);
}

const remove = id => {
    return axios.delete(`${baseUrl}/${id}`)
}

// eslint-disable-next-line import/no-anonymous-default-export
export default { getAll, create, remove };