import React from 'react';

import Numbers from './components/Numbers';
import Form from './components/Form';

import numberService from './services/numbers';

class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			persons: [
				{
					name: '',
					number: ''
				}
			],
			newName: '',
			newNumber: ''
		};
	}

	componentDidMount() {
        numberService
            .getAll()
            .then(response => {
                this.setState({persons: response.data});
            });
	}

    addNumber = e => {
        e.preventDefault();

        if(this.state.persons.some(person => person.name === this.state.newName)) {
            alert(`Henkilö nimeltä '${this.state.newName}' on jo puhelinluettelossa!`);
            return;
        }

        numberService
            .create({
                name: this.state.newName,
                number: this.state.newNumber
            })
            .then(response => {
                this.setState({
                    persons: this.state.persons.concat(response.data),
                    newName: '',
                    newNumber: ''
            })
        })
    }

    deleteNumber = person => {
        return() => {                
            if(window.confirm(`Poistetaanko ${person.name}?`)) {
                numberService
                    .remove(person.id)
                    .then(() => {
                        this.setState({
                            persons: this.state.persons.filter(p => p.id !== person.id)
                        })
                    })
                    .catch(err => {
                        console.log(err);
                    })
            }            
        }
    }

    handleNameChange = e => {
        this.setState({newName: e.target.value});
    }

    handleNumberChange = e => {
        this.setState({newNumber: e.target.value});
    }

	render() {
		return (
			<div>
                <Form 
                    newName={this.state.newName}
                    newNumber={this.state.newNumber}
                    addNumber={this.addNumber}
                    handleNameChange={this.handleNameChange}
                    handleNumberChange={this.handleNumberChange} />
                <Numbers 
                    persons={this.state.persons} 
                    deleteNumber={this.deleteNumber} />
			</div>
		);
	}
}

export default App;
