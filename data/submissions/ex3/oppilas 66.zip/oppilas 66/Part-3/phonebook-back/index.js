const express = require('express');
const app = express();

const bodyParser = require('body-parser');
app.use(bodyParser.json());
const cors = require('cors');
app.use(cors());
app.use(express.static('build'));
const Person = require('./modules/person');

/* format */
const formatPerson = (person) => {
    return {
        name: person.name,
        number: person.number,
        id: person._id
    };
};

/* get all persons */
app.get('/api/people', (_, res) => {
    Person
        .find({})
        .then(persons => {
            res.json(persons.map(formatPerson));
    })
});

/* get single person */
app.get('/api/people/:id', (req, res) => {
    Person
        .findById(req.params.id)
        .then(person => {
            if(person) {
                res.json(formatPerson(person)); 
            }
            else {
                res.status(404).end();
            }
        })
        .catch(error => {
            console.log(error);
            res.status(404).send({ error: 'malformatted id' });
        });
});

/* delete person */
app.delete('/api/people/:id', (req, res) => {
    Person 
        .findByIdAndRemove(req.params.id)
        .then(() => {
            res.status(204).end();
        })
        .catch(error => {
            console.log(error);
            res.status(400).send({ error: 'malformatted id' })
        });
});

/* add person */
app.post('/api/people', (req, res) => {    
    const body = req.body;

    if(body.name === undefined) {
        return res.status(400).json({error: 'name missing'});
    }
    if(body.number === undefined) {
        return res.status(400).json({error: 'number missing'});
    }

    Person.findOne({name: body.name}, (error, res) => {
        if(error) {
            console.log(error);
            return res.status(400).end();
        }
        if(res) {
            return res.status(403).json({error: 'name must be unique'})
        }
    });

    const person = new Person({
        name: body.name,
        number: body.number
    });

    person
        .save()
        .then(formatPerson)
        .then(result => {
            res.json(result);
    });
});

/* start listening */
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
