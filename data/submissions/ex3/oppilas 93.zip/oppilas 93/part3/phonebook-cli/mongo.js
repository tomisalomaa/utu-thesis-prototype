const mongoose = require("mongoose");

if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config();
}

const mongo = process.env.MONGODB_URI;
mongoose.connect(mongo);

const Entry = mongoose.model("Entry", {
  name: String,
  number: String,
  _id: Number
});

let args = process.argv;

// argumenttejä on neljä tai enemmän, kun lisätään...
if(args.length >= 4) {
  let name = args[2];
  let number = args[3];

  const entry = new Entry({
    name,
    number,
    _id: Math.floor(Math.random() * 100000)
  });

  entry.save().then(() => {
    console.log(`adding person ${name} number ${number} to the directory`);
    mongoose.connection.close();
    process.exit();
  });
} else {
  console.log("puhelinluettelo:");
  Entry.find().then(entries => {
    entries.forEach(entry => {
      console.log(`${entry.name} ${entry.number}`);
    });

    mongoose.connection.close();
    process.exit();
  })
}
