const PhonebookForm = ({ handleSubmit, newName, newNum, setNewName, setNewNum }) => {
  return (
    <form onSubmit={e => handleSubmit(e)}>
      <div>
        nimi: <input value={newName} onChange={e => setNewName(e.target.value)} />
      </div>
      <div>
        numero: <input value={newNum} onChange={e => setNewNum(e.target.value)} />
      </div>
      <div>
        <button type="submit">lisää</button>
      </div>
    </form>
  )
}

export default PhonebookForm;