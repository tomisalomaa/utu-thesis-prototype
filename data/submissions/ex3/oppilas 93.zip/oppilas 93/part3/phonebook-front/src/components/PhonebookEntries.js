import PhonebookEntry from "./PhonebookEntry";

const PhonebookEntries = ({ entries, handleDeleteNumber }) => {
    return (
      <table>
        <tbody>
        {entries.map(entry =>
          <PhonebookEntry key={entry.name} deleteNumber={handleDeleteNumber} entry={entry} />
        )}
        </tbody>
      </table>
    )
}

export default PhonebookEntries;