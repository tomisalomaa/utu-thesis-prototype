import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

import PhonebookEntries from './components/PhonebookEntries';
import PhonebookForm from './components/PhonebookForm';

const API_HOST = "/api/persons";

const App = () => {

  const [persons, setPersons] = useState([]);
  const [newName, setNewName] = useState("");
  const [newNum, setNewNum] = useState("");

  /**
   * Periaatteessa sama kuin componentDidMount.
   * Haetaan alkustate palvelimelta.
   */
  useEffect(() => {
    axios
      .get(API_HOST)
      .then(response => setPersons(response.data));
  }, []);

  const addName = event => {
    event.preventDefault();
    if (newName === "" || newNum === "") {
      alert("Täytä molemmat kentät! pliis");
      return;
    }

    if (persons.some(el => el.name === newName)) {
      alert(`Nimi ${newName} on jo puhelinluettelossa!`);
      return;
    }

    axios
      .post(API_HOST, { name: newName, number: newNum })
      .then(response => {
        /**
         * Päivitetään state selaimessa vasta kun ollaan varmoja,
         * että uuden kontaktin lisääminen onnistui palvelimella.
         */
        setPersons([
          ...persons,
          response.data // pyyntö palauttaa lisätyn henkilön ja sille annetun idn, joten käytetään sitä
        ]);
        setNewName("");
        setNewNum("");
      })
      .catch(error => {
        alert(error.response.data.error);
      });
  }

  const deleteNumber = entry => {
    const confirmation = window.confirm(`poistetaanko ${entry.name}`);
    if(confirmation) {
      axios
        .delete(`${API_HOST}/${entry.id}`)
        .then(() => {
          setPersons(persons.filter(person => person !== entry));
        });
    }
  }

  return (
    <>
      <h2>Puhelinluettelo</h2>
      <PhonebookForm
        handleSubmit={addName}
        newName={newName} 
        newNum={newNum} 
        setNewName={setNewName} 
        setNewNum={setNewNum}
      />

      <h2>Numerot</h2>
      <PhonebookEntries 
        handleDeleteNumber={deleteNumber}
        entries={persons}
      />
    </>
  )
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);