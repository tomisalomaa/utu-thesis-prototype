const PhonebookEntry = ({ entry, deleteNumber }) => {
  return (
    <tr>
      <td>{entry.name}</td>
      <td>{entry.number}</td>
      <td><button onClick={() => deleteNumber(entry)}>poista</button></td>
    </tr>  
  )
}

export default PhonebookEntry;