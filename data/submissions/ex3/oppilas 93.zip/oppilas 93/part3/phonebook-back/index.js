const express = require("express");
const cors = require("cors");
const Entry = require("./models/mongo");
const app = express();

app.use(express.json()); // nykyään ei tarvii bodyparseria
app.use(cors());
app.use(express.static("build"));

app.get("/api/persons", (_request, response) => {
  Entry
    .find()
    .then(entries => entries.map(e => {
      return {
        name: e.name,
        number: e.number,
        id: e._id
      }})
    )
    .then(entries => {
      return response.json(entries);
    })
    .catch(error => console.log(error));
});

app.post("/api/persons", (request, response) => {
  const newEntry = request.body;

  if (!("name" in newEntry)) {
    return response.status(400).json({ error: "Name must be present." });
  }

  if (!("number" in newEntry)) {
    return response.status(400).json({ error: "Number must be present." });
  }

  let contact = {
    name: newEntry.name,
    number: newEntry.number,
    _id: Math.floor(Math.random() * 100000)
  };

  const entry = new Entry(contact);
  entry.save().then(() => {
    contact.id = contact._id;
    delete contact._id;

    return response.status(201).json(contact);
  })
  .catch(error => console.log(error));

});

app.get("/api/persons/:id", (request, response) => {
  const id = Number(request.params.id);

  Entry.findById(id).then(result => {
    if(result) {
      return response.json({
        name: result.name,
        number: result.number,
        id: result._id
      });
    }
    return response.status(404).end();
  })
  .catch(error => {
    console.log(error);
    return response.status(400).json({ error: "Malformatted id" });
  });
});

app.delete("/api/persons/:id", (request, response) => {
  const id = Number(request.params.id);

  Entry.findByIdAndRemove(id).then(result => {
    if(result) {
      return response.status(204).end();
    }
    return response.status(404).end();
  })
  .catch(error => {
    console.log(error);
    return response.status(400).json({ error: "Malformatted id" });
  });

});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Express Server running on port ${PORT}`);
});