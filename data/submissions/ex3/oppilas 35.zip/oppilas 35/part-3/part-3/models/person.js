const mongoose = require('mongoose')

//mongo_test:UpKbUJTaCbK8Bje
const mongoUrl = 'mongodb+srv://mongo_test:UpKbUJTaCbK8Bje@cluster0.ddq18.mongodb.net/phonebook-fullstack'

mongoose.connect(mongoUrl)

const Person = mongoose.model('Person', {
    name: String,
    number: String
})

module.exports = Person
