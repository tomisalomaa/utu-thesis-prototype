const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')
const Person = require('./models/person')

app.use(express.static('build'))
app.use(bodyParser.json())
app.use(cors())


let persons = [
        {
            name: 'Arto Hellas',
            number: '040-123456',
            id: 1
        },
        {
            name: 'Martti Tienari',
            number: '040-123456',
            id: 2
        },
        {
            name: 'Arto Järvinen',
            number: '040-123456',
            id: 3
        },
        {
            name: 'Lea Kutvonen',
            number: '040-123456',
            id: 4
        }
]

const format_pers = (person) => {
    return {
        name: person.name,
        number: person.number,
        id: person._id
    }
}

app.get('/api/persons', (req, res) => {
    Person.find({}).then(persons => {
        res.json(persons.map(format_pers))
    })
    .catch(error => {
        console.log(error)
        res.status(404).end()
    })
})

/*
app.get('/api/persons/:id', (req, res) => {
    const id = Number(req.params.id)
    const person = persons.find(person => person.id === id)

    if (person) {
        res.json(person)
    } else {
        res.status(404).end()
    }
}) */


app.get('/api/persons/:id', (req, res) => {
    Person.findById(req.params.id)
    .then(person => {
        res.json(format_pers(person))
    })
    .catch(error => {
        console.log(`[ERROR] In adding new entry with id ${req.params.id}:`)
        console.log(error)
        res.status(404).json({error: 'invalid id'})
    })
})

app.delete('/api/persons/:id', (req, res) => {
    Person.findByIdAndRemove(req.params.id)
    .then(person => {
        console.log(`Deleting entry ${req.params.id}`)
        res.status(204).end()
    })
    .catch(error => {
        console.log(`[ERROR] In removing entry with id ${req.params.id}:`)
        console.log(error)
        res.status(400).json({error: 'invalid id'})
    })
})

app.post('/api/persons', (req, res) => {
    const body = req.body;

    if (body.name === undefined || body.name === "" || body.number === undefined || body.number === "" ) {
        return res.status(400).json({error: 'invalid'})
    }

    if (persons.find(person => person.name === body.name)) {
        return res.status(400).json({error: 'name must be unique'})
    }

    const person = new Person({
        name: body.name,
        number: body.number
    })

    person.save().then(savedPerson => {
        res.json(format_pers(savedPerson))
    })
    .catch(error => {
        console.log('[ERROR] In adding new entry' + JSON.stringify(person) + ':')
        console.log(error)
        res.status(400).end()
    })
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
})
