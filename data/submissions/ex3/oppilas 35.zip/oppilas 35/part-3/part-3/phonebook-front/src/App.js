import React from 'react'
import axios from 'axios'
const baseUrl = '/api/persons'

const Person = ({person, remove}) => {
    return (
        <tr>
            <td>{person.name}</td><td>{person.number}</td><td><button onClick={remove}>poista</button></td>
        </tr>
    )
}

const PersonForm = (props) => {
    return (
        <div>
            <form onSubmit={props.addPerson}>
                <div>
                    nimi: <input value={props.newName} onChange={props.handleNameChange} />
                </div>
                <div>
                    numero: <input value={props.newNumber} onChange={props.handleNumChange} />
                </div>
                <div>
                    <button type="submit">lisää</button>
                </div>
            </form>
        </div>
    )
}

class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            persons: [], //name, number, id
            newName: '',
            newNumber: ''
        }
    }

    componentDidMount() {
        axios
          .get(baseUrl)
          .then(response => {
              this.setState({persons: response.data})
          })
    }

    addPerson = (event) => {
        event.preventDefault()
        const newPerson = {name: this.state.newName, number: this.state.newNumber}

        const exists = (person1) => person1.name === newPerson.name

        if (!this.state.persons.some(exists)) {
            // Save to server
            axios
              .post(baseUrl, newPerson)
              .then(response => {
                  const persons = this.state.persons.concat(response.data)
                  this.setState({persons: persons, newName: '', newNumber: ''})
              })
        }
        else {
            this.setState({newName: '', newNumber: ''})
        }
    }

    removePerson = (id) => {
        return () => {
            if (window.confirm('Poistetaanko ' + this.state.persons.find(person => person.id === id).name + '?')) {
                axios.delete(`${baseUrl}/${id}`)
                this.setState({persons: this.state.persons.filter(person => person.id !== id)})
            }
        }
    }

    handleNameChange = (event) => {
        this.setState({newName: event.target.value})
    }

    handleNumChange = (event) => {
        this.setState({newNumber: event.target.value})
    }

    render() {
        return (
            <div>
                <h2>Puhelinluettelo</h2>
                <div>
                    <PersonForm
                        addPerson={this.addPerson}
                        newName={this.state.newName}
                        handleNameChange={this.handleNameChange}
                        newNumber={this.state.newNumber}
                        handleNumChange={this.handleNumChange}
                    />
                </div>
                <h2>Numerot</h2>
                <div>
                    <table>
                        <tbody>
                            {this.state.persons.map((person) => <Person key={person.id} person={person} remove={this.removePerson(person.id)} />)}
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

export default App
