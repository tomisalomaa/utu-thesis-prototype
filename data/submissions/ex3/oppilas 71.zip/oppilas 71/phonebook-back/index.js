const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const cors = require('cors');

app.use(express.static('build'));
app.use(cors());
app.use(bodyParser.json());
const Person = require('./models/person');

const formatPerson = (person) => {
    return {
      name: person.name,
      number: person.number,
      id: person._id
    }
}

const formatPersons = (persons) => { return persons.map(formatPerson) };

app.get('/api/persons', (request, response) => {
    Person
        .find({})
        .then(formatPersons)
        .then(persons => { response.json(persons) })
        .catch(error => { console.log(error) });
});

app.get('/api/persons/:id', (request, response) => {
    Person
        .findById(request.params.id)
        .then(formatPerson)
        .then(person => {
            if (person) {
                response.json(person);
            } else {
                response.status(404).end();
            }
        })
        .catch(error => {
            console.log(error);
            response.status(400).send({ error: 'malformatted id' });
        });
});

app.delete('/api/persons/:id', (request, response) => {
    Person
        .findByIdAndRemove(request.params.id)
        .then(person => {
            if (person) {
                response.status(204).end();
            } else {
                response.status(404).end();
            }
        })
        .catch(error => {
            console.log(error);
            response.status(400).send({ error: 'malformatted id' });
        });
});

app.post('/api/persons', (request, response) => {
    const body = request.body;
    
    if (!body.name || !body.number) {
        return response.status(400).send({error: 'name and phone number are required'});
    };
    
    const person = new Person({
        name: body.name,
        number: body.number
    });
    
    person
        .save()
        .then(formatPerson)
        .then(savedPerson => { response.json(savedPerson) })
        .catch(error => { console.log(error) });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});