const mongoose = require('mongoose');
const url = 'mongodb+srv://hello_kitty:gsaJKuIeliTfX09p@cluster0.g2nav.mongodb.net/phonebook';
mongoose.connect(url);

const Person = mongoose.model('Person', {
    name: String,
    number: String
});

module.exports = Person