const mongoose = require('mongoose')
const url = 'mongodb+srv://hello_kitty:jIPaz9PN16dqjyju@cluster0.g2nav.mongodb.net/phonebook?retryWrites=true&w=majority';

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String
})

const cliArgs = process.argv.slice(2);

switch (cliArgs.length) {
    case 0:
        Person
            .find({})
            .then(result => {
                console.log('puhelinluettelo:');
                result.forEach(person => {
                    console.log(`${person.name} ${person.number}`);
                    mongoose.connection.close();
            });
        });
        break;
    case 2:
        const name = cliArgs[0];
        const number = cliArgs[1];
        const person = new Person({
          name: name,
          number: number
        })
        person
            .save()
            .then(response => {
                console.log(`adding person ${name} number ${number} to the directory`)
                mongoose.connection.close();
            })
        break;
    default:
        // If invalid number of arguments were given, the program will terminate with an error message.
        console.log(`Error: Invalid amount of parameters were given: only 0 or 2 is allowed. You gave ${cliArgs.length}.`);
        console.log('Closing connection...');
        mongoose.connection.close().then(console.log("Connection closed."));
}