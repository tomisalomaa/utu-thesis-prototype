const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')
const Person=require('./models.person')
app.use(cors())
app.use(express.static('build'))

const logger = (req,res,next)=> {
    console.log('Method: ', req.method)
    console.log('Path: ', req.path)
    console.log('Body: ', req.body)
    console.log('---')
    next()
}
app.use(logger)



const generateId=()=> {
    return Math.floor(Math.random()*1000000)
}

app.use(bodyParser.json())

let persons = [
    {
        name: "Arto Hellas",
        number: "040-123456",
        id: 1
    },
    {
        name: "Martti Tienari",
        number: "040-123456",
        id: 2
    },
    {
        name: "Arto Järvinen",
        number: "040-123456",
        id: 3
    },
    {
        name: "Lea Kutvonen",
        number: "040-123456",
        id: 4
    }
]

app.get('/',(req,res) =>{
    console.log('toimii')
    res.send('<h1>Part 3: Aarni Soininen</h1>')
})

app.get('/api/persons',(req,res)=>{
    console.log('toimii2')
    res.json(persons)
})

app.get('/api/persons/:id', (req,res) =>{
    const id = Number(req.params.id)
    const person = persons.find(person => person.id === id)
    if(person){
        console.log('toimii3')
       res.json(person) 
    } else {
        res.status(404).end()
    }
    
})

app.delete('/api/persons/:id', (req,res) =>{
    const id = Number(req.params.id)
    persons = persons.filter(person => person.id !== id)
    console.log('poistettu')
    res.status(204).end()
})

app.post('/api/persons', (req,res) => {
    const body = req.body
    const names= persons.map(person=> person.name);

    if(body.name===undefined || body.number===undefined){
        return res.status(400).json({error: 'content missing'})
    }  

    const person = {
        name: body.name,
        number: body.number,
        id: generateId()
    }

    if(names.includes(body.name)){
        return res.status(400).json({error: 'person already exists in phonebook'})
    }
    
    persons= persons.concat(person)
    res.json(person)
})

const error = (req,res)=>{
    res.status(404).send({error: 'unknown endpoint'})
}
app.use(error)

const port = process.env.port ||3001
app.listen(port,() =>{
    console.log('Server running on port', port)
})