const mongoose = require('mongoose')

if(process.env.NODE_ENV !== 'prodiúction'){
    require('dotenv').config()
}


const url = process.env.MONGO_URI

mongoose.connect(url)

const Person= mongoose.model('Person', {
  name: String,
  number: Date
})


if(process.argv.length===4){
    const person = new Person({
        name: process.agv[2],
        number: process.argv[3]
    })

person
  .save()
  .then(response => {
    console.log('person saved!')
    mongoose.connection.close()
  })
} else if(process.argv.length ===2){
    Person
    .find({})
    .then(result=>{
        console.log('puhelinluettelo:')
        result.forEach(person=>{
            console.log(person.name,person.number)
        })
        mongoose.connection.close()
    })
} else{
    console.log('Tuntematon komento')
    mongoose.connection.close()
}