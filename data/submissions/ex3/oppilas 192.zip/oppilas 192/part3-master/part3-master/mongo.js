const mongoose = require('mongoose')

if ( process.env.NODE_ENV !== 'production' ) {
  require('dotenv').config()
}

const url = process.env.MONGODB_URI
const myArgs=process.argv.slice(2);


const Person = mongoose.model('Person', {
  name: String,
  number: String
})

if(!(myArgs[0]===undefined && myArgs[1]===undefined)){
const person = new Person({
  name: myArgs[0],
  number: myArgs[1]
})

  person
  .save()
  .then(response => {
    console.log(`adding person ${myArgs[0]} to the directory `)
    mongoose.connection.close()
  })}
  else{
  Person
  .find({})
  .then(result => {
    result.forEach(person => {
      console.log(person)
    })
    mongoose.connection.close()
  })}