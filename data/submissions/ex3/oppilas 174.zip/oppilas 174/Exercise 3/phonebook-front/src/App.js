import React from 'react'
import axios from 'axios'

const dbUrl = '/api/persons'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
      ],
      newName: '',
      newNumber: ''
    }
  }

  componentDidMount() {
    axios
      .get(dbUrl)
      .then(response => {
        this.setState({persons: response.data})
      })
  }

  onNameChange = (event) => this.setState({newName: event.target.value})
  onNumberChange = (event) => this.setState({newNumber: event.target.value})

  onSubmit = (event) => {
    event.preventDefault()
    if (!this.state.persons.find(person => person.name === this.state.newName))
      axios.post(dbUrl, {name: this.state.newName, number: this.state.newNumber})
        .then((response) => {
          this.setState((prevState) => ({persons: prevState.persons.concat(response.data)}))
        })
    this.setState({newName: '', newNumber: ''})
  }

  onDelete = (id) => () => { 
    if(window.confirm(`poistetaanko ${this.state.persons.find((person) => person._id === id).name}`)){
      axios.delete(`${dbUrl}/${id}`)
      .then((response) => {
        if(response.status === 204){
          this.setState((prevState) => ({persons: prevState.persons.filter((person) => person._id !== id)}))
        }
      })
    }
  }
    
  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Luettelo state={this.state} onNameChange={this.onNameChange} onNumberChange={this.onNumberChange} onSubmit={this.onSubmit}/>
        <h2>Numerot</h2>
        <Numerot persons={this.state.persons} onDelete={this.onDelete}/>
      </div>
    )
  }
}

const Numerot = ({persons, onDelete}) => {
  return(
    <table>
    <tbody>
      {persons.map((person) => <tr key={person.name}><td>{person.name}</td><td>{person.number}</td><td><button onClick={onDelete(person._id)}>poista</button></td></tr>)}
    </tbody>
  </table>
  )
}

const Luettelo = ({state, onNameChange, onNumberChange, onSubmit}) => {
  return(
    <form onSubmit={onSubmit}>
      <div>
        nimi: <input value={state.newName} onChange={onNameChange}/>
      </div>
      <div>
        numero: <input value={state.newNumber} onChange={onNumberChange}/>
      </div>
      <div>
        <button type="submit">lisää</button>
      </div>
    </form>
  )
}

export default App
