const mongoose = require('mongoose')

const url = 'mongodb+srv://snuusi:pyYrkBPEs8JB4ht@wamp.z9roe.mongodb.net/fullstack'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String
}, 'persons')

printAllEntries = () => {
    Person
    .find({})
    .then(result => {
        result.forEach(person => {
            console.log(`${person.name} ${person.number}`)
        })
        mongoose.connection.close()
    })
}

addNewPerson = () => {
    const person = new Person({
        name: process.argv[2],
        number: process.argv[3]
      })
      
    person
        .save()
        .then(response => {
            console.log(`adding person ${person.name} number ${person.number} to the directory`)
            mongoose.connection.close()
        })
}

switch (process.argv.length) {
    case 2:
        printAllEntries()
        break;
    case 4:
        addNewPerson()
        break;
}
