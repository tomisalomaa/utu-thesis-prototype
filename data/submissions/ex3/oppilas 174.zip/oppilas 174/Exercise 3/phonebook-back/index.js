const express = require('express')
const app = express()
const cors = require('cors')
const bodyParser = require('body-parser')

app.use(cors())
app.use(bodyParser.json())
app.use(express.static('build'))

const Mongo = require('./mongo.js')

app.get('/api/persons', (request, response) => {
  Mongo.Person
    .find({}).then(result => {
      response.json(result)
    })
    .catch(error => console.log(error))
})

app.post('/api/persons', (request, response) => {
  const body = request.body

  if (body.name === undefined) return response.status(400).json({error: 'name missing'})
  if (body.number === undefined) return response.status(400).json({error: 'number missing'})

  const person = new Mongo.Person({
    name: body.name,
    number: body.number
  })

  person
    .save()
    .then(result => {
      response.json(result)
    })
    .catch(error => console.log(error))
})

app.get('/api/persons/:id', (request, response) => {
  Mongo.Person.findById(request.params.id)
    .then(person => {
      if (person) {
        response.json(person)
      } else {
        response.status(404).end()
      }
    })
    .catch(error => {console.log(error)})
})

app.delete('/api/persons/:id', (request, response) => {
  Mongo.Person.findByIdAndRemove(request.params.id)
    .then(() => {
      response.status(204).end()
    })
    .catch(error => console.log(error))
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
