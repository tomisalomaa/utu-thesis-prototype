const mongoose = require('mongoose')

const url = 'mongodb+srv://snuusi:pyYrkBPEs8JB4ht@wamp.z9roe.mongodb.net/fullstack'

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String
  }, 'persons')

exports.Person = Person
