const mongoose = require("mongoose");

const url = "mongodb+srv://fsdb:fsdb22@fullstack-phonebook.fgmsd.mongodb.net/persons"
mongoose.connect(url);

process.argv.forEach((val, index) => {});
const args = process.argv.slice(2);

const Person = mongoose.model("Person", {
  name: String,
  number: String,
  id: Number,
});

const person = new Person({
  name: args[0],
  number: args[1],
  id: Math.floor(Math.random() * (100000 - 0 + 1)) + 0,
});

person.save().then((response) => {
  if (args.length < 1) {
    console.log("puhelinluettelo: ");

    Person.find({}).then((result) => {
      result.forEach((person) => {
        console.log(person.name + " " + person.number);
      });
      mongoose.connection.close();
    });
  }
  else{
    console.log("adding person" + args[0] + " " + args[1] + " to the directory");
    mongoose.connection.close();
  }
  
});
