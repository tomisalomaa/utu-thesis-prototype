const mongoose = require("mongoose");
const url = "mongodb+srv://fsdb:fsdb22@fullstack-phonebook.fgmsd.mongodb.net/persons"
mongoose.connect(url);

const Person = mongoose.model("Person", {
    name: String,
    number: String,
    id: Number
  });


module.exports = Person