const mongoose = require('mongoose')
const url = 'mongodb+srv://petkolius:SALASANAPOISTETTU@cluster0.rveyz.mongodb.net/keltaisetsivut'

mongoose.connect(url)
console.log('Tietokanta yhdistetty')

const persSchema = new mongoose.Schema({
    name: String,
    number: String
})

const Person = mongoose.model('Person', persSchema);

module.exports = Person