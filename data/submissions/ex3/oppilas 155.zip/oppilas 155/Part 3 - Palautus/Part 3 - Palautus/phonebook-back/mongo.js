const mongoose = require('mongoose')

// Replace with the URL of your own database. Do not store the password on GitLab!
const url = 'mongodb+srv://petkolius:SALASANAPOISTETTU@cluster0.rveyz.mongodb.net/keltaisetsivut'


mongoose.connect(url)
console.log('Tietokanta yhdistetty')

const persSchema = new mongoose.Schema({
    name: String,
    number: String
  })

const Person = mongoose.model('Person', persSchema);

const person = new Person({
    name: process.argv[2],
    number: process.argv[3]
  })
/*
const formatPerson = (person) => {
    return {
      name: person.name,
      number: person.number,
      id: note._id
    }
  }
  */
  
  
 if(process.argv.length === 2) {
    console.log('Puhelinluettelo:')
    Person
    .find({})
    .then(result => {
        result.forEach(person => {
          console.log(person.name)
          console.log(person.number)
        })
        mongoose.connection.close()
    })

 }else {
    person.save().then(result => {
        console.log(`Lisätään person ${process.argv[2]}, numbberi ${process.argv[3]
        } tu tö tirektory`)
        mongoose.connection.close()
    })
 }