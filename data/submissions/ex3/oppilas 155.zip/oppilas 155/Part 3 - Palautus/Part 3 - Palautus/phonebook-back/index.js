//const http = require('http')
const express = require("express")
const app = express()
const bodyParser = require("body-parser")
const cors = require('cors')
const Person = require('./models/person')


app.use(bodyParser.json())
app.use(cors())
app.use(express.static('build'))

const formatPerson = (person) => {
    return {
        name: person.name,
        number: person.number,
        id: person._id
    }
}

app.get('/api/persons', (request, response) => {
    Person
        .find({})
        .then(persons => {
            response.json(persons.map(formatPerson))
        })
})

app.get('/api/persons/:id', (request, response) => {
  
    Person
        .findById(request.params.id)
        .then(person => {
            if (person) {
                res.json(person)
            } else {
                res.status(404).end()
            }   
        })
        .catch(error => {
        console.log(error)
        response.status(400).send({error: 'ei löydy'})
        })  
})

app.delete('/api/persons/:id',(request, response) =>{
 
    Person.findByIdAndDelete(request.params.id)
    .then(person => {
      if (person) {
        response.json(person)
      } else {
        response.status(400).end()
      }
    })
    .catch(error => {
      console.log(error)
      response.status(400).send({error: 'ei löydy'})
    })
})

app.post('/api/persons', (request, response) => {
    const body = request.body

    if(body.name === "" || body.number === ""){
        return response.status(400).json({error: 'Sisältöä puuttuu'})
    } else {

    const newPerson = new Person({
        name: String(body.name),
        number: body.number,
        id: Math.floor(Math.random() * 100000)
    })

    newPerson
        .save()
        .then(savedPerson => {
            response.json(formatPerson(savedPerson))
        })
    }
    //response.json(newPerson)
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})