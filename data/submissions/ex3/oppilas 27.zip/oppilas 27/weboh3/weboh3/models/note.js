const mongoose = require('mongoose')

const url = 'mongodb+srv://juppuu:123@cluster0.u315m.mongodb.net/myFirstDatabase?'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String
})

module.exports = Person