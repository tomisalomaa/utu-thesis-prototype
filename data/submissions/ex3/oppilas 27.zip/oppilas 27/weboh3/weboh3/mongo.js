const mongoose = require('mongoose')

const url = 'mongodb+srv://juppuu:123@cluster0.u315m.mongodb.net/myFirstDatabase?'

mongoose.connect(url)

const noteSchema = new mongoose.Schema({
    name: String,
    number: String,
    
  })
  
  const Person = mongoose.model('Person', noteSchema);

const person = new Person({
  name: '321',
  number: '3'
  
})

person
  .save()
  .then(response => {
    console.log('person saved!')
    mongoose.connection.close()
  })

Person
.find({})
.then(result => {
result.forEach(note => {
    console.log(note)
})
mongoose.connection.close()
})    