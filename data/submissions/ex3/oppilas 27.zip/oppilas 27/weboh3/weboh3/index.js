const express = require('express')
const app = express()
const bodyParser = require('body-parser')
app.use(express.static('build'))
const cors = require('cors')

app.use(cors())

app.use(bodyParser.json())

const Person = require('./models/note')

const formatNote = (person) => {
  return {
    name: person.name,
    numero: person.number,
    id: person._id
  }
}



app.get('/', (req, res) => {
  res.send('<h1>Hello World!</h1>')
})

app.get('/api/persons', (request, response) => {
  Person
    .find({})
    .then(persons => {
      response.json(persons.map(formatNote))
    })
})

app.get('/api/persons/:id', (request, response) => {
  Person
    .findById(request.params.id)
    .then(person => {
      response.json(formatNote(person))
    })
})

app.post('/api/persons', (request, response) => {
  const body = request.body
  console.log(body)
  if (body.name === undefined) {
    return response.status(400).json({error: 'content missing'})
  }

  const person = new Person({
    name: body.name,
    number: body.numero,
    id: 20
  })

  person
    .save()
    .then(savedNote => {
      response.json(formatNote(savedNote))
    })
})
  
app.delete('/api/person/:id', (request, response) => {
  const id = Number(request.params.id)
  console.log(body)
  if (body.content === undefined || body.number === undefined || persons.name.includes(body.name)) {
    return response.status(400).json({error: 'content missing'})
  }

  persons = persons.filter(person => person.id !== id)

  response.status(204).end()
})



const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})