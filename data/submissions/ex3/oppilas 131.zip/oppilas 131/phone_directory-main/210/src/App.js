import React from 'react';
import axios from 'axios';
import Form from './components/form';
import Person from './components/person';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      persons: [],
      newName: '',
      newNumber: '',
    };
  }

  addPerson = (event) => {
    event.preventDefault();
    if (
      this.state.persons.find(
        (person) => person.name.toUpperCase() === this.state.newName.toUpperCase()
      )
    ) {
      alert(`${this.state.newName} on jo luettelossa!`);
      this.setState({ persons: this.state.persons, newName: '', newNumber: '' });
      return;
    }
    const personObject = {
      name: this.state.newName,
      number: this.state.newNumber,
    };

    axios.post('/api/persons', personObject).then((response) => {
      this.setState({
        persons: this.state.persons.concat(response.data),
        newName: '',
        newNumber: '',
      });
    });
  };

  handlePersonChange = (event) => {
    this.setState({ newName: event.target.value });
  };

  handleNumberChange = (event) => {
    this.setState({ newNumber: event.target.value });
  };

  componentDidMount() {
    axios.get('/api/persons').then((response) => {
      this.setState({ persons: response.data });
    });
  }

  deletePerson = (id) => {
    const person = this.state.persons.find((person) => person.id === id);
    const name = person.name;
    const url = `/api/persons/${id}`;
    if (window.confirm(`Poistetaanko ${name}?`)) {
      axios.delete(url).then((response) => {
        this.setState({ persons: this.state.persons.filter((person) => person.id !== id) });
      });
    }
  };

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form
          state={this.state}
          addPerson={this.addPerson}
          handleNumberChange={this.handleNumberChange}
          handlePersonChange={this.handlePersonChange}
        />
        <h2>Numerot</h2>
        {this.state.persons.map((person) => (
          <Person
            key={person.id}
            person={person}
            deletePerson={() => this.deletePerson(person.id)}
          />
        ))}
      </div>
    );
  }
}

export default App;
