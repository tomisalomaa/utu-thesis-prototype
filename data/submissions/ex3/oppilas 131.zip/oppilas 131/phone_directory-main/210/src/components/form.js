import React from 'react';

const Form = ({ state, addPerson, handleNumberChange, handlePersonChange }) => {
  return (
    <form onSubmit={addPerson}>
      <div>
        nimi: <input value={state.newName} onChange={handlePersonChange} />
      </div>
      <div>
        numero: <input value={state.newNumber} onChange={handleNumberChange} />
      </div>
      <div>
        <button type="submit">lisää</button>
      </div>
    </form>
  );
};

export default Form;
