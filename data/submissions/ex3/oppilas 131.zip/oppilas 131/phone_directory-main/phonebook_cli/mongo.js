const mongoose = require('mongoose');

// DO NOT STORE IN GITHUB
const url =
  'mongodb+srv://millina:72H3TpFf7Kai993@phonebook.vslj4.mongodb.net/phonebook-people?retryWrites=true&w=majority';

mongoose.connect(url);

const Person = mongoose.model('Person', {
  name: String,
  number: String,
  id: Number,
});

if (process.argv.length === 2) {
  console.log('puhelinluettelo:');
  Person.find({}).then((result) => {
    result.forEach((p) => {
      console.log(p.name, p.number);
    });
    mongoose.connection.close();
  });
} else {
  const person = new Person({
    name: process.argv[2],
    number: process.argv[3],
    id: Math.floor(Math.random() * 1000),
  });

  person.save().then((response) => {
    console.log('person saved!');
    mongoose.connection.close();
  });
}
