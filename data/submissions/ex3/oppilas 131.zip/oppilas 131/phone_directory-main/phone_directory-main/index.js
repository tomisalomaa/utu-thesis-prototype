const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
const Person = require('./models/person');
const { default: mongoose } = require('mongoose');

app.use(cors());
app.use(express.static('build'));
app.use(bodyParser.json());

let persons = [
  {
    name: 'Arto Hellas',
    number: '040-123456',
    id: 1,
  },
  {
    name: 'Matti Tienari',
    number: '040-123456',
    id: 2,
  },
  {
    name: 'Arto Järvinen',
    number: '040-123456',
    id: 3,
  },
  {
    name: 'Lea Kutvonen',
    number: '040-123456',
    id: 4,
  },
];

const formatPerson = (person) => {
  return {
    name: person.name,
    number: person.number,
    id: person._id,
  };
};

app.get('/', (req, res) => {
  res.send('<h1>Phone Directory</h1>');
});

app.get('/api/persons', (req, res) => {
  Person.find({}).then((people) => {
    res.json(people.map(formatPerson));
  });
});

app.get('/api/persons/:id', (req, res) => {
  const id = req.params.id;
  if (!mongoose.isValidObjectId(id)) {
    res.status(404).end();
  } else {
    Person.find({ _id: id }).then((persons) => {
      if (!persons[0]) {
        res.status(404).end();
      } else {
        res.json(formatPerson(persons[0]));
      }
    });
  }
});

app.post('/api/persons', (req, res) => {
  const body = req.body;
  if (body.name === undefined || body.number === undefined) {
    return res.status(400).json({ error: 'name and/or number missing' });
  }
  Person.find({ name: body.name }).then((persons) => {
    if (persons[0]) {
      return res.status(400).json({ error: 'name must be unique' });
    } else {
      const person = new Person({
        name: body.name,
        number: body.number,
      });
      person.save().then((savedPerson) => {
        res.json(formatPerson(savedPerson));
      });
    }
  });
});

app.delete('/api/persons/:id', (req, res) => {
  const id = req.params.id;
  Person.deleteOne({ _id: id }).then(() => {
    res.status(204).end();
  });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
