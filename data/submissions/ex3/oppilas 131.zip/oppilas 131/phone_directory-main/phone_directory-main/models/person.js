const mongoose = require('mongoose');

// DO NOT STORE IN GITHUB
const url =
  'mongodb+srv://millina:72H3TpFf7Kai993@phonebook.vslj4.mongodb.net/phonebook-people?retryWrites=true&w=majority';

mongoose.connect(url);

const Person = mongoose.model('Person', {
  name: String,
  number: String,
  id: String,
});

module.exports = Person;
