const mongoose = require('mongoose')

// Replace with the URL of your own database. Do not store the password on GitLab!
const url = 'mongodb+srv://alikoodailee:4l1sekoodailee@cluster0.3bk42.mongodb.net/Webpart3'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String
})

if(process.argv[2] === undefined && process.argv[3] === undefined){
Person
  .find({})
  .then(console.log('Puhelinluettelo:'))
  .then(result => {
    result.forEach(person => {
      console.log(person.name, person.number)
      
    })
    mongoose.connection.close()
  })
}
else {
    const person = new Person({
        name: process.argv[2],
        number: process.argv[3]
    })

person
    .save()
    .then(response => {
        console.log('adding person', process.argv[2], 'number', process.argv[3], 'to the directory')
        mongoose.connection.close()
  })
}

