import axios from "axios";

const Form = ({ currentPersons, newName, newNumber, setState }) => {

    const addContact = (event) => {
        event.preventDefault()
        // Jos nimi löytyy jo listalta, ilmoita käyttäjälle ja poistu funktiosta
        if (currentPersons.some(person => person.name === newName)) {
            alert(`Ei voida lisätä nimeä. ${newName} on jo lisätty.`);
            return;
        }

        // Jos jompikumpi kentistä on tyhjä, ilmoita käyttäjälle,
        // aseta focus tyhjään kenttään ja poistu funktiosta
        if (newName === '' || newNumber === '') {
            alert(`Täytä molemmat kentät.`);
            if (newName === '') document.getElementById("name-input").focus();
            else document.getElementById("number-input").focus();
            return;
        }

        // Lisää uusi nimi ja numero listalle ja päivitä tila.
        const newPerson = { name: newName, number: newNumber };
        const persons = currentPersons.concat(newPerson);
        setState({ persons, newName: '', newNumber: '' });

        // Lisää uusi nimi ja numero palvelimelle

        axios
            .post("/api/persons", newPerson)
            .catch(error => console.error(error));

        // Asetetaan focus nimi-kenttään
        document.getElementById("name-input").focus()
    }

    const handleNameChange = (event) => {
        console.log('handleName:', event.target.value)
        setState({ newName: event.target.value })
    }

    const handleNumberChange = (event) => {
        console.log('handeNumber:', event.target.value)
        setState({ newNumber: event.target.value })
    }
    return (
        <form className="contact-form" onSubmit={addContact}>
            <div className="input-block">
                Nimi: <input id="name-input" type="text" value={newName} onChange={handleNameChange} />
            </div>
            <div className="input-block">
                Numero: <input id="number-input" type="tel" value={newNumber} onChange={handleNumberChange} />
            </div>
            <div>
                <button type="submit">Lisää</button>
            </div>
        </form>
    )

}
export default Form;