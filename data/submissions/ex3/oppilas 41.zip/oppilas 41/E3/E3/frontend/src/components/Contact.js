import axios from "axios";

export default function Person({ name, number, id, setState, currentPersons }) {

    const handleClick = () => {
        const cancel = !window.confirm(`Poistetaanko ${name}?`);
        if (cancel) return;

        // Poista henkilö nykyisestä tilasta
        const newPersons = currentPersons.filter(person => person.id !== id);
        setState({ persons: newPersons});

        // Poista henkilö palvelimelta
        axios
            .delete(`/api/persons/${id}`)
            .catch(error => console.error(error));
        
    }

    return (
        <tr className="table-row">
            <td>{name}</td>
            <td>{number}</td>
            <td><button className="delete-button" onClick={handleClick}>Poista</button></td>
        </tr>
    )
}

