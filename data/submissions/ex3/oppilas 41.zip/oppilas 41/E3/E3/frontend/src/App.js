import React from 'react';
import Contact from './components/Contact'
import Form from './components/Form';
import contactService from './services/persons'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [],
      newName: '',
      newNumber: ''
    }
    console.log('constructor')
  }

  componentDidMount() {
    console.log('did mount')
    contactService
      .getAll()
      .then(persons => {
        this.setState({ persons })
      })
      .catch(error => console.error(error));
  }

  setAppState = (obj) => {
		this.setState(obj);
	}

  render() {
    console.log('render')
    return (
      <div>
        <h1>Puhelinluettelo</h1>
        <Form
					onSubmit={this.addContact}
					currentPersons={this.state.persons}
					newName={this.state.newName}
					newNumber={this.state.newNumber}
					setState={this.setAppState}
				/>
        <h2>Yhteystiedot:</h2>
        <table style={{ maxWidth: 450 }}>
					<tbody>
						{
							this.state.persons.map(person =>
								<Contact key={person.name} name={person.name} number={person.number} id={person.id} setState={this.setAppState} currentPersons={this.state.persons} />
							)
						}
					</tbody>
				</table>

      </div>
    )
  }
}
export default App