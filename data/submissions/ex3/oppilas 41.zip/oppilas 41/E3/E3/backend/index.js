const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const cors = require('cors')

app.use(cors())
app.use(bodyParser.json())
app.use(express.static('build'))

const logger = (request, response, next) => {
  console.log('Method:', request.method)
  console.log('Path:  ', request.path)
  console.log('Body:  ', request.body)
  console.log('---')
  next()
}

app.use(logger)

let persons = [
  {
    id: 1,
    name: 'Arto Hellas',
    number: '040-123456',
  },
  {
    id: 2,
    name: 'Martti Tienari',
    number: '040-123456',
  },
  {
    id: 3,
    name: 'Arto Järvinen',
    number: '040-123456',
  },
  {
    id: 4,
    name: 'Lea Kutvonen',
    number: '040-123456',
  }
]

// GET kaikki
app.get('/api/persons', (request, response) => {
  response.json(persons)
})

// GET yksi
app.get('api/persons', (request, response) => {
  const id = Number(request.params.id)
  const person = persons.find(person => person.id === id)

  if (person) {
    response.json(person)
  } else {
    response.status(404).end()
  }
})

// DELETE
app.delete('/api/persons/:id', (request, response) => {
  const id = Number(request.params.id)
  persons = persons.filter(person => person.id !== id)

  response.status(204).end()
})

// Järjestyksellinen id 
const generateId = () => {
  const maxId = persons.length > 0 ? persons.map(n => n.id).sort((a, b) => a - b).reverse()[0] : 1
  return maxId + 1
}

// POST
function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

app.post('/api/persons', (request, response) => {
  const body = request.body

  // Tarkistaa onko annettu vaadittavat tiedot!
  if (!body.name) {
    return response.status(400).json({ error: 'no name!' })
  }
  if (!body.number) {
    return response.status(400).json({ error: 'no number"' })
  }

  // Tarkistetaan onko annettu nimi uniikki:
  if (persons.some(person => person.name === body.name)) {
    return response.status(400).json({ error: 'the name to be added already exists!' })
  }

  // Luodaan uusi henkilö
  const person = {
    id: getRandomInt(1000),
    name: body.name,
    number: body.number
  }

  persons = persons.concat(person)

  response.json(person)
})

const error = (request, response) => {
  response.status(404).send({ error: 'unknown endpoint' })
}

app.use(error)

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})