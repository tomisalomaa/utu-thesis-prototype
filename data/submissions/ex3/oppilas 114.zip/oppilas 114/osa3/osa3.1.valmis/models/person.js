const mongoose = require('mongoose')

const url = 'mongodb+srv://lauri:ztDOwtTckxRtn6rx@cluster0.f4r6l.mongodb.net/fullstack-persons'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String
})

module.exports = Person