const mongoose = require('mongoose')

const url = 'mongodb+srv://lauri:ztDOwtTckxRtn6rx@cluster0.f4r6l.mongodb.net/fullstack-persons'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String
})

if (process.argv.length === 4) {
  
  const person = new Person({
    name: process.argv[2],
    number: process.argv[3]
  })
  console.log(`adding person ${process.argv[2]} number ${process.argv[3]} to the directory`)

  person
    .save()
    .then(response => {
      mongoose.connection.close()
    })

}

else if (process.argv.length === 2) {

  Person
    .find({})
    .then(result => {
      console.log('puhelinluettelo:')
      result.forEach(person => {
        console.log(person.name, person.number)
      })
      mongoose.connection.close()
    })

}

else {
  console.log('Syötteestä puuttuu nimi tai numero')
  mongoose.connection.close()
}