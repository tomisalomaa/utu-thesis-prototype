const mongoose = require("mongoose");

const url = "mongodb+srv://blank:level1@cluster0.g4981.mongodb.net/myFirstDatabase";

mongoose.connect(url)



const Note = mongoose.model('Note', {
  name: String,
  number: String,
  important: Boolean
})

if(process.argv.length==4){

const note = new Note({
  name: process.argv[2],
  number: process.argv[3],
  important: true
})

note
  .save()
  .then(response => {
    console.log('adding person ' + process.argv[2] + " number " + process.argv[3] + " to the directory");
    mongoose.connection.close()
  })
}
else{
    console.log("puhelinluettelo:");
    Note
    .find({})
    .then(notes=>{
        
        notes.map((note)=>{console.log(note.name + " " + note.number + "")})
        mongoose.connection.close()
    })
    
}
