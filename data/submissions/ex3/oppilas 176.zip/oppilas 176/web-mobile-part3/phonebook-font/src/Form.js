import React from 'react';

function Form(props){

    return(
        <form>
          <div>
            nimi: <input value={props.olio.state.newName} onChange={props.olio.handleLetter}/>
          </div>
          <div>
            numero: <input value={props.olio.state.number} onChange={props.olio.handleNumber}/>
          </div>
          <div>
            <button type="submit" onClick={props.olio.handleClick}>lisää</button>
          </div>
        </form>

    );

}

export default Form;