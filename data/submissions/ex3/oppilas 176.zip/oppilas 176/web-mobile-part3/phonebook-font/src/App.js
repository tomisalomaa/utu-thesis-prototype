import React from 'react';
import Entry from "./Entry.js";
import Form from "./Form.js";
import axios from "axios";

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      persons: [
        { name: 'Arto Hellas',
          number: "040-123456"
      }
      ],
      newName: '',
      number: ''
    }
  }

  componentDidMount() {
    axios
      .get('http://localhost:3001/api/persons')
      .then(response => {
        console.log(response.data)
        this.setState({ persons: response.data })
      }).catch(console.log("error"));
  }

  handleClick = (event) => {
    event.preventDefault();
    console.log(this.state.number);
    if(this.state.persons.find(element => element.name === this.state.newName || this.state.number==="" || this.state.newName==="" || element.number===this.state.number)){
      return;
    }
    axios.post('http://localhost:3001/api/persons', {name: this.state.newName, number: this.state.number});
    this.setState({persons: [...this.state.persons, {name: this.state.newName, number: this.state.number,}]});
    this.setState({newName: ""});
    this.setState({number: ""});
    
  } 

  handleNumber = (event) => {
    let good = true;
    for(let i=0;i<event.target.value.length;i++){
      if(!isNaN(event.target.value.charAt(i)) || event.target.value.charAt(i)==="-"){

      }
      else{
        good = false;
      }
    }
    if(good){
      this.setState({number: event.target.value});
    
    }
  }
  
  handleLetter = (event) => {
    let good = true;
    for(let i=0;i<event.target.value.length;i++){
      if(isNaN(event.target.value.charAt(i)) || event.target.value.charAt(i)===" "){

      }
      else{
        good = false;
      }
    }
    if(good){
      this.setState({newName: event.target.value});
    
    }
  }

  deletePerson = (id) => {
      for(let i=0; i<this.state.persons.length;i++){
        console.log(this.state.persons[i].id + " " +id);
        if(this.state.persons[i].id===id){
          axios.delete(`http://localhost:3001/api/persons/${id}`);
          
        } 
      }
      this.setState(prev=>{
        return prev.persons.filter((element)=>{
          return element.id !== id;
        })

      });
        
      window.location.reload(false);

  }

  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Form olio={this} />
        <h2>Numerot</h2>
        <table>
        <tbody>
        {this.state.persons.map(prop=>{
          console.log(prop);
          
           return(
           <Entry key={prop.name} id={prop.id} name={prop.name} number={prop.number} delete={this.deletePerson}/>
           );
        })}
        </tbody>
        </table>
      </div>
    )
  }
}
export default App;