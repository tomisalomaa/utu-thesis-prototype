const mongoose = require('mongoose')

const url = 'mongodb+srv://blank:level2@cluster1.swuyy.mongodb.net/myFirstDatabase'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String,
  important: Boolean
})

module.exports = Person