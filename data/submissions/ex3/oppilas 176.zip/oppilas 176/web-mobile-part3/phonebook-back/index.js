const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require("cors");


const Person = require("./models/note");

app.use(cors());
app.use(express.static('build'));
app.use(bodyParser.json());

let api = {
    persons: [
        {
            name: "Arto Hellas",
            number: "040-123456",
            id: 1
         },
        {
            name: "Martti Tienari",
            number: "040-123456",
            id: 2
        },
        {
            name: "Arto Järvinen",
            number: "040-123456",
            id: 3
        },
        {
            name: "Lea Kutvonen",
            number: "040-123456",
            id: 4
        }
    ]

}


    
app.get('/', (req, res) => {
    res.send('<h1>Hello World!</h1>')
  });


  /*
  app.get("/api/persons", (request, response) => {
      response.json(api.persons);
  });
  */
  app.get('/api/persons', (request, response) => {
    Person
      .find({}, {__v: 0})
      .then(persons => {
        response.json(persons.map(formatPerson))
      })
  })

  const formatPerson = (person) =>{
    const formattedPerson = {...person._doc, id: person._id}
    delete formattedPerson._id
    delete formattedPerson.__v
    return formattedPerson
  }


  
  /*
  app.get('/api/persons/:id', (request, response) => {
    const id = Number(request.params.id)
    const person = api.persons.find(person => person.id === id)
  
    if ( person ) {
      response.json(person)
    } else {
      response.status(404).end()
    }
  });
  */
  app.get("/api/persons/:id", (request, response)=>{
    Person
    .findById(request.params.id)
    .then(note=>{
      response.json(formatNote(note))
    })
  })


  /*
  app.delete('/api/persons/:id', (request, response) => {
    const id = Number(request.params.id);
    api.persons = api.persons.filter(person => person.id !== id);
    
    response.status(204).end()
  });
  */
  app.delete("/api/persons/:id", (request, response)=>{
    Person
    .findByIdAndRemove(request.params.id)
    .then(result => {
      response.status(204).end()
    })
    .catch(error=>{
      response.status(400).send({error: "malformatted id"})
    })
  })





  /*
  app.post('/api/persons', (request, response) => {
    const person = request.body;
    if(person.name.length!=0 && person.number.length!=0){
        person.id=Math.floor(Math.random()*1000000);
        const person2 = api.persons.find(not => not.name===person.name);
        if(person2){
            response.json({error: "name must be unique"});
        }
        else{
            console.log(person);
            response.json(person);
            api.persons = [...api.persons, person];
            console.log(api.persons);
    }
    }

  });
  */
  app.post('/api/persons', (request, response) => {
    const body = request.body
  
    if (body.name === undefined ||body.number === undefined) {
      return response.status(400).json({error: 'content missing'})
    }
  
    const person = new Person({
      name: body.name,
      important: body.important || false,
      number: body.number
    })
  
    person
      .save()
      .then(savedPerson => {
        response.json(formatPerson(savedPerson))
      })
  })

  
  const PORT = process.env.PORT || 3001;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
  });
