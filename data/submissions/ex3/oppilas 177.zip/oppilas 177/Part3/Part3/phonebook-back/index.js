
  const express = require('express')
  const app = express()
  const bodyParser = require('body-parser')
  const cors = require('cors')
  const Person = require('./models/person')

  const formatPerson = (Person) => {
    return {
      name: Person.name,
      number: Person.number,
      id: Person._id
    }
  }

  app.use(express.static('build'))
  app.use(cors())
  app.use(bodyParser.json())
    
/*let persons = [
    {
      name: "Arto Hellas",
      number: "040-123456",
      id: 1
    },
    {
      name: "Martti Tienari",
      number: "040-123456",
      id: 2
    },
    {
      name: "Arto Järvinen",
      number: "040-123456",
      id: 3
    },
    {
      name: "Lea Kutvonen",
      number: "040-123456",
      id: 4
    }
  ]


  const generateId = () => {
    return Math.floor(Math.random() * 1000000);
  }*/

  app.post('/api/persons', async (request, response) => {
    const body = request.body
    
    if (body.name === undefined || body.number === undefined)  {
      return response.status(400).json({error: 'Nimi tai numero puuttuu'})
    }

    const oldPerson = await Person.findOne({name: body.name})

    if(oldPerson) {
      return response.status(400).json({error: 'Henkilö löytyy jo'})
    }

  
    const person = new Person({
      name: body.name,
      number: body.number
    })  


    person
    .save()
    .then(savedPerson => {
      console.log('person saved!')
      response.json(formatPerson(savedPerson))
    })
    
    /*if ( persons.find(person => person.name === body.name) ) {
      return response.status(400).json({error: 'Henkilö löytyy jo'})
    } 
    const person = {
      name: body.name,
      number: body.number,
      id: generateId()
    }

    persons = persons.concat(person)
    response.json(person)*/
  })

  /*app.get('/', (req, res) => {
    res.send('<h1>Hello World!</h1>')
  })*/
  
  app.get('/api/persons', (req, res) => {
    //res.json(persons)
    Person
    .find({})
    .then(persons => {
      res.json(persons.map(formatPerson))
    })
  })
  
  app.get('/api/persons/:id', (request, response) => {
    /*const id = Number(request.params.id)
    const person = persons.find(person => person.id === id)
    if ( person ) {
      response.json(person)
    } else {
      response.status(404).end()
    }*/
    const id = request.params.id
    console.log(`Find by id: ${request.params.id}`)
    Person
    .findById(id)
    .then(person => {
      if (person) {
        response.json(formatPerson(person))
      } else {
        response.status(404).end()
      }
    })
    .catch(error => {
      console.log(error)
      response.status(400).send({ error: 'malformatted id' })
    })
  })

  app.delete('/api/persons/:id', (request, response) => {
    const id = request.params.id
    /*persons = persons.filter(person => person.id !== id)*/
    console.log(`Delete by id: ${id}`)

    Person.deleteOne( { _id : id }).then(result => {
      response.status(204).end()
    }).
    catch(error => {
      console.log(error)
      response.status(400).send({ error: 'malformatted id' })
    })
  
  })
  
  app.get('*', (request, response) => {
    response.status(404).end()
  })

  const PORT = process.env.PORT || 3001
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
  })