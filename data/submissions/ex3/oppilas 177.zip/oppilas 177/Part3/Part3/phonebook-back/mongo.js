const mongoose = require('mongoose')

// Replace with the URL of your own database. Do not store the password on GitLab!
  const url = 'mongodb+srv://WebProgram:FullStack2022@ssidbcluster.cykx7.mongodb.net/fullstack-persons'

mongoose.connect(url)

  const Person = mongoose.model('Person', {
    name: String,
    number: String,
  }, 'persons')

  /*process.argv.forEach((val, index) => {
    console.log(`${index}: ${val}`);
  });*/

  if(process.argv.length == 4) 
  {
const person = new Person({
  name: process.argv[2],
  number: process.argv[3]
})

console.log(`adding person ${person.name} number ${person.number} to the directory`);
person
  .save()
  .then(response => {
    mongoose.connection.close()
    process.exit(1);
  })
  }
  else if(process.argv.length == 2)  {
    console.log('Puhelinluettelo');
    Person
    .find({})
    .then(persons => {
        persons.forEach((person) => {
        console.log(`${person.name} ${person.number}`)
        });
        mongoose.connection.close()
        process.exit(1);
    })
  }
  else {
    console.log(`Erronous amount of parameters.`); 
    console.log(`You should call app with 'node mongo.js' to show all persons in phonebook or `);
    console.log(`or with 'node mongo.js "wanted name" "phonenumber"'. `);
    console.log(`"" are needed if there is space in name or phonenumber. `);
    process.exit(1);
  }
  