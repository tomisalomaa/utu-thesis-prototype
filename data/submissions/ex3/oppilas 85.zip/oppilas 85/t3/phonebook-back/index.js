const express = require('express')
const app = express()
const bodyParser = require('body-parser')

app.use(bodyParser.json())

const api = require('./mongo.js')

app.get('/api/persons', (req, res) => {
    api.get()
	.then(r => {
	    res.status(200).send(r)
	})
})

app.delete('/api/persons/:id', (req, res) => {
    api.delete(req.params.id)
	.then(r => {
	    res.status(200).send()
	})
})

app.post('/api/persons', (req, res) => {
    const b = req.body
    api.add(b.name, b.number, b.id)
	.then(r => {
	    res.status(200).send(b)
	})
})

//this is never used
app.get('/api/persons/:id', (req, res) => {
    api.getSingle(req.params.id)
	.then(r => {
	    res.status(200).send(r)
	})
})

const PORT = 3001
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
