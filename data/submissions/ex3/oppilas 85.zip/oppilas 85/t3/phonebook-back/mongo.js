const mongoose = require('mongoose')

require('dotenv').config()

const url = process.env.MONGODB_URI

const Person = mongoose.model('Person', {
    name: String,
    number: String,
    id: Number
})

module.exports = {
    add: async (nam, num, id) => {
	await mongoose.connect(url)

	const person = new Person({
	    name: nam,
	    number: num,
	    id: id
	})

	await person.save()
	  .then(response => {
	    mongoose.connection.close()
	})
    },

    get: async () => {
	await mongoose.connect(url)
	return Person.find()
	mongoose.connection.close()
    },

    delete: async (id) => {
	await mongoose.connect(url)
	Person.deleteOne({ id: id })
	    .then(response => {
		mongoose.connection.close()
	    })
    },

    //this is never used
    getSingle: async (id) => {
	await mongoose.connect(url)
	return Person.find({ id: id })
	mongoose.connection.close()
    }
}
