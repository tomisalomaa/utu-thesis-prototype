const mongoose = require('mongoose')

require('dotenv').config()

const url = process.env.MONGODB_URI

const nam = process.argv[2]
const num = process.argv[3]

const Person = mongoose.model('Person', {
  name: String,
  number: String
})

async function main() {
    await mongoose.connect(url)

    if (nam === undefined) {
	const people = await Person.find()

	console.log("puhelinluettelo:")
	people.forEach(p => {
	    console.log(p.name + " " + p.number)
	})
    } else {
	const person = new Person({
	    name: nam,
	    number: num
	})

	await person.save()
	  .then(response => {
	    console.log('adding person '+nam+' number '+num+' to the directory')
	  })
    }

    mongoose.connection.close()
}

main()
