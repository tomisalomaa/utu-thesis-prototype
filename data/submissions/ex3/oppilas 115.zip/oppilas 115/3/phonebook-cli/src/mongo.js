import dotenv from 'dotenv';
import mongoose from 'mongoose';

const Contact = mongoose.model("Contact", { name: String, number: String });

const createContactEntryObject = (name, number) => {
	if (!(name && number)) {
		throw new Error("Name and number required");
	}

	return new Contact({
		name,
		number
	});
};

const openDBConnection = async (mongoose, dbConnectionUrl) => {
	await mongoose.connect(dbConnectionUrl);
	console.log("DB connection opened");
};

const closeDBConnection = async (mongoose) => {
	await mongoose.connection.close();
	console.log("DB connection closed");
};

const handle = async () => {

	dotenv.config();

	const args = process.argv;
	const env = process.env;

	const {
		MONGO_USER,
		MONGO_PASSWORD,
		MONGO_CLUSTER,
		MONGO_DB,
		MONGO_COLLECTION
	} = env;

	if (!(
		MONGO_USER &&
		MONGO_PASSWORD &&
		MONGO_CLUSTER &&
		MONGO_DB &&
		MONGO_COLLECTION
	)) {
		return console.error("Env variables missing");

	}

	const dbConnectionUrl = `mongodb+srv://${MONGO_USER}:${MONGO_PASSWORD}@${MONGO_CLUSTER}.mongodb.net/${MONGO_DB}`;

	try {
		await openDBConnection(mongoose, dbConnectionUrl);
	} catch (error) {
		return console.error(error);
	}

	const listEntries = async () => {

		try {

			const result = await Contact.find({});

			console.log("\n");
			console.log("puhelinluettelo:");

			for (const note of result) {
				console.log(`${note.name} ${note.number}`);
			}

			console.log("\n");

			await closeDBConnection(mongoose);

		} catch (error) {
			return console.error(error);
		}

	};

	const addEntry = async (name, number) => {
		try {

			console.log(`adding person ${name} number ${number} to the directory`)

			const entry = createContactEntryObject(name, number);

			await entry.save();

			await closeDBConnection(mongoose);

		} catch (error) {
			return console.error(error);
		}
	};

	if (args.length === 2) {
		return listEntries();
	} else if (args.length === 4) {

		const name = args[2];
		const number = args[3];

		return addEntry(name, number);
	} else {
		return console.error("Invalid CLI arguments");
	}
};

handle().then(() => {
	console.log("script terminated");
});