import LayoutRow from "./LayoutRow";
import ListRow from "./ListRow";

const List = (props ) => {
	return (
		<LayoutRow>
			{props.names.map((row, index) => (
				<ListRow key={index}
						 name={row.name}
						 number={row.number}
						 onClick={(event) => props.onRowDeleteClick(event, row._id, row.name)}
				/>
			))}
		</LayoutRow>
	)
};

export default List;