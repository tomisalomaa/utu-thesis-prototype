import { useEffect, useState } from 'react';
import axios from 'axios';

import PageTitle from "./components/PageTitle";
import Form from "./components/Form";
import List from "./components/List";

import styles from './App.module.css';

const apiUrl = '/api/persons';

const App = () => {

  const [newPersonName, setNewPersonName] = useState('');
  const [newPersonNumber, setNewPersonNumber] = useState('');
  const [persons, setPersons] = useState([]);

  useEffect(() => {
  	updatePersonsList();
  }, []);

  const updatePersonsList = () => {
	  axios.get(apiUrl)
		  .then((result) => {
			  setPersons(result.data);
		  })
		  .catch((error) => {
			  return console.error(error);
		  })
  };

  const personAlreadyExists = () => {
  	return persons.find((person) => person.name === newPersonName || person.number === newPersonNumber) !== undefined;
  };

  const onFormSubmit = (event) => {

  	event.preventDefault();

  	if (personAlreadyExists()) {
  		return alert('Name or number already in use');
	}

  	axios.post(apiUrl, {
  		name: newPersonName,
		number: newPersonNumber
  	}).then(() => {
  		updatePersonsList();
	}).catch((error) => {
		return console.error(error);
	});

  };

	const onRowDeleteClick = (event, rowId, name) => {
		event.preventDefault();

		if (!window.confirm(`Poistetaanko ${name}?`)) {
			return;
		}

		axios.delete(`${apiUrl}/${rowId}`)
			.then(() => {
				updatePersonsList();
			})
			.catch((error) => {
				return console.error(error);
			});

	};

	/**
	 * Submit form when enter is pressed
	 */
	const onKeyPress = (event) => {
  	if (event.key === 'Enter') {
  		onFormSubmit(event);
  	}
  };

  const onNewNameChange = (event) => {
  	event.preventDefault();
  	setNewPersonName(event.currentTarget.value);
  };

  const onNewNumberChange = (event) => {
  	event.preventDefault();
  	setNewPersonNumber(event.currentTarget.value);
  }

  return (
    <div className={styles.App}>

		<PageTitle value={'Puhelinluettelo'} />

		<Form newPersonName={newPersonName}
			  newPersonNumber={newPersonNumber}
			  onNewPersonNameChange={onNewNameChange}
			  onNewPersonNumberChange={onNewNumberChange}
			  onKeyPress={onKeyPress}
			  onSubmit={onFormSubmit}
		/>

		<PageTitle value={'Numerot'} />

		<List names={persons} onRowDeleteClick={onRowDeleteClick} />

    </div>
  );
};

export default App;
