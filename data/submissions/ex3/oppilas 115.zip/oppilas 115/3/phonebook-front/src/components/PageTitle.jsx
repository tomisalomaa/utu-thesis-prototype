import styles from './PageTitle.module.css';

const PageTitle = (props) => {
	return (
		<h1 className={styles.PageTitle}>
			{props.value}
		</h1>
	);
};

export default PageTitle;