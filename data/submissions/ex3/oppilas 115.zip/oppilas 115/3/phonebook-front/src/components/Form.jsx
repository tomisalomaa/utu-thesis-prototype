import LayoutRow from "./LayoutRow";

import SubmitButton from "./SubmitButton";

import styles from './Form.module.css';

const Form = (props) => {
	return (
		<LayoutRow>
			<div className={styles.FormRow}>
				Nimi:
				<input type={'text'}
					   value={props.newPersonName}
					   onChange={props.onNewPersonNameChange}
					   onKeyPress={props.onKeyPress}
				/>
			</div>
			<div className={styles.FormRow}>
				Numero:
				<input type={'text'}
					   value={props.newPersonNumber}
					   onChange={props.onNewPersonNumberChange}
					   onKeyPress={props.onKeyPress}
				/>
			</div>
			<div className={styles.FormRow}>
				<SubmitButton onClick={props.onSubmit} />
			</div>
		</LayoutRow>
	);
};

export default Form;