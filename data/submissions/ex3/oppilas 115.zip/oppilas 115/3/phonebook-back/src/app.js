import express from 'express';
import parser from 'body-parser';
import cors from 'cors';

import router from "./router.js";

const app = express();

const enableMiddleware = (app) => {

	app.use(express.static('front-end-build'));

	app.use(cors());

	app.use(parser.urlencoded({ extended: true }));
	app.use(parser.json());

	app.use('/api/persons', router);

	app.use((req, res) => { res.status(500).send('Route not found'); })

};

enableMiddleware(app);

app.listen(process.env.PORT || 3001, () => {
	console.log(
		`Server listening on port ${3001}`
	);
});