import mongoose  from 'mongoose';
import dotenv from 'dotenv';

import { generateUserId } from "./lib.js";

const Contact = mongoose.model("Contact", {
	_id: String,
	name: String,
	number: String
});

const createContactEntryObject = (name, number) => {
	if (!(name && number)) {
		throw new Error("Name and number required");
	}

	const _id = generateUserId();

	return new Contact({
		_id,
		name,
		number
	});
};

const openDBConnection = async (mongoose, dbConnectionUrl) => {

	if (!dbConnectionUrl) {
		throw new Error("Invalid db connection  url");
	}

	await mongoose.connect(dbConnectionUrl);
	console.log("DB connection opened");
};

const closeDBConnection = async (mongoose) => {
	await mongoose.connection.close();
	console.log("DB connection closed");
};

dotenv.config();

const env = process.env;

const {
	MONGO_USER,
	MONGO_PASSWORD,
	MONGO_CLUSTER,
	MONGO_DB,
	MONGO_COLLECTION
} = env;

if (!(
	MONGO_USER &&
	MONGO_PASSWORD &&
	MONGO_CLUSTER &&
	MONGO_DB &&
	MONGO_COLLECTION
)) {
	throw new Error("Invalid env");
}

const dbConnectionUrl = `mongodb+srv://${MONGO_USER}:${MONGO_PASSWORD}@${MONGO_CLUSTER}.mongodb.net/${MONGO_DB}`;

const getPersons = async () => {

	await openDBConnection(mongoose, dbConnectionUrl);

	const result = await Contact.find({});

	await closeDBConnection(mongoose);

	return result;
};

const getPerson = async (_id) => {

	await openDBConnection(mongoose, dbConnectionUrl);

	const result = await Contact.find({ _id });

	await closeDBConnection(mongoose);

	return result;
};

const removePerson = async (_id) => {

	await openDBConnection(mongoose, dbConnectionUrl);

	await Contact.findOneAndDelete({ _id });

	await closeDBConnection(mongoose);
};

const addPerson = async ({ name, number }) => {
	await openDBConnection(mongoose, dbConnectionUrl);

	if (!(name && number)) {
		throw new Error('name and phone number required');
	}

	if ((await Contact.find({ name })).length !== 0) {
		throw new Error("name already in use");
	}

	if ((await Contact.find({ number })).length !== 0) {
		throw new Error("number already in use");
	}

	const contact = createContactEntryObject(name, number);

	await contact.save();

	await closeDBConnection(mongoose);
};

export const controller = {
	getPersons,
	getPerson,
	addPerson,
	removePerson
};