export const generateUserId = () => {
	return Math.floor(Math.random() * 99999999);
};