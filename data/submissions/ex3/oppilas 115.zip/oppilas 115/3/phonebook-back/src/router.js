import express from "express";

import { controller } from "./controller.js";

const router = express.Router();

router.get('/', async (req, res, next) => {
	return res.json(await controller.getPersons());
});

router.get('/:id', async (req, res, next) => {
	const { params } = req;
	const { id } = params;
	const result = await controller.getPerson(id);

	if (!result || result.length === 0) {
		return res.status(404).json({ error: "Not found" });
	}

	return res.json(result);
});

router.post('/', async (req, res, next) => {
	const { body } = req;
	const { name, number } = body;

	try {
		await controller.addPerson({ name, number });
	} catch (error) {
		return res.status(400).json({ error: error.message });
	}
	return res.json({ message: "Ok" });
});

router.delete('/:id', async (req, res, next) => {
	const { params } = req;
	const { id } = params;

	await controller.removePerson(id);
	return res.json({ message: "Ok" });
});

export default router;