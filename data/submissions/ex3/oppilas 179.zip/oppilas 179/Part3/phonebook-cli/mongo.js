const mongoose = require('mongoose')

const url = 'mongodb+srv://<username>:<password>@cluster0.sflvg.mongodb.net/phonebook-cli'

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String,
})

var arguments = process.argv

if(arguments[2] !== undefined && arguments[3] !== undefined) {
	const person = new Person({
	name: arguments[2],
	number: arguments[3],
})
    person
      .save()
      .then(response => {
         console.log('adding person ' +person.name+ ' number ' +person.number+' to the directory')
         mongoose.connection.close()
   })
} else {
	Person
      .find({})
      .then(result => {
	     console.log('puhelinluettelo:')
         result.forEach(person => {
            console.log(person.name+ ' ' +person.number)
      })
    mongoose.connection.close()
    })
}



