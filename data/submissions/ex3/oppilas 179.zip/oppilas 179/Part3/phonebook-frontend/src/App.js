import React from 'react';

import Form from './components/Form'
import Directory from './components/Directory'

import personService from './services/persons'

class App extends React.Component {
	constructor(props) {
    	super(props)
    	this.state = {
      		persons: [
        	],
      	newName: '',
	  	newNumber: ''
    	};
  	}	
	
    componentDidMount() {
    	personService
      	.getAll()
      	.then(response => {
        this.setState({ persons: response })
      	})
  	}

	addName = (event) => {
		event.preventDefault()
		
		if((this.state.persons.find(a => a.name.valueOf() === this.state.newName.valueOf()) === undefined) 
		&& (this.state.persons.find(a => a.number.valueOf() === this.state.newNumber.valueOf()) === undefined) ){
		
    	const personObject = {
    		name: this.state.newName,
			number: this.state.newNumber,
  		} 

		personService
    	.create(personObject)
    	.then(newPerson => {
      		this.setState({
        	persons: this.state.persons.concat(newPerson),
    		newName: '',
			newNumber: ''
      	})
    })
	} else {
		alert('Ei voi syöttää samoja tietoja toiseen kertaan!')
		}
  	}

	handleChangeName = (event) => {
		const value = event.target.value;
    	this.setState({ 
			newName: value
 		})	
  	}

	handleChangeNumber = (event) => {
		const value = event.target.value;
    	this.setState({ 
			newNumber: value
 		})	
  	}

	handleRemovePerson = (id, name, event) => {
		if (window.confirm("Poistetaanko "+name+ "?")) {
			personService
    		.remove(id, event)
    		.then(response => {
				const persons = this.state.persons.filter(n => n.id !== id) 
      			this.setState({
        		persons: persons
      			})
    		})
		}
	}

 	render() {
    	return (
      		<div>
        		<h2>Puhelinluettelo</h2>
				<Form props = {this} person = {this.state}/>
        		<h2>Numerot</h2>
				<Directory persons = {this.state.persons} props = {this}/>
      		</div>
    	)
  	}
}

export default App
