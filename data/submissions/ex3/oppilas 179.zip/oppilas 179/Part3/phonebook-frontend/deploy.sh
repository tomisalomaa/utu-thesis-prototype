#!/bin/sh

npm run build
rm -rf ../../v2/phonebook_frontend/build
cp -r build ../../v2/phonebook_frontend/

chmod u+x deploy.sh