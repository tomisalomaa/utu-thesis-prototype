const mongoose = require('mongoose')

const url = 'mongodb+srv://<username>:<password>@cluster0.sflvg.mongodb.net/fullstack'

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String,
    //id: Number
})

module.exports = Person
