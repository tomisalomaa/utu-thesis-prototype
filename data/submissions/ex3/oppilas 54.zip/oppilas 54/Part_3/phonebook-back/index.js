const http = require('http')
const { response } = require('express')
const express = require('express')
const app = express()
const bodyParser = require('body-parser')

let persons = [
    {
        name: "Iris Kirjalainen",
        number: "0443563561",
        id: 1
    },
    {
        name: "Salla Sipipipi",
        number: "0401232345",
        id: 2
    },
    {
        name: "Joel Lentonen",
        number: "0447896543",
        id: 3
    },
    {
        name: "Jari Lehto",
        number: "0443789762",
        id: 4
    },
    {
        name: "Jadena Tuominen",
        number: "0403998276",
        id: 5
    }
]
app.get('/api/persons', (req,res) => {
    res.json(persons)
})
app.get('/api/persons/:id', (req,res) => {
    const id = Number(req.params.id)
    const person = persons.find(person => person.id === id)

    if (person) {
        res.json(person)
    }else{
        res.status(404).end()
    }
})
app.delete('/api/persons/:id', (req,res) => {
    const id = Number(req.params.id)
    persons = persons.filter(person => person.id !== id)

    res.status(204).end()
})
app.use(bodyParser.json())
const generateId = () => {
    const id = Math.floor(Math.random()* 10000 ) + 10
    return id
}
app.post('/api/persons', (req,res) => {

    const body = req.body
    if (body.name === undefined || body.number === undefined){
        return res.status(400).json({error: 'name or number missing'})
    }

    if (persons.some(person => person.name === body.name)) {
        return res.status(400).json({error: 'name already exists'})
    }
    

    const person = {
        name: body.name,
        number: body.number,
        id: generateId()
    }

    persons = persons.concat(person)
    res.json(person)

})
const port = 3001
app.listen(port)
console.log('Hyvin toimii. :)')