const mongoose = require('mongoose');

// The url below does NOT work, because the password is wrong!
const url = 'mongodb+srv://fullstack:insertpasswordhere@cluster0.skcup.mongodb.net/fullstack-people';

mongoose.connect(url);

const Person = mongoose.model('Person', {
  name: String,
  number: String
});

if (process.argv[2] === undefined) {
  Person
    .find({})
    .then(result => {
      console.log('puhelinluettelo:');
      result.forEach(person => {
        console.log(person);
      });
      mongoose.connection.close();
    });
} else {
  const name = process.argv[2];
  const number = process.argv[3];
  console.log(`adding person ${name} number ${number} to the directory`);

  const person = new Person({
    name: name,
    number: number
  });

  person
    .save()
    .then(response => {
      mongoose.connection.close();
    });
}
