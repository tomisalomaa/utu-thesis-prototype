const mongoose = require('mongoose')

const USERNAME = 'vijoni'
const PASSWORD = ''
const DATABASE = 'Cluster0'

const url = 'mongodb+srv://' + USERNAME + ':' + PASSWORD + '@cluster0.wp3lv.mongodb.net/' + DATABASE

mongoose.connect(url)

const Person = mongoose.model('Person', {
  name: String,
  number: String
})

if (process.argv.length < 4) {
  Person
    .find({})
    .then(result => {
      console.log(result)
      mongoose.connection.close()
    })
  return
}

const person = new Person({
  name: process.argv[2],
  number: process.argv[3]
})


person
  .save()
  .then(response => {
    console.log('person saved!')
    mongoose.connection.close()
  })