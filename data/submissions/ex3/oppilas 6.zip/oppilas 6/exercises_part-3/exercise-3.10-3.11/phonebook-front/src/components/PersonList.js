import React from "react"

const PersonList = ({ persons, removePerson }) => {
  return (
    <table>
      <tbody>
        {persons.map(person => 
          <Person 
            key={person.name} 
            person={person} 
            removePerson={removePerson(person.id)}
          />
        )}
      </tbody>
    </table>
  )
}

const Person = ({ person, removePerson }) => {
  return (
  <tr>
    <td className="entry">{person.name}</td>
    <td className="entry">{person.number}</td>
    <td className="entry"><button onClick={removePerson}>poista</button></td>
  </tr>
  )
}

export default PersonList