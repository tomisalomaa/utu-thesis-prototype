const mongoose = require("mongoose")
const url = 'mongodb+srv://Luuka:<asdasdasdasd>@koulu.fuvk0.mongodb.net/fullstack-phonebook'

mongoose.connect(url)

const Person = mongoose.model('Person', {
    name: String,
    number: String,
    id: String
})

module.exports = Person