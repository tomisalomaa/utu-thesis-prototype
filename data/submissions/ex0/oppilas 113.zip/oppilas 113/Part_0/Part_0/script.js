const submit = document.getElementsByClassName("submit_button");

function alarma() {
  alert("Ethän sä nyt sitä voi tilata!!");
}
